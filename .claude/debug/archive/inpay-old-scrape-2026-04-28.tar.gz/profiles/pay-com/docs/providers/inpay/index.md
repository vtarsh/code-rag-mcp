# Inpay — Provider Documentation

Scraped from https://app.inpay.com/docs/ on 2026-04-24. Source: React SPA that loads 7 OpenAPI 3.0.3 specs + 54 markdown pages + 7 ISO 20022 code snippets.

## API surface — 126 endpoints across 7 specs

- [Authentication API](authentication.md) — 3 endpoints (credentials check, encryption/decryption)
- [Collections API](collection.md) — 17 endpoints, 17 schemas (orders, payments, refunds, banks, extra_fields)
- [Customer APP API](customer_app_api.md) — 90 endpoints, 185 schemas (organisations, payout_batches, payout_drafts, payout_requests, payout_reports, withdrawal_requests, stats)
- [FX API](fx.md) — 1 endpoint, 2 schemas
- [Payouts API](payouts.md) — 7 endpoints (read-side: status lookup, search, reports, cancellation)
- [Payouts — Create endpoints](payouts-create.md) — not in Swagger: `POST /disbursement/payment_requests`, `POST /disbursement/iso_20022` (per-product schema)
- [Reconciliation API](reconciliation.md) — 4 endpoints (balance, funding, daily/monthly statements)
- [Sandbox Customer API](sandbox_customer_api.md) — 4 endpoints

## ⚠️ Path-prefix gotcha — `/api/` is wrong everywhere

**Verified live against `https://test-api.inpay.com` on 2026-04-25.** All swagger paths starting with `/api/` are wrong for the public façade — strip the prefix. Inpay's swagger was authored against an internal back-end (servers `backend-v2.internal/` and `*-backend-v2.inpay.com/` — none of those hosts resolve in public DNS). The public edge proxy never expects `/api/`.

**Public host → real path mapping** (each row probed with credentials):

| Spec | Swagger path prefix | Public path prefix | Probe verdict |
|---|---|---|---|
| `authentication` (3 ops) | `/api/authentication/...` | **`/authentication/...`** | `GET /authentication/checks/credentials` → `200 {"status":"OK"}` |
| `authentication` (decrypt/encrypt) | `/api/authorization/checks/...` | **`/authorization/checks/...`** | `POST .../encryption` → `200 + PKCS7` |
| `collection` (17 ops) | `/api/collection/...` | **`/collection/...`** | `POST /collection/orders` → live |
| `fx` (1 op) | `/api/fx/exchange_rate` | **`/fx/exchange_rate`** | live |
| `sandbox_customer_api` (4 ops) | `/api/sandbox/...` | **`/sandbox/...`** | live |
| `payouts` (7 ops) | `/disbursement/...` | `/disbursement/...` (no change) | `POST /disbursement/payment_requests` → `400 invalid_pkcs7_format` (route OK, needs `merchant.crt`) |
| `reconciliation` (4 ops) | `/reconciliation/...` | `/reconciliation/...` (no change) | `GET .../accounts/balance/virtual_account/{id}` → `200 + PKCS7` |
| `customer_app_api` (90 ops) | `/customer_app_api/...` | **NOT PUBLIC** | the entire `/customer_app_api/*` namespace 302-redirects on `test-api.inpay.com` — internal merchant-panel API only |

### Confirmed-live endpoints (no auth context required to confirm route exists)

- `GET /authentication/checks/credentials` → `200`
- `POST /authorization/checks/encryption` → `200` + PKCS7
- `POST /authorization/checks/decryption` → `200` + PKCS7
- `GET /reconciliation/accounts/balance/virtual_account/{id}` → `200` + PKCS7
- `GET /reconciliation/accounts/{id}/daily_statement.json` → `422` + PKCS7 (route exists)
- `POST /disbursement/payment_requests` → `400 invalid_pkcs7_format` (route exists; needs valid PKCS7 from `merchant.crt`)
- `POST /disbursement/iso_20022`, `GET /fx/exchange_rate`, `POST /collection/orders`, sandbox endpoints — all live

### Confirmed-NOT-public

- The whole `/customer_app_api/*` namespace — internal merchant panel, not exposed via public façade
- `/payment_instruments` as a top-level — only exists inside the (inaccessible) `customer_app_api`

### Hosts to use

- Production: `https://api.inpay.com` + `<path-without-leading-/api>`
- Test sandbox: `https://test-api.inpay.com` + `<path-without-leading-/api>`
- Dev/UAT: `https://{dev,uat}-api.inpay.com` + `<path-without-leading-/api>`

Swagger-listed `*-backend-v2.inpay.com/` are internal-only (no public DNS). Use `*-api.inpay.com` unless you have VPN.

## Reason codes

- [Payouts reason codes](reason-codes-payouts.md) — 89 codes across `refund_returned`, `refund_cancelled`, etc. (also [JSON](reason-codes-payouts.json))
- [Collection reason codes](reason-codes-collection.md) — 17 codes (also [JSON](reason-codes-collection.json))

## Guides & conceptual docs

54 markdown pages (flattened into the root dir with `__` as path separator) covering onboarding, integration, webhooks, sandbox, security:

**Getting started & integration (docs-overview):**
- `docs-overview__introduction.md` + `about.md` + `business-value.md` + `working-with-services.md`
- `docs-overview__getting-started__*` (introduction, onboarding-process, environments-and-going-live, operating)
- `docs-overview__integration__*` (introduction, prepare, build, test, go-live, maintenance, data-security, input/output-data, setup-prod, test-verification, needed-setup/get-your-api-keys)
- `docs-overview__integration__authentication__*` (introduction, key-elements)
- `docs-overview__integration__webhooks__*` (description, needed-setup)

**API reference pages (api):**
- `api__getting-started__introduction.md` + `security-model.md` + `sign-and-encrypt.md` + `decrypt-and-verify.md`
- `api__getting-started__http-headers__*` — `bearer-token.md`, `x-auth-uuid.md`, `x-request-id.md`
- `api__payouts-introduction.md` — payout state machine (Received → Processing → Pending/Action required/Rejected → Completed → Returned)
- `api__payouts-terminology.md`, `api__payouts_virtual_bank_account.md`
- `api__payins_virtual_bank_account.md`
- `api__products.md` — product concept (currency × country × method)
- `api__response-codes.md`, `api__api-errors.md`
- `api__iso-introduction.md`, `api__iso-2022-status-codes.md`, `api__iso-2022-response-further-checks.md`
- `api__collection-products.md`
- `api__collections__*` — terminology, order-lifecycle, order-status-reasons, bank-transfer-payment-status, instant-bank-transfer-payment-status, ui-integration

**Sandbox:**
- `docs-overview__sandbox__introduction.md` + `getting-started.md`
- `docs-overview__sandbox__test-cases-overview.md`
- `docs-overview__sandbox__payins-test-cases.md`
- `docs-overview__sandbox__payouts-test-cases.md`

## Code snippets — `code-snippets/`

- `iso2022-request-pain.xml` — `pain.001` outgoing request sample
- `iso2022-request-pacs.xml` — `pacs.008` outgoing request sample
- `iso2022-received-response-pain.xml` / `pacs.xml` — "received" response
- `iso2022-rejected-response-pain.xml` / `pacs.xml` — "rejected" response
- `pkcs7example.txt` — PKCS#7 encryption example (used for sign-and-encrypt / decrypt-and-verify)

## Raw sources — `swagger/`

Original OpenAPI 3.0.3 JSON specs as downloaded from `/docs/swagger/*.json`. Use the generated `.md` files above for reading; keep the JSON if you need to re-process or feed to another tool.

## Key integration notes (from pages)

- Auth: bearer token + `X-Auth-Uuid` (Inpay-issued) + `X-Request-ID` (caller-generated).
- Security model requires sign-and-encrypt on requests, decrypt-and-verify on responses (PKCS#7). See `pages/api__getting-started__security-model.md`.
- Webhooks: 2XX = accept; 3XX/4XX = stop retrying; 5XX = Inpay retries. No response body expected. See `pages/docs-overview__integration__webhooks__description.md`.
- Payout product model drives request schema — `GET /customer_app_api/disbursement/organisations/{org}/product_schemas` → pick product → `GET .../schema_fields_definition/{schema_id}` for required fields.
