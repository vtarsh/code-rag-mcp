When our servers process an API request, they may encounter two types of errors:

- Controlled errors are resulting from requests that break some business rules and as such we will be able to provide a response indicating what went wrong.

- Uncontrolled errors are bugs or infrastructure problems which should not happen.
