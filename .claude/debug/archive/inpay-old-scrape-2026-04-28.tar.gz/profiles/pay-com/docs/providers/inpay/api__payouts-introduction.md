The disbursement straight through processing (STP) is illustrated below using green colors. The yellow colors represents states that requires an action from you, while the red are states from where a disbursement can not recover.

<img src="payouts-intro-light.svg" alt="payouts-diagram"/>

<table class="table mt-3">
<thead>
<tr>
<th>
Status
</th>
<th>
Description
</th>
</tr>
</thead>
<tbody>

<tr>
<td>
<code>Received</code>
</td>
<td>
The payment request has passed our primary validations and therefore confirmed as received. The payment request still may be rejected upon secondary and, if applicable, external validations.
</td>
</tr>

<tr>
<td>
<code>Processing</code>
</td>
<td>
The payment request has successfully passed all data validation types and is now under processing. Please note that processing status encompasses internal compliance reviews: if transaction monitoring identifies a transaction requiring additional data to finalise manual review, a follow up webhook indicating payment state change to <code>action_required</code> will be triggered.
</td>
</tr>

<tr>
<td>
<code>Pending</code>
</td>
<td>
If a payment request has been submitted with a later execution date, e.g. requested_execution_date, the request will remain in <code>pending</code> state until the requested date of execution is reached. On that date, the payment will progress to <code>processing</code> state.
</td>
</tr>

<tr>
<td>
<code>Action required</code>
</td>
<td>
If a payment request requires an action in order to process, e.g. insufficient funds in the virtual account, a webhook will be triggered to inform you that the payment request is in <code>action_required</code> state. The corresponding message in the reason code will provide details on what action is required.
</td>
</tr>

<tr>
<td>
<code>Rejected</code>
</td>
<td>
If a payment request is not executable for some reason, the payment will  be marked as rejected  and this event will trigger a new webhook notification. A payment request can enter this status right after received state due to failing validations. A payment can also be rejected due compliance and in such instance the respective payment request may change from, for example, <code>processing</code> or <code>action_required</code> status to <code>rejected</code> state.
</td>
</tr>

<tr>
<td>
<code>Completed</code>
</td>
<td>
Completed webhook is triggered when the respective payment request has been accepted for processing by the banking layer/processing partner.
</td>
</tr>

<tr>
<td>
<code>Returned</code>
</td>
<td>
If a payment is returned to Inpay after it has been processed, the state of the payment will be set as returned and a webhook notification will be sent to you informing you of this status change.
</td>
</tr>
</tbody>
</table>

<br />
<div class="hint">
  <p>
    <b>Hint</b>: You can use <a href="/guide/sandbox#sandbox-payouts-test-cases">Sandbox test cases</a> to facilitate the payment request going through various statuses.
  </p>
</div>
