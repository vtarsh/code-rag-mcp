ISO 20022 is a single standardisation approach to be used by all financial standards initiatives. The API accepts both **ISO 20022 XML pain.001.001.10** and **pacs.008.001.12** as a payment initiation message.

After receiving a request the API will carry out preliminary validations. Then, an **ISO 20022 XML pain.002 / pacs.002** message will be sent as a status report to inform whether the request has been accepted or rejected. Once accepted, the message will be processed asynchronously and updates on status changes will be sent via configured [webhook notifications](/guide/docs-integration#integration-webhooks-needed-setup).

Please refer to the ISO 20022 Message Definition page for more information about [pain](https://www.iso20022.org/iso-20022-message-definitions?search=pain) and [pacs](https://www.iso20022.org/iso-20022-message-definitions?search=pacs).

<div class="warning">
Important: The body of the request must be signed and encrypted pain.001.001.10 XML or pacs.008.001.12 XML.

Please consult [Sign & Encrypt a request](/reference/getting-started#sign-and-encrypt) in case of doubts about encryption requirements.

</div>

As mentioned above, the XML message resulting from decrypting the message sent to the API must be a valid ISO 20022 XML pain.001.001.10 or pacs.008.001.12 message. Besides the message following the required format, it also must be compliant with the products that are enabled for your account. You can, at any time after you log in, review your access configuration under the [Products](#products) section.

<img src="payouts-processing-of-ISO-20022-messages-light.svg" alt="iso-flow"/>
