# Reason codes — collection

_17 codes total._

## `collection` (10 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `101` | `` |  |  |
| `102` | `` |  |  |
| `103` | `` |  |  |
| `191` | `` |  |  |
| `194` | `` |  |  |
| `200` | `` |  |  |
| `211` | `` |  |  |
| `229` | `` |  |  |
| `232` | `` |  |  |
| `98` | `` |  |  |

## `refund_cancelled` (7 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `130` | `` |  |  |
| `188` | `` |  |  |
| `21` | `` |  |  |
| `32` | `` |  |  |
| `35` | `` |  |  |
| `36` | `` |  |  |
| `validation_schema_failed_generic_key` | `` |  |  |
