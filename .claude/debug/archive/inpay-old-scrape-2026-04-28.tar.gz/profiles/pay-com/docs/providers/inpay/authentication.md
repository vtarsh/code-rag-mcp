# Authentication API

**API version:** v1

> ⚠️ **PATH PREFIX:** All paths below carry a leading `/api/` because the swagger describes the internal back-end. The **public façade** (`https://api.inpay.com`, `https://{dev,uat,test}-api.inpay.com`) **strips `/api/`**. Verified: `GET https://test-api.inpay.com/api/authentication/checks/credentials` → `302` (wrong), `GET https://test-api.inpay.com/authentication/checks/credentials` → `200 OK` (correct). See `index.md` for the full mapping.

## Servers (internal back-end, swagger-as-authored)

- `https://backend-v2.internal/` — docker
- `http://localhost:3000` — Localhost
- `https://dev-backend-v2.inpay.com/` — DEV (not publicly resolvable)
- `https://uat-backend-v2.inpay.com/` — UAT (not publicly resolvable)
- `https://test-backend-v2.inpay.com/` — TEST (not publicly resolvable)

## Public façade (use this from outside Inpay)

- Prod: `https://api.inpay.com` + `<path-without-/api>`
- Test: `https://test-api.inpay.com` + `<path-without-/api>`

## Endpoints (paths shown as authored in swagger — strip leading `/api/` for public calls)

## `GET /api/authentication/checks/credentials`

**Summary:** Credentials

You can use this endpoint to verify your authentication credentials. Those credentials are the ones sent in each request as HTTP headers. <a href="/docs/guide/docs-integration#integration-authentication" target="_blank"> Check the authentication section in case of doubt</a>

**Tags:** Authentication / Checks

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `status`: string


---

## `POST /api/authorization/checks/decryption`

**Summary:** Decryption

You can use this to test data decryption on your end. Inpay will encrypt & sign the request data and return this to you, for you to <a href="/docs/reference/getting-started#decrypt-and-verify" target="_blank">decrypt and verify the data on your end.</a>

**Tags:** Authorization / Checks

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |

### Request body

Payload to be decrypted

_Required._

**Content-Type:** `text/plain`

- string

### Responses

#### `200` Successful

**Content-Type:** `text/plain`

- string [example: `-----BEGIN PKCS7-----
MIIOSQYJKoZIhvcNAQcDoIIOOjCCDjYCAQAxggJOMIICSgIBADAyMCUxCzAJBgNV
...
bAGGI4H9dWmvkGrXjT2qVfA5zuLMy3nXEZfQgeemPlIdEeY9vpIbeNWapa+CFWBq
W8oFBFXmPg/WOgXmpA==
-----END PKCS7-----`]


---

## `POST /api/authorization/checks/encryption`

**Summary:** Encryption

You can use this to test the data encryption. <a href="/docs/reference/getting-started#sign-and-encrypt">Sign and encrypt</a> the payload on your end and Inpay will decrypt & verify the data.

**Tags:** Authorization / Checks

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |

### Request body

Payload to be encrypted

_Required._

**Content-Type:** `text/plain`

- string

### Responses

#### `200` Successful

**Content-Type:** `text/plain`

- string [example: `Hello Inpay!`]


---

