All responses coming from Inpay's API are - like the requests - signed and encrypted, including GET responses. In order to read the response it is required to use the SSL Private key to decrypt the data.

<p>After decrypting the data, it is strongly recommended to verify the signed data or else you cannot be sure the request originates from Inpay. When verifying the data, you use <a id="inpay-public-ssl-certificate">Inpay's Public SSL X.509 Certificate (Click to see)</a></p>
