## Contact

When you are ready to go through a validation process together with Inpay, please reach out to the onboarding team by replying to their email about this.

[Here's more information about how to contact us](https://www.inpay.com/contact-us/)

## Process for validation

Next to the validations you need to do internally in your organisation, Inpay also needs to see that it is possible for your integration to function correctly before you can move to the production API.

<div class="warning">
Your tests should, as a minimum, cover all corridors used in your products, but it is preferred that you test all products. Additionally, your webhook should provide the expected “200 OK” response.
</div>

## Obtaining production credentials

When you and Onboarding & Support have ensured that the integrations solution works well and is ready to go live, the onboarding team will create a production access for you with a new set of API endpoints, and they will send you the needed login information.
