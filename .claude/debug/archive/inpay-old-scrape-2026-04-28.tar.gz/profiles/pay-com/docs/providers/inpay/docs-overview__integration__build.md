Through the development phase you will need to consult the API reference section for the specifics of the available API endpoints and their exact use.

## API areas

The different areas of the [API reference](/reference/getting-started) that you have access to contain all the endpoint information and other information that you will need – so that the [payouts area](/reference/payouts#payouts-concepts) is fully described in the section for this.

The only exceptions are the [reconciliation area](/reference/reconciliation#reconciliation-get-balance), that holds endpoints for handling the Inpay virtual account and is useful across the API, and the integration help area, that is meant to be used mainly for the initial testing of your certificates.

## Products

For each area, the products are different – for instance, a product in Payouts consists of `Country + Currency + Local instrument` together.

For each product, you will find information on available fields, which of them are mandatory and which are optional, and there are examples of a full set of values.

Please pay attention to the fact that different products may have different mandatory and optional fields, due to different rules and restrictions related to the involved parties. There can also be a different set of fields altogether, which makes it necessary to pay attention to the field set of each individual product.

- The mandatory fields must always be filled out with relevant values for a request to work.
- The optional fields may be filled out and will be forwarded as they fit to the connected service providers, but it is not possible to say anything general about if and how the information will be used if present.

## Examples

There are examples for each available product, and for each endpoint. Examples are to some extent pre-filled with values related to your account.

The examples will need adaptation – so that all mandatory fields, as well as those optional fields you choose to fill out, are filled out according to their field descriptions and with a combined set of values that makes sense (city and country values that match each other, for example).

<div class="warning">
When using the endpoint addresses listed, please note that they are slightly different between the test API and the production API, so you should preferably construct your code with a mechanism for swapping the first part of the address.
</div>
