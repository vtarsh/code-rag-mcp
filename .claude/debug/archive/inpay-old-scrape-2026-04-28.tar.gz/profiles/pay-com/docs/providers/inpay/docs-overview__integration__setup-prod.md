**You will need a separate environment for production, as it is suggested that you keep your test environment for future maintenance and changes.**

You will receive new links to a customer portal and API information

<div class="warning">
It is important to keep in mind that everything in the production environment is separate from the test environment, at least on the Inpay-side of it – no data can or will be transferred, and no certificates or tokens can be repurposed for the new environment.
</div>
