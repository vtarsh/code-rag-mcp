There are several ways to utilise the services from Inpay.

## **[API](/reference/getting-started#introduction)**

The Inpay API will be the preferred way of arranging payments for any organisation having a high volume or a regular flow of transactions to perform and is the primary way of interacting with our system.

The API allows for implementing the level of automation suitable for exactly your organisation, meaning that you can add local user interface elements to include in the workflow around the payments, or you can let all transactions take place fully automated as an extension of your other software solutions.

This allows you to develop different types of applications that either run in your back office or has user interactions through a web or mobile application.

The API is based on a [REST](https://en.wikipedia.org/wiki/REST) architecture for direct communication with webhooks used for asynchronous elements, such as follow-up status on the transactions, and offers and [ISO 20022](https://en.wikipedia.org/wiki/ISO_20022) XML communication. The communication is [fully encrypted](/guide/docs-integration#integration-authentication), end-to-end, using [CMS/PKCS#7](https://en.wikipedia.org/wiki/Cryptographic_Message_Syntax) and `X.509` certificates.

#### **[List of endpoints we have](/reference/reconciliation#reconciliation-get-balance)**

#### **[Our security model](/guide/docs-integration#integration-authentication)**

<h2><strong><a id="customer-app-link">Customer App</a></strong></h2>

Our Customer App is a user-friendly interface that can be used alongside your API integration or independently.

You can use it for manual data input, view transactions and their statuses, as well as manage your account. Our Customer App also offers a semi-automatic way of providing multiple inputs in one go, making batch payouts a joy. You can use the Customer App in both test and production environments.

<img src="customer-app-light.png" alt="customer app" />
