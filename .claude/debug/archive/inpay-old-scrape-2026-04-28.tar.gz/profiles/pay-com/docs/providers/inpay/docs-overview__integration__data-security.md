The Inpay API offers a [secured communication with encryption and authentication](/reference/getting-started#security-model) of the sender of data, but the rest of the solution could be vulnerable to unwanted exposure or theft of data.

An end-to-end evaluation of the data security needs is suggested, ensuring that every potential soft spot during the data flow will be handled appropriately by your solution.
