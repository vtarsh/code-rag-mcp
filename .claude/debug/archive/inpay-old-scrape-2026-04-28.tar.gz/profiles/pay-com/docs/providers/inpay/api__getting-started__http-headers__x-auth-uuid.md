XAuth (Extended Authentication) consists of a code or a number that Inpay gives you for the solution and you then include in all communication, together with the Authorization Bearer Token, showing that the communication came from you.

The HTTP header to use for this: `X-Auth-Uuid: [X-Auth-Uuid]`
