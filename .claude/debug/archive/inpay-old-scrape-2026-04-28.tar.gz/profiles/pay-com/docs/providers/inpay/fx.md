# FX API

**API version:** v1

> ⚠️ **PATH PREFIX:** The single endpoint here carries a leading `/api/` because the swagger describes the internal back-end. The **public façade strips `/api/`**: `GET /api/fx/exchange_rate` → public is `GET https://api.inpay.com/fx/exchange_rate`. See `index.md`.

## Servers (internal back-end)

- `https://backend-v2.internal/` — docker
- `http://localhost:3000` — Localhost
- `https://dev-backend-v2.inpay.com/` — DEV server
- `https://uat-backend-v2.inpay.com/` — UAT server
- `https://test-backend-v2.inpay.com/` — TEST server

## Security schemes

### `bearerAuth`

- type: `http`
- scheme: `bearer`
- bearerFormat: `JWT`

## Endpoints

## `GET /api/fx/exchange_rate`

**Summary:** Retrieve Exchange Rate

**Tags:** FX

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |
| `buy_currency` | query | string | yes | buy currency. Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies. |
| `pay_currency` | query | string | yes | pay currency. Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies. |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `buy_currency`: string — Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies.
- `pay_currency`: string — Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies.
- `exchange_rate`: string — the exchange rate value
- `utc_time`: string — time when the request was processed in UTC time zone.

#### `400` Bad Request - Invalid Parameters

**Content-Type:** `application/json`

- `errors`: array of object
  - `details`: object
  - `title`: string
  - `detail`: object

#### `404` Not Found - Exchange Rate not found

**Content-Type:** `application/json`

- `errors`: array of object
  - `detail`: string
  - `title`: string


---

# Schemas / Definitions

## `error_object`

- `title`: string
- `detail`: 

---

## `error_response`

- `errors`: array of **error_object**
  - **error_object** (ref)
    - `title`: string
    - `detail`: 

---
