Inpay offers a test API and asks for development to take place against this, ending up with a joint verification that ensures a properly functioning solution before going live with it.

You may consider employing your own tools for quality insurance and code verification, and in addition, both the Inpay customer portal and the API itself can assist in the verification and error tracking process.

## Using the API

Next to the dedicated integration help endpoints for checking the authentication and encryption, it can be valuable to also control the correct outcome of your code by cross-checking through the other API endpoints.

For instance, checking the [Get Account Balance](/reference/reconciliation#reconciliation-get-balance) after completing an [Account Funding request](/reference/reconciliation#reconciliation-account-funding) to see if the balance adjusted correspondingly, or check with a [Search payment request](/reference/payouts#payouts-search) that the payment you requested through [Create payment](/reference/payouts#payouts-create) has been registered correctly.

By thinking this into the development project, you might be able to get through it faster and reach a higher level of confidence with the quality of your entire integration solution.

## Using the customer portal

The <a id="customer-app-link">customer portal</a> is a web app for manual interaction with Inpay’s services, including the possibility to monitor transactions.

You can utilise this during the development phase to quickly check if the transaction your code initiated has been sent and processed as expected.
