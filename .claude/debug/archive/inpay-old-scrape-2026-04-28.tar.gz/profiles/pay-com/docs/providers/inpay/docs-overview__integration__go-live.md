Follow these steps to ensure a smooth transition to production:

### 1. Verify Credentials and Certificates

Ensure you have exchanged the necessary `.csr` files and credentials with Inpay during development. Confirm with Inpay’s Onboarding & Support that the correct certificates and tokens are in place.

### 2. Provide Production Webhook URL

Send your production webhook URL to Onboarding & Support when requested.

### 3. Ensure Backend Systems Connectivity

Check that all integrated systems, both internal and third-party, are correctly configured for the production environment.

### 4. Validate Setup

Use the integration help endpoints in the production environment to verify that the security setup is working correctly.

### 5. Perform Final Verification

Conduct one or more transactions in the production environment, preferably with known accounts, to ensure the transaction flow is correct. Use the customer portal for monitoring. If you don't have access, collaborate with someone who does. Remember, all production transactions are real.

### 6. Go Live

Once testing is complete, you are live and can start using the integration in production.

### 7. Communicate with Inpay

For all go-live activities, contact Onboarding & Support at [support@inpay.com](mailto:support@inpay.com) or reply to their emails. They will assist you and help resolve any issues that may arise.

By following these steps, you can ensure a smooth and successful go-live process for your Inpay integration.
