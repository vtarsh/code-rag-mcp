The Inpay API communication is secured by a model for **public-key message encryption and signing** using [X.509 certificates](https://en.wikipedia.org/wiki/X.509) which builds on top of [PKCS 7](https://en.wikipedia.org/wiki/PKCS_7).

The encrypted and signed messages are furthermore exchanged over the Internet using the `HTTPS` over [`TLS`](https://en.wikipedia.org/wiki/Transport_Layer_Security) protocol that ensures encryption as well as authentication of the underlying `HTTP` messages, in which the actual API messages are placed.

We’re using a format called `PKCS#7` which encapsulates encryption and signing into one message. This method use certificates to encrypt and private keys to sign

<img src="Encryption-and-signing-light.svg" alt="auth diagram"/>
