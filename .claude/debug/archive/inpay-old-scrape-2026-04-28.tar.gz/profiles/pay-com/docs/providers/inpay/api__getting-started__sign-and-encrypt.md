All communication to and from the API is encrypted & signed using PKCS#7.

Sign the payload (XML or JSON) with your private key - Inpay will verify the signed data before processing any payments, to ensure the request comes from you.

Encrypt the signed data (In either PEM or DER format) using <a id="inpay-public-ssl-certificate">Inpay's Public SSL X.509 Certificate (Click to see)</a> - this ensures only Inpay can decrypt and read the content. The encrypted data should be packages in PEM format. It looks like this

[Read more about the authentication & encryption model here](/guide/docs-integration#integration-authentication)
