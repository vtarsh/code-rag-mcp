We provide a secure, Inpay-hosted payment experience that lets you collect payments quickly.

Inpay offers one hosted UI integration method - **Redirect**. This solution is built to offer you a fast and simple way to connect while reducing the usage of internal resources for user interface development.

The diagram below illustrates the interactions between the different applications across the user journey.

<img src="payins-ui-integration-flow-light.png" alt="payins-ui-integration"/>

## Redirect

When using redirection your end-users will enter the required information to place an order on your platform and, when the time to choose a payment method comes, you have two options:

- **Delegate the Payment Method's choice to Inpay**: The end user will be able to pick how to pay after being redirected to Inpay. Inpay will only include in the list of Payment Methods to choose from those contracted by the Merchant. In order to be able to redirect to Inpay, your platform will need to first create an order by calling the [CreateOrder](/reference/collections#collections-order-create) end point via the Collection API, and then issue a 302 redirect to the user's browser pointing to the received redirect_url in the CreateOrder response.

- **Let the user choose the Payment Method in your platform**: In this scenario you will need to do two calls to the Collections API prior to redirecting the user. In the first call you will create an Order by calling the [CreateOrder](/reference/collections#collections-order-create) end point and then you will create a Payment by calling the [CreatePayment](/reference/collections#collections-payment-create) end point. The [CreatePayment](/reference/collections#collections-payment-create) response contains a <code>redirect_url</code>, which you need to use to redirect the end-user to the Inpay UI.
  In the Inpay UI, we will collect all the required payment information from the user to perform the funds collection. Once the user finishes the journey at the Inpay UI, the user will be redirected back to your application by using the URL provided when creating the order as order.back_to_merchant_url.

<div class="warning">
  <b>Redirect URLs</b>
  Collections API returns two different redirect URLs. Below you can read what each of them mean:
  <li>
    <b>Redirect URL in order response:</b> Inpay UI takes the end user through a set of sequential steps in order to make a payment related to an order. This redirect URL takes the end user to the first step of the process, which is the payment method selection. By using this redirect URL you don't even have to create a payment, since the payment will be created based on the user selection.
  </li>
 <li>
    <b>Redirect URL in payment response:</b> Taking into account what is described above, this redirect URL is different and takes the end user to a further step in the Inpay UI interface since the payment selection was done by your application when creating the type of payment you want your end user to make. This redirect URL might take the end user to different steps since it depends on the type of payment and state of the payment.
  </li>

</div>
