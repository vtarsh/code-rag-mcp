As previously stated, every time an Order transitions from one status to another, a webhook notification is sent. In the majority of cases it is enough to look at the status field in the notification to understand the reason behind such notification. The meaning of each of those statuses is explained in the [Order Status](/reference/collections#payins-lifecycle) section.

However, in some exceptional cases, further clarification about the reason/s that made an Order reach certain status will be added in the <code>status_reasons</code> field of the webhook notification. This is the case for the following Order statuses:

<table class="table mt-3">
  <thead>
    <tr>
      <th>Order Status</th>
      <th>Potential Status Reasons</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code>ACTION REQUIRED</code></td>
      <td>
        <ul>
          <li>Order processing halted, payment will be refunded to the debtor</li>
          <li>Order held for review by Inpay's compliance team</li>
          <li>Too much funds have been received</li>
        </ul>
      </td>
    </tr>
    <tr>
      <td><code>PROCESSING REFUND</code></td>
      <td>
        <ul>
          <li>Rejected by Inpay due to compliance</li>
          <li>Refund requested by customer</li>
        </ul>
      </td>
    </tr>
    <tr>
      <td><code>REFUNDED</code></td>
      <td>
        <ul>
          <li>Rejected by Inpay due to compliance</li>
          <li>Refund requested by customer</li>
        </ul>
      </td>
    </tr>
     <tr>
      <td><code>ACTION REQUIRED FOR REFUND</code></td>
      <td>
        <ul>
          <li>Refund cannot be issued - not enough funds in the Virtual Account</li>
        </ul>
      </td>
    </tr>
    <tr>
      <td><code>CANCELLED</code></td>
      <td>
        <ul>
          <li> • Order cancelled by user</li>
          <li> • Order cancelled by <code>###merchant_name###</code></li>
          <li> • Order cancelled by Inpay Operator in Inpay Admin</li>
          <li> • Order Expired</li>
          <li> • Payment failed</li>
        </ul>
      </td>
    </tr>
  </tbody>
</table>
