A Bank Transfer Payment tracks a payment attempt when the end user selects Bank Transfer as Payment Method. Hence, a Bank Transfer Payment may go through a set of statuses only relevant to this Payment Method. The meaning of each of such statuses is explained in the table below:

<table class="table mt-3">
<thead>
<tr>
<th>Status</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>CREATED</code></td>
<td>A choice has been made to pay via Bank Transfer.</td>
</tr>
<tr>
<td><code>INSTRUCTIONS PROVIDED</code></td>
<td>The appropriate Payment Instructions have been generated based on the location of the Debtor Account.</td>
</tr>
<tr>
<td><code>COMPLETED</code></td>
<td>The funds have arrived to an Inpay account. This status will make the related Order move to Processing status.</td>
</tr>
</tbody>
</table>

There are NO webhook notifications being sent because of status transitions in a Bank Transfer Payment since this is just a subpart of the overall collection process which is tracked by the Order instead. Please refer to the webhook notification section for further details.

<div class="warning">
  <li>
    A Bank Transfer Payment is created every time the end user starts a payment attempt via Bank Transfer. An Order may have one or many Payments.
  </li>
  <li>
    Only the status <code>Completed</code> cause a status change in the Order.
  </li>
  <li>
    Only the Bank Transfer Payment that reaches status <code>Completed</code> becomes the Primary Payment of the Order.
  </li>
  <li>
    The status of every Payment may be checked at any time by calling the <a href="/reference/collections#collections-get-payment-details">GetPaymentDetails</a> end point
  </li>

</div>
