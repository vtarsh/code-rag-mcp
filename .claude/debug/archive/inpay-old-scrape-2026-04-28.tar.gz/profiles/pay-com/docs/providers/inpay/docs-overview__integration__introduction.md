The suggested process flow looks like this, with each step explained further below:

<img src="integration-process-light.svg" alt="onboarding process" />

Even though this illustrates a phased approach, you may wish to organise the work differently – just pay attention to having everything ready when needed for the next steps.
