## Create your private key and `.csr` `(X.509 certificate)`

- Issue the following command from the command line on a computer that has `openssl` installed. The command will generate both files as its output:

```bash
openssl req -new -newkey rsa:4096 -nodes -keyout merchant-private.key -out merchant.csr -subj /O='organisation Name'/C='DK'/ST='Denmark'/L=''/
```

The private key will have the extension `KEY` and the `.csr` file will have the extension `.csr`. We suggest that you use the file names and their endings as they are, without changing them, to avoid any confusion.

<a id="inpay-private-and-certificate-key-pair"></a>

## Get your `X-Auth-Uuid`

After sending the `.csr` file to us, we will return your `X-Auth-Uuid` in an email that also contains other information – everything you need to get started.

You will get a separate set of information for the test environment and the production environment, at separate times, when needed, and each set will be provided to you as the response to you sending us your `.csr` for that environment.

<div class="warning">
  This is used by Inpay to verify the signature 
</div>

## Get your Authorization `Bearer token`

We will send this token to you together with your `X-Auth-Uuid`. They are always used together.

## Get your `X.509` certificate

We will send you this key in the same email as the `X-Auth-Uuid`.

<div class="warning">
Inpay will encrypt your messages when sending them to you using your X.509 certificate
</div>

## Get Inpay's `X.509` certificate

- You can see Inpay’s public key here: <a id="inpay-public-ssl-certificate">Inpay's Public SSL Certificate (click to see)</a> <br/>

<div class="warning">
You will encrypt your messages using this and send them to us.
</div>

## Get your account number

For the test environment, we will send you a virtual account number by email. This can be used in the test environment as if it were a bank account number, allowing you to add and spend fonds. The virtual account is only for test purposes in the test environment, no real money will be transferred.

We will tell you more about how to proceed with adding your real-world account information when setting up the production environment.

## Security considerations

All keys, tokens and numbers belong to one environment – you will need:

- a complete set for your test environments
- complete set for your production environment.

### Private key

In all cases, **you should store the private key in a safe place**. This key is for your own use only, and the security solution is based on the expectation that only you have this key – nobody else. This means that when using it in the application – for signing the payload of your own messages and for decrypting the messages from Inpay – you should make sure that your code will not accidentally reveal it to anyone that is not a trusted member of your team.

### Public key

Your public key and Inpay’s public key are less sensitive, and your main consideration is to make sure that Inpay’s public key is available for your application when encrypting your messages to Inpay. Your public key is not used in your end of the communication.

### Other sensitive information

- `X-Auth-Uuid` and the `Authorization Bearer Token` must be present in the `HTTP` headers of each message you send to the Inpay API. They should be kept private between you and Inpay, to avoid any potential abuse of your account.
- Bank account numbers should be treated according to your company’s policy, but in case there is no such policy available, it is advised to avoid sharing them publicly.
- All information about your company, including names of people and addresses, may be subject to special treatment according to relevant laws and regulations about personal data.
- The transactions made by your application may contain sensitive information about your own organisation or your customers, so you should pay attention to your use of log files and similar, protecting these from unauthorised access.
