Inpay provides **cross-border payments solutions** that can also be accessed and used through the Inpay <a id="customer-app-link">Customer App</a>, which is convenient for many customers.

<img src="api-doc-introduction-light.png" alt="api introduction diagram"/>
