All communication happens over `HTTPS` `TLS1.2` (or newer) and is fully end-to-end encrypted.

To get started [you will need to obtain](/guide/docs-integration#integration-needed-setup) a `X-Auth-Uuid` (a universally unique identifier that alone recognizes your account at Inpay) from [support@inpay.com](mailto:support@inpay.com). To retrieve this, you will first need to generate a private key & certificate signing request (`.csr`), see below. If you are using a 3rd party software provider or an external party in charge of your IT system administration, please reach out to them.

Upon sending the `.csr` to Inpay technical support, they will provide you with the `X-Auth-Uuid`, a Authorization bearer token and your X.509 public certificate, together these represents your authentication to the API.

Inpay uses full end-to-end encryption on our API for an extra layer of security and assurance that only you and Inpay can read the data being sent. In order to get your Inpay signed SSL certificate, please follow the steps below:

[Make sure to read this section on How to obtain the keys you need for this](/guide/docs-integration#integration-needed-setup)

1. Use the **SSL private key** to generate a Certificate Signing Request (`.csr`).
2. Send the `.csr` file to Inpay technical support [support@inpay.com](mailto:support@inpay.com)
3. Wait for Inpay to send you back your `X-Auth-Uuid` and **public SSL (X.509) certificate**. The Authorization `Bearer token` will be delivered separately.
4. Include the `X-Auth-Uuid`, Authorization `Bearer token` and your public SSL (X.509) certificate to your application and your are good to go.
5. Using <a id="inpay-public-ssl-certificate">Inpay's Public (X.509) SSL Certificate</a> for encrypting the payload and your own private key to sign the payload - we can create assurance that only you and Inpay has access to the data.

Please read the next sections carefully for information and examples on how to communicate with the API.
