The data you feed into the Inpay API will come from your other systems, and you should consider if they need to be processed on

- an event-basis, as soon as they appear
- batch processing approach is more suitable.

This will influence your application design.

It is also necessary to ensure that all the needed access rights are in place for the developers, testers, and others who take part in the project, and for the solution itself when it will go live.
