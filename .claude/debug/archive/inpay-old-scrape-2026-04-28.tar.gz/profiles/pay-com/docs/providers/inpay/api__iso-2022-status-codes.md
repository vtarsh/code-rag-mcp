<table class="table mt-3">
<thead>
<tr>
<th>
Name
</th>
<th>
XML value
</th>
<th>
Description
</th>
</tr>
</thead>
<tbody>
<tr>
<td>
Received
</td>
<td>
RCVD
</td>
<td>
Payment initiation has been received. Further checks and status update will be performed.
</td>
</tr>
<tr>
<td>
Pending
</td>
<td>
PDNG
</td>
<td>
Payment initiation or individual transaction included in the payment initiation is pending. Further checks and status update will be performed.
</td>
</tr>
<tr>
<td>
Accepted Customer Profile
</td>
<td>
ACCP
</td>
<td>
Preceding checks of technical validation was successful. Customer profile check was also successful.
</td>
</tr>
<tr>
<td>
Rejected
</td>
<td>
RJCT
</td>
<td>
Payment initiation or individual transaction included in the payment initiation has been rejected.
</td>
</tr>
</tbody>
</table>
