Payout test cases can be executed from <a id="customer-app-link">Customer App</a> -> Payouts page, Sandbox section of payout details. <br/>
There is also a related End-to-end sandbox test case field that can be used to create a payout with a pre-determined test case. It is available in <a id="customer-app-link">Customer App</a> -> Payouts page -> Create payout, Payout request step.

<table class="table mt-3">
  <thead>
    <tr>
      <th>Test case</th>
      <th>Steps</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <code>Hold</code>
      </td>
      <td>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Navigate to the <a id="customer-app-link">Customer App</a> -> Payouts page</li>
          <li>Create a payout with the <b>Hold</b> End-to-end sandbox test case field</li>
        </ol>
      </td>
      <td></td>
    </tr>
    <tr>
      <td>
        <code>Complete</code>
      </td>
      <td>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Navigate to the <a id="customer-app-link">Customer App</a> -> Payouts page</li>
          <li>Create a payout with <b>Complete</b> End-to-end sandbox test case field</li>
        </ol>
        <b>OR</b>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Execute <b>Hold</b> test case</li>
          <li>Execute <b>Complete</b> test case from the Sandbox section of payout details</li>
        </ol>
      </td>
      <td>
        This is the default behaviour when no specific test case is specified or when creating a payout through API.
      </td>
    </tr>
    <tr>
      <td>
        <code>Returned</code>
      </td>
      <td>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Navigate to the <a id="customer-app-link">Customer App</a> -> Payouts page</li>
          <li>Create a payout with <b>Returned</b> End-to-end sandbox test case field</li>
          <li>Ask <a href="mailto:support@inpay.com">support@inpay.com</a> to link the payout by reference with returned financial transaction</li>
        </ol>
        <b>OR</b>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Execute <b>Hold</b> test case</li>
          <li>Execute <b>Returned</b> test case from the Sandbox section of payout details</li>
          <li>Ask <a href="mailto:support@inpay.com">support@inpay.com</a> to link the payout by reference with returned financial transaction</li>
        </ol>
        <b>OR</b>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Execute <b>Complete</b> test case</li>
          <li>Execute <b>Returned</b> test case from the Sandbox section of payout details</li>
          <li>Ask <a href="mailto:support@inpay.com">support@inpay.com</a> to link the payout by reference with returned financial transaction</li>
        </ol>
      </td>
      <td>
        This test case currently requires manual interaction from Inpay to imitate the behaviour on production environment.
      </td>
    </tr>
  </tbody>
</table>
