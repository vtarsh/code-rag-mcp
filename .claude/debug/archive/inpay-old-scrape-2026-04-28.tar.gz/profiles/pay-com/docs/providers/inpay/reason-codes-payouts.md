# Reason codes — payouts

_89 codes total._

## `action_required` (1 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `220` | `insufficient_funds` | action_required | Insufficient funds in Virtual Account |

## `info` (4 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `283` | `no_match` | vop_info | Verification of Payee no match result |
| `286` | `close_match` | vop_info | Verification of Payee close match result |
| `289` | `match` | vop_info | Verification of Payee match result |
| `292` | `not_applicable` | vop_info | Verification of Payee not applicable result |

## `payment_request_rejected` (5 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `73` | `invalid_creditor_account` | schema_validation_error | Rejected - Invalid creditor account |
| `76` | `invalid_creditor` | schema_validation_error | Rejected - Invalid creditor |
| `79` | `invalid_ultimate_debtor` | schema_validation_error | Rejected - Invalid ultimate debtor |
| `82` | `invalid_general_data` | schema_validation_error | Rejected - Invalid general payment request data |
| `85` | `invalid_debtor` | schema_validation_error | Rejected - Invalid debtor |

## `pending` (1 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `91` | `waiting_future_execution` | pending | Payment awaiting the requested execution date |

## `refund_cancelled` (43 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `1` | `not_supported_by_your_contract` | contract_issue | Cancelled - Not supported by your contract |
| `10` | `invalid_data_incorrect_beneficiary_details` | invalid_data | Cancelled - Incorrect or missing beneficiary details |
| `11` | `invalid_data_mismatch_account_and_bic` | invalid_data | Cancelled - Mismatch account and BIC |
| `12` | `invalid_data_mismatch_country_and_bic` | invalid_data | Cancelled - Mismatch country and BIC |
| `130` | `invalid_data_incorrect_beneficiary_address` | invalid_data | Incorrect or missing beneficiary address/City/Postal code |
| `131` | `invalid_data_incorrect_beneficiary_date_of_birth` | invalid_data | Cancelled - Incorrect or missing beneficiary date of birth / DOB |
| `140` | `invalid_data_incorrect_or_missing_bank_name` | invalid_data | Cancelled - Incorrect or missing bank name |
| `143` | `invalid_data_incorrect_or_missing_BSB_number` | invalid_data | Cancelled - Incorrect or missing BSB number |
| `146` | `invalid_data_incorrect_or_missing_sender_address` | invalid_data | Cancelled - Incorrect or missing sender state/city/postal code |
| `149` | `rejected_due_to_processing_bank_policy` | processing_bank_request | Cancelled - Rejected due to processing bank policy |
| `15` | `kyc_documentation_not_provided_within_reasonable_time` | kyc | Cancelled - KYC documentation not provided within reasonable time |
| `151` | `rejected_by_processing_bank_missing_routing_capability` | processing_bank_request | Cancelled- Rejected by processing bank - missing routing capability |
| `16` | `unable_to_approve_kyc_documentation` | kyc | Cancelled - Unable to approve KYC documentation |
| `18` | `suspicious_name_mismatch` | suspicious | Cancelled - Name mismatch |
| `185` | `invalid_data_v2_tstm` | invalid_data | Rejected - Incorrect or missing data |
| `19` | `beneficiary_bank_account_closed` | suspicious | Cancelled - Beneficiary bank account is closed/blocked |
| `2` | `service_unavailable` | contract_issue | Cancelled - Service unavailable |
| `20` | `rejected_by_bank_beneficiary_flagged` | suspicious | Cancelled - Rejected by bank |
| `205` | `invalid_data_incorrect_or_missing_account_type` | invalid_data | Cancelled - Incorrect or missing account type |
| `21` | `test_payment` | test | Cancelled - Test Payment |
| `22` | `technical_issue_unknown` | technical_issue | Cancelled - Technical issue |
| `295` | `no_match` | vop_rejection | Cancelled - Verification of Payee no match result |
| `298` | `close_match` | vop_rejection | Cancelled - Verification of Payee close match result |
| `3` | `rejected_due_to_internal_policy` | internal_policy | Cancelled - Rejected due to internal policy |
| `304` | `not_applicable` | vop_rejection | Cancelled - Verification of Payee not applicable result |
| `34` | `freetext` | freetext | Refer to invoice status page |
| `35` | `requested_by_merchant` | merchant_request | Cancelled - Requested by merchant |
| `36` | `compliance_check` | kyc | Rejected by Inpay due to compliance |
| `4` | `invalid_data_incorrect_account_number` | invalid_data | Cancelled - Incorrect or missing bank account number/IBAN |
| `49` | `beneficiary_bank_account_name_mismatch` | suspicious | Cancelled - Beneficiary bank account/name mismatch |
| `5` | `invalid_data_incorrect_swift_bic` | invalid_data | Cancelled - Incorrect or missing SWIFT/BIC |
| `50` | `beneficiary_bank_is_unable_to_apply_funds` | beneficiary_bank_request | Cancelled - Beneficiary bank is unable to apply funds |
| `51` | `invalid_data_incorrect_beneficiary_name` | invalid_data | Cancelled - Incorrect or missing beneficiary name |
| `53` | `reason_not_specified_by_beneficiary_bank` | beneficiary_bank_request | Cancelled - Reason not specified by beneficiary bank |
| `54` | `not_suitable_for_faster_payment_service` | invalid_data | Cancelled - Not suitable for Faster Payment Service |
| `55` | `invalid_data_incorrect_or_missing_sender_details` | invalid_data | Cancelled - Incorrect or missing sender details |
| `6` | `invalid_data_incorrect_branch_code` | invalid_data | Cancelled - Incorrect or missing bank/branch code |
| `60` | `the_BIC_is_not_SEPA_reachable` | invalid_data | Cancelled - The BIC is not SEPA reachable |
| `62` | `processing_bank_is_unable_to_apply_funds` | processing_bank_request | Cancelled - Processing bank is unable to apply funds |
| `67` | `missing_capability` | contract_issue | Cancelled - Missing capability |
| `7` | `invalid_data_country_mismatch` | invalid_data | Cancelled - Country mismatch |
| `9` | `invalid_data_incorrect_beneficiary_bank_details` | invalid_data | Cancelled - Incorrect beneficiary bank details |
| `96` | `invalid_data_kanji_character_is_not_supported` | invalid_data | Cancelled - Kanji character is not supported |

## `refund_returned` (35 codes)

| Key | Code | Category | Description |
|-----|------|----------|-------------|
| `162` | `invalid_data_incorrect_or_missing_bank_name` | invalid_data | Returned - Incorrect or missing bank name |
| `165` | `invalid_data_incorrect_or_missing_BSB_number` | invalid_data | Returned - Incorrect or missing BSB number |
| `168` | `invalid_data_incorrect_or_missing_sender_address` | invalid_data | Returned - Incorrect or missing sender state/city/postal code |
| `174` | `rejected_due_to_processing_bank_policy` | processing_bank_request | Returned - Rejected due to processing bank policy |
| `177` | `rejected_by_processing_bank_missing_routing_capability` | processing_bank_request | Returned- Rejected by processing bank |
| `180` | `invalid_data_incorrect_beneficiary_address` | invalid_data | Returned - Incorrect or missing beneficiary address/City/Postal code |
| `181` | `rejected_by_processing_bank_is_unable_to_apply_funds` | processing_bank_request | Returned- Processing bank is unable to apply funds |
| `23` | `beneficiary_request_returned_payment_as_per_beneficiary_request` | beneficiary_request | Returned - Returned payment as per beneficiary request |
| `235` | `invalid_data_incorrect_beneficiary_name` | invalid_data | Returned - Incorrect or missing beneficiary name |
| `238` | `processing_bank_is_unable_to_apply_funds` | processing_bank_request | Returned - Processing bank is unable to apply funds |
| `25` | `invalid_data_incorrect_account_number` | invalid_data | Returned - Incorrect or missing bank account number |
| `26` | `invalid_data_incorrect_branch_code` | invalid_data | Returned - Incorrect bank/branch code |
| `27` | `invalid_data_incorrect_beneficiary_details` | invalid_data | Returned - Incorrect or missing beneficiary details |
| `277` | `invalid_data_incorrect_or_missing_account_type` | invalid_data | Returned - Incorrect or missing account type |
| `28` | `requested_by_customer` | merchant_request | Returned - Requested by customer |
| `29` | `suspicious_account_not_recognized` | suspicious | Returned - Account not recognized |
| `30` | `beneficiary_bank_account_closed` | suspicious | Returned - Beneficiary bank account is closed |
| `31` | `beneficiary_bank_account_name_mismatch` | suspicious | Returned - Beneficiary bank account/name mismatch |
| `32` | `beneficiary_bank_is_unable_to_apply_funds` | beneficiary_bank_request | Returned - Beneficiary bank is unable to apply funds |
| `38` | `invalid_data_incorrect_swift_bic` | invalid_data | Returned - Incorrect or missing SWIFT/BIC |
| `40` | `invalid_data_currency_mismatch` | invalid_data | Returned - Currency mismatch |
| `41` | `invalid_data_incorrect_beneficiary_bank_details` | invalid_data | Returned - Incorrect beneficiary bank details |
| `42` | `invalid_data_mismatch_account_and_bic` | invalid_data | Returned - Mismatch account and BIC |
| `43` | `invalid_data_mismatch_country_and_bic` | invalid_data | Returned - Mismatch country and BIC |
| `44` | `requested_by_merchant` | merchant_request | Returned - Requested by merchant |
| `45` | `suspicious_name_mismatch` | suspicious | Returned - Name mismatch |
| `46` | `rejected_by_bank_beneficiary_flagged` | suspicious | Returned - Rejected by bank |
| `47` | `technical_issue_unknown` | technical_issue | Returned - Technical issue |
| `48` | `test_payment` | test | Returned - Test Payment |
| `52` | `reason_not_specified_by_beneficiary_bank` | beneficiary_bank_request | Returned - Reason not specified by beneficiary bank |
| `56` | `beneficiary_bank_account_blocked` | suspicious | Returned - Beneficiary bank account is blocked |
| `58` | `the_account_is_not_suitable_for_EFT_transaction` | invalid_data | Returned - The account is not suitable for EFT transaction |
| `59` | `the_BIC_is_not_SEPA_reachable` | invalid_data | Returned - The BIC is not SEPA reachable |
| `61` | `invalid_data_incorrect_or_missing_sender_details` | invalid_data | Returned - Incorrect or missing sender details |
| `63` | `kyc_documentation_not_provided_within_reasonable_time` | kyc | Returned - KYC documentation not provided within reasonable time |
