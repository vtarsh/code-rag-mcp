When integrating with the Inpay API, our onboarding process provides the necessary access, information, and support for a successful setup.

Communication during onboarding is conducted via direct email between our Onboarding & Support team and your specified contact (an individual or team email address provided during signup with our sales department).

Please share the communication with your development team as needed. If any information is unclear or further assistance is required, [feel free to ask](https://www.inpay.com/contact-us/).

<img src="onboarding-process-light.svg" alt="onboarding process" />

### Steps

<br>

<table>
  <thead>
    <tr>
      <th>Step</th>
      <th>Activity</th>
      <th>Description</th>
      <th>When</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Welcome email with test API link and documentation</td>
      <td>
        Making contact and providing important first information, including a link to your customised documentation for development and test activities
      </td>
      <td>After contract signage, when your test account has been set up according to contract</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Customer App for test</td>
      <td>
        You will get receive an email with a link to set up a password for the Customer App. It also explains how to set up multi-factor authentication (MFA). The first user account is the admin, additional users can be added from the portal
      </td>
      <td>After contract signage, when your test account has been set up according to contract</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Create and send <code>.csr</code> for the test API</td>
      <td>
        <b>This is for you to do - </b> <a href="/reference/getting-started#introduction">generate a private key & certificate signing request</a> <code>.csr</code> for the development and test environment(s) and send only the <code>.csr</code> to Inpay
      </td>
      <td>As a response to the welcome mail</td>
    </tr>
    <tr>
      <td></td>
      <td>Provide webhook for test</td>
      <td>
        <b> This is for you to do – </b> <a href="/guide/docs-integration#integration-webhooks-needed-setup">When you have setup the webhook</a> for your test environment, please send us the URL to it
      </td>
      <td>As a response to the welcome mail</td>
    </tr>
    <tr>
      <td></td>
      <td>Credentials for the test API</td>
      <td>
       We will then sign your <code>.csr</code> certificate (certificate signed by Inpay) and you will receive an email attached and information about your <code>X-Auth-Uuid</code>, Authorization <code>Bearer token</code>, virtual account number, business units and instructions to set up your test environment and begin your integration.
      </td>
      <td>As a response to receiving the test <code>.csr</code></td>
    </tr>
    <tr>
      <td>4</td>
      <td>Validation test</td>
      <td>
        You are welcome to contact us when you have successfully tested all corridors and the webhook, but we are also monitoring your account and will see when you have been though these tests. We will then validate and approve your integration
      </td>
      <td>When you are done with your development and all needed tests toward the API</td>
    </tr>
    <tr>
      <td></td>
      <td>Validation approved</td>
      <td>
        We will send you an email confirming that the validation test was successful
      </td>
      <td>As a response to approved validation test</td>
    </tr>
    <tr>
      <td></td>
      <td>Production API link and documentation</td>
      <td>
        We will create your production account and send you an email with a link to your customised production documentation and a request for a production <code>.csr</code>
      </td>
      <td>After the approved validation, when your production account has been set up according to contract</td>
    </tr>
    <tr>
      <td>5</td>
      <td>Create and send <code>.csr</code> for the production API</td>
      <td>
        <b>This is for you to do – </b> <a href="/reference/getting-started#introduction">generate a private key & certificate signing request</a> for the production environment and send only the <code>.csr</code> to Inpay
      </td>
      <td>As a response to the validation approved email</td>
    </tr>
    <tr>
      <td></td>
      <td>Provide webhook for production</td>
      <td>
        <b> This is for you to do – </b> <a href="/guide/docs-integration#integration-webhooks-needed-setup">When you have setup the webhook</a> for your test environment, please send us the URL to it
      </td>
      <td>As a response to the validation approved email</td>
    </tr>
    <tr>
      <td></td>
      <td>Credentials for the production API</td>
      <td>
       We will then sign your <code>.csr</code> certificate (certificate signed by Inpay) and you will receive an email attached and information about your <code>X-Auth-Uuid</code>, Authorization <code>Bearer token</code>, virtual account number, business units and instructions to set up your production environment and go live
      </td>
      <td>As a response to receiving the production <code>.csr</code></td>
    </tr>
    <tr>
      <td>6</td>
      <td>Customer App for production</td>
      <td>
        You will get receive an email with a link to set up a password for the <a id="customer-app-link">Customer App</a>. It also explains how to set up multi-factor authentication (MFA). The first user account is the admin, additional users can be added from the portal
      </td>
      <td>After the approved validation, when your production account has been set up according to contract</td>
    </tr>
    <tr>
      <td></td>
      <td>Funding information</td>
      <td>
        We will send you an email with information on how to add funds to your account
      </td>
      <td>After the approved validation, when your production account has been set up according to contract</td>
    </tr>

  </tbody>
</table>

<i>If you find out during the integration project that you need additional features or products, please talk to your Inpay sales contact or let [Onboarding & Support](https://www.inpay.com/contact-us/) know, and they will pass on the message.</i>

<div class="warning">
If your contract contains a hyper care period after going live, this will be arranged directly with your Inpay sales contact, who will engage with Onboarding & Support as needed.
</div>
