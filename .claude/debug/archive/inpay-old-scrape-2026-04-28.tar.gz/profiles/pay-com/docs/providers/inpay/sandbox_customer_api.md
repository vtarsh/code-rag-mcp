# Customer Api Sandbox API

**API version:** v1

> ⚠️ **PATH PREFIX:** All 4 sandbox endpoints carry a leading `/api/` in the swagger but the **public façade strips it**: e.g. `POST /api/sandbox/orders/{uuid}/complete` → public is `POST https://test-api.inpay.com/sandbox/orders/{uuid}/complete`. See `index.md`.

## Servers (internal back-end)

- `https://backend-v2.internal/` — docker
- `http://localhost:3000` — Localhost
- `https://dev-backend-v2.inpay.com/` — DEV server
- `https://uat-backend-v2.inpay.com/` — UAT server
- `https://test-backend-v2.inpay.com/` — TEST server

## Endpoints

## `POST /api/sandbox/fundings/complete`

**Summary:** Simulate an incoming funding event in sandbox to fund the account, enable payment request creation, and test reconciliation behaviour.

**Tags:** Sandbox

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |

### Request body

_Required._

**Content-Type:** `application/json`

- `funding_reference`: string _(required)_ — Funding reference from the funding instructions.
- `debtor_name`: string _(required)_ — Name of the debtor, for example a person or organisation.
- `amount`: string _(required)_ — Amount to fund the account.
- `debtor_account_number`: string _(required)_ — Debtor account identifier, for example an IBAN, local account number, or wallet identifier.

### Responses

#### `200` Success

**Content-Type:** `application/json`

- `success`: boolean _(required)_

#### `400` bad_request

**Content-Type:** `application/json`

- **error_response** (ref)
  - `errors`: array of object _(required)_
    - `title`: string _(required)_
    - `detail`: object _(required)_


---

## `POST /api/sandbox/orders/{uuid}/complete`

**Summary:** Simulate successful completion of a sandbox order to test payin flows and downstream status updates.

**Tags:** Sandbox

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |
| `uuid` | path | string | yes | The unique identifier of the order you want to complete in Sandbox. The order must status pending or authorised, depending on the payment method. |

### Responses

#### `200` Success

**Content-Type:** `application/json`

- `success`: boolean _(required)_

#### `400` no eligible payment to complete

**Content-Type:** `application/json`

- **error_response** (ref)
  - `errors`: array of object _(required)_
    - `title`: string _(required)_
    - `detail`: object _(required)_


---

## `POST /api/sandbox/payment_requests/{inpay_unique_reference}/complete`

**Summary:** Simulate successful completion of a sandbox payment request to test payout processing and completion handling.

**Tags:** Sandbox

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |
| `inpay_unique_reference` | path | string | yes | Inpay-generated unique reference for a payout in processing state. |

### Responses

#### `200` Success

**Content-Type:** `application/json`

- `success`: boolean _(required)_

#### `400` Bad request

**Content-Type:** `application/json`

- **error_response** (ref)
  - `errors`: array of object _(required)_
    - `title`: string _(required)_
    - `detail`: object _(required)_

#### `401` Not Authorized

**Content-Type:** `application/json`

- `errors`: array of object _(required)_
  - `title`: string _(required)_


---

## `POST /api/sandbox/payment_requests/{inpay_unique_reference}/return`

**Summary:** Simulate a returned sandbox payment request to test return handling, status changes, and related payout flows.

**Tags:** Sandbox

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `X-Auth-Uuid` | header | string | yes | Universally unique identifier sent by Inpay |
| `Authorization` | header | string | yes | Bearer [bearer token sent by Inpay] |
| `X-Request-ID` | header | string | yes | Universally unique identifier sent by the Customer |
| `inpay_unique_reference` | path | string | yes | Inpay-generated unique reference for a payout in processing or completed state. |

### Responses

#### `200` Success

**Content-Type:** `application/json`

- `success`: boolean _(required)_

#### `404` Not found

**Content-Type:** `application/json`

- **error_response** (ref)
  - `errors`: array of object _(required)_
    - `title`: string _(required)_
    - `detail`: object _(required)_


---

# Schemas / Definitions

## `error_response`

- `errors`: array of object _(required)_
  - `title`: string _(required)_
  - `detail`: object _(required)_

---
