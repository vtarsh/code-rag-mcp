# Inpay write-side payload vs static swagger asymmetry

**Status:** Captured 2026-04-28 (PI-65 / cdc-pi65). Verified by live SPA bundle + live 422 probe.

## Summary

The static swagger files in `~/.code-rag-mcp/profiles/pay-com/docs/providers/inpay/swagger/*.json` describe ONLY the **read-side** of `/disbursement/payment_requests` (i.e., `GET /disbursement/payment_requests/{ref}`, `GET .../search`). The **write-side** (`POST /disbursement/payment_requests`) is NOT in those swagger files.

The Inpay docs SPA renders the write-side payload schema **client-side** by:
1. Hard-coding the schema definitions in the docs JS bundle (`https://test-app.inpay.com/docs/assets/index-*.js`), or
2. Calling the authenticated customer-app API at runtime (`/customer_app_api/disbursement/.../schema_fields_definition/{schema_id}`).

Per `.claude/rules/inpay-doc-source.md`, MCP RAG is background context only. Authoritative source order:
1. Live Inpay docs site bundle (parse the JS for `payout_product:{id, currency, country}` + `current_schema:{id, name}` + `schema_fields:[...]` + `example: \`...\`` blocks).
2. Live 422 probe of `POST /disbursement/payment_requests`.
3. MCP RAG.

## The asymmetry — 5 confirmed key renames (write vs read)

| Write-side (POST request) | Read-side (GET response & static swagger) |
|---|---|
| `creditor.name` | `creditor.full_name` |
| `creditor.address_lines` | `creditor.address` |
| `creditor.postcode` | `creditor.postal_code` |
| `ultimate_debtor.name` | `ultimate_debtor.full_name` |
| `ultimate_debtor.address_lines` | `ultimate_debtor.address` |
| `ultimate_debtor.postcode` | `ultimate_debtor.postal_code` |

**Evidence:**
- Bundle `rY` block at `https://test-app.inpay.com/docs/assets/index-B6Zupu8u.js` (variable for AUD-AU-LOCAL, product id 394, schema id 5 LOCAL) — `schema_fields[]` lists `creditor.name`, `creditor.address_lines`, `creditor.postcode` as REQUIRED.
- Live 422 from `POST /disbursement/payment_requests` against `test-api.inpay.com` (2026-04-28T18:44:29Z) returned `details:{name:["is missing"]}` for `creditor` and `details:{name, address_lines, postcode}` for `ultimate_debtor` — see `~/work/pay-com/.claude/plans/cdc-pi65/inpay-payout-test-findings.json`.
- Static swagger `customer_app_api.json:323` (component `disbursement_party_identification`) lists `full_name`, `address`, `postal_code` — describes the READ shape only.

## AUD-AU-LOCAL write-side schema (truth source)

Saved to `/Users/vaceslavtarsevskij/work/pay-com/.claude/docs/inpay-write-schema-aud-au-local.json` — full 43-field list with REQ/optional flags, format regex, and the example payload extracted from the bundle.

Required fields (18):
- Top-level: `amount`, `currency_code`, `end_to_end_id`, `local_instrument` (must equal `"LOCAL"`).
- `creditor.{address_lines, city, name, postcode}` (postcode format `^\d{3,4}$`).
- `creditor_account.{account_number (^\d{5,9}$), bank_clearing_system_code (must equal "AUBSB"), country_code}`.
- `debtor.{name}`.
- `debtor_account.{id, scheme_name (must equal "VirtualAccount" — PascalCase)}`.
- `ultimate_debtor.{address_lines, city, country_code, name, postcode (^\d{3,4}$)}`.

Optional fields (25): see source-of-truth dump.

## Path-vs-body case mismatch

URL paths use lowercase `virtual_account` (e.g. `GET /reconciliation/accounts/balance/virtual_account/{id}`), but request body field `debtor_account.scheme_name` uses PascalCase `"VirtualAccount"`. Confirmed in `~/work/pay-com/.claude/plans/cdc-pi65/inpay-api-discovery.md` §"Path-vs-body case mismatch" + bundle example payload.

## Implication for code review

Any payload-builder authored against `disbursement_party_identification` swagger (read-side) will fail at the live validator with `details:{<key>:["is missing"]}` for the renamed keys. This is exactly what happened to `grpc-apm-inpay/libs/payload-builders/corridors/aud-au-local.js` — see header comment lines 5-7 referencing `customer_app_api.json:323-385` and the resulting 422 evidence in `inpay-payout-test.md`.

## Cross-references

- Schema verify report: `~/work/pay-com/.claude/plans/cdc-pi65/inpay-schema-verify-report.md`
- Payout test (live 422 evidence): `~/work/pay-com/.claude/plans/cdc-pi65/inpay-payout-test.md`
- API discovery (other endpoints): `~/work/pay-com/.claude/plans/cdc-pi65/inpay-api-discovery.md`
- Doc-source rule: `~/work/pay-com/.claude/rules/inpay-doc-source.md`
- Write-side schema dump (AUD-AU-LOCAL): `~/work/pay-com/.claude/docs/inpay-write-schema-aud-au-local.json`
- Production code that has the bug today:
  - `grpc-apm-inpay/libs/payload-builders/corridors/aud-au-local.js:91-101` (creditor block + missing ultimate_debtor)
  - `grpc-apm-inpay/libs/map-response.js` (FIXME-DEAD-CODE, response shape mismatch)
  - `grpc-apm-inpay/libs/statuses-map.js` (keys do not match real Inpay states)
- Webhook code that is CORRECT:
  - `workflow-provider-webhooks/activities/inpay/webhook/parse-webhook.js`
  - `workflow-provider-webhooks/activities/inpay/webhook/map-state-to-status.js`

## How to refresh schemas for other corridors

Each `Ln[i]` entry in the bundle (`Ln=[iY,oY,lY,cY,fY,mY,gY,bY,CY,EY,wY,TY]`) is a payout product. Decode by following each variable's `={data:rY}` indirection — `data.schema.payout_product.{id,currency,country}` identifies the product, `data.schema.schema_fields[]` enumerates fields with rules, and `data.example` is the canonical example JSON (template literal in source).

Twelve products embedded today (2026-04-28):
- 394 AUD-AU LOCAL
- 436 EUR-BE SEPA
- 1082 BRL-BR PIX
- 397 CAD-CA LOCAL
- 952 EUR-DE INSTANT-SEPA
- 403 DKK-DK LOCAL
- 529 EUR-ES SEPA
- 370 INR-IN LOCAL
- 406 JPY-JP LOCAL
- 988 EUR-NL INSTANT-SEPA
- 817 NZD-NZ LOCAL
- 514 EUR-PT SEPA
