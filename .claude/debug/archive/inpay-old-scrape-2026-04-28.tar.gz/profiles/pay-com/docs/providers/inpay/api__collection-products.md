Collection Products are represented by the triplet `Payment Method + Debtor Country + Debtor Currency`. For example, `InstantBankTransfer-NL-EUR` represents the capability of collecting payments in Euros, originating from bank accounts in Netherlands via Instant Bank Transfer payment method (Open Banking).

The list below represents the Collection Products that are currently active under your contract. To activate more Collection Products and unlock the full potential of your account, please get in touch with your Inpay Account Manager.
