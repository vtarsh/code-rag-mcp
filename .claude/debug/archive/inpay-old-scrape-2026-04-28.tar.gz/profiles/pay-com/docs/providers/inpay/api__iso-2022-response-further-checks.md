<div class="warning">
Warning: Remember, after receiving the message the API will carry on further checks. You will receive updates about the payment execution progress. Check the possible statuses
</div>
