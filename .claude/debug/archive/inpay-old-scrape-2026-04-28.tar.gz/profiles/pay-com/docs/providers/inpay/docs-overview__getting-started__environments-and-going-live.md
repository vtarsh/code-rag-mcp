You need environments for development, test and production. At Inpay, **we will set up accounts for you** that are separate for test and production.

Most customers will set up a combined environment for development and test, and another environment for production.

### Differences between the test and production environments:

The two environments are fully separated, and you cannot transfer information from one to another – this includes all data, tokens and certificates, that must be a separate set for each environment.

Inpay will from time to time make new functionality available in the test environment ahead of time, i.e., before it appears in the production environment. This will give you a chance to prepare for it, but it also means that you must include a validation and test step in your process for going live, as there could be details to adjust. This final validation will in most cases consist of reading through the production [API reference](/reference/getting-started) for the endpoints your integration is making use of, checking for each that they match the specifications of your application.
