A brief overview of how the Inpay API’s security level works.

`HTTPS` over `TLS` is encrypting the communication package over the Internet with the receiver’s public key, which is obtained from the receiver’s web server through a handshake process. The public key is authorised through a `CA` (Certification Authority), which is a trusted third party that has seen and registered the key before and can confirm that it is the correct key that belongs to the recipient.

When the message is received, the receiver can then decrypt the communication package using their own private key.

`S-MIME` works in a similar way: The sender is encrypting the message with the recipient’s public key, and the receiver decrypting with their private key. This is a different set of keys from those used for the `HTTPS` over `TLS`.

Here, the key may not be authorised by a `CA` but can be authorised locally – when the two parties have exchanged public keys and know that they can trust each other.

Inpay’s API requires the payload of the message (the `JSON` or `XML` but not the `HTTP` headers) to be signed with your private key – later to be verified by Inpay using your public key that we keep with your account.

So, the message is first signed and encrypted through `S-MIME`, then wrapped in a `HTTP` package, encrypted another time through `HTTPS` over `TLS` – when received, first the `HTTPS` over `TLS` is decrypted, then the `S-MIME` message is read from the `HTTP` package and decrypted, and the signature is verified.

The first signing and encryption step and the corresponding decryption and verification in the end is what comprises `PKCS#7`.

To identify the user, Inpay requires an additional `X-Auth-Uuid` and an `Authorization Bearer Token` to be included in each package as `HTTP` headers.

`HTTPS` over `TLS` is usually handled by the communications library you use.

## `X.509` Certificates

`X.509` is a standard defining the format of public key certificates. An `X.509` certificate is used to associate a public key with an identity (like a person or an organisation). This certificate is typically issued by a trusted Certificate Authority (`CA`) and contains information such as:

- The public key
- The identity of the owner (subject)
- The `CA` that issued the certificate (issuer)
- The validity period of the certificate
- The digital signature of the issuer to ensure the certificate's integrity and authenticity

## Certificate Signing Request (`CSR`)

A Certificate Signing Request is a message sent from an applicant to a Certificate Authority to apply for a digital identity certificate.
A `CSR` typically contains the following information:

- The applicant’s public key
- Information about the applicant (e.g., common name, organisation, country)
- An optional password
- A digital signature made with the applicant’s private key to prove ownership of the public key
- The `CSR` is signed by the private key corresponding to the public key in the `CSR`. When the `CA` receives the `CSR`, it validates the information, verifies the applicant's identity, and, if everything checks out, issues an `X.509` certificate.

## `PKCS#7`

`PKCS#7` is a standard for cryptographically signed and encrypted messages. It is used to package certificates and other cryptographic information. `PKCS#7` can be used for:

- Signed data: Ensuring data integrity and authenticity by attaching a digital signature.
- Enveloped data: Encrypting data so that only the intended recipient can decrypt and read it.
- Signed and enveloped data: Both signing and encrypting the data.

## How They Work Together

- Generating a Key Pair: The applicant generates a public-private key pair.
- Creating a `CSR`: The applicant creates a `CSR` using their public key and other identifying information.
- The `CSR` is signed with the private key.
  Submitting the `CSR`: The `CSR` is submitted to a `CA`.
  Issuing an `X.509` Certificate: The `CA` verifies the `CSR` details and the applicant's identity. If approved, the `CA` issues an `X.509` certificate containing the public key and the applicant's information, signed by the `CA`’s private key.
- Using the Certificate:
- Signing Data: The certificate can be used to sign data, creating a digital signature to ensure integrity and authenticity.
- Encrypting Data: The public key in the certificate can be used by others to encrypt data that only the private key holder can decrypt.
- Packaging with `PKCS#7`: Signed or encrypted data can be packaged in a `PKCS#7` structure. This structure can include the `X.509` certificate(s) necessary for verifying signatures and decrypting the data.
