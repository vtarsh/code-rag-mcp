The Sandbox is the test environment, which provides a safe, risk-free space to explore and test our cross-border payments platform. You can:

<ul>
  <li>Use the <a id="customer-app-link">Customer App</a> to simulate payouts, payins and more, exactly as you would in production, without moving real money.</li>
  <li>Integrate with our API to test and validate your technical setup, webhooks, and automation against realistic responses.</li>
</ul>
The sandbox mirrors the production environment closely, making it easy to familiarize yourself with the platform, experiment with payment flows, and ensure your integration is ready before going live.
