Sandbox test cases are isolated test scenarios/flows executed in a controlled environment. The primary purpose of test cases is to provide a risk-free validation layer before integrating to production environment. They allow developers, testers, and business stakeholders to validate system behavior, workflows, and integrations without affecting live data & services.

<div class="hint">
  <p>
    Executing test cases is currently supported only through the <a id="customer-app-link">Customer App</a>
  </p>
</div>
<br />
<div class="warning">
  <p>
    <b>Important</b>: test cases rely on the system already being setup & working for your organisation. If you encounter any issues with the default processing flows or execution of test cases, please get in touch with <a href="mailto:support@inpay.com">support@inpay.com</a>.
  </p>
</div>
