An Instant Bank Transfer Payment tracks a payment attempt when the end user selects Instant Bank Transfer as Payment Method. Hence, an Instant Bank Transfer Payment may go through a set of statuses only relevant to this Payment Method. The meaning of each of such statuses is explained in the table below:

<table class="table mt-3">
<thead>
<tr>
<th>Status</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>CREATED</code></td>
<td>A choice has been made to pay via Instant Bank Transfer.</td>
</tr>
<tr>
<td><code>EXTRA BANK INFO REQUIRED</code></td>
<td><strong>OPTIONAL:</strong> The Bank selected by the end user requires further information to initiate the payment (e.g. debtor's account number). Not all Banks will request additional information hence why this state is optional.</td>
</tr>
<tr>
<td><code>BANK INFO COLLECTED</code></td>
<td>All the info that will need to be sent to the debtor's Bank to initiate the payment has been captured successfully.</td>
</tr>
<tr>
<td><code>CONSENT GIVEN</code></td>
<td>The legal terms and conditions have been accepted by the end user.</td>
</tr>
<tr>
<td><code>EXTERNAL REQUEST CREATED</code></td>
<td>A transient status that keeps track of when the Transfer Request with the Bank was initiated.</td>
</tr>
<tr>
<td><code>EXTERNAL TRANSFER REQUIRED</code></td>
<td><strong>OPTIONAL:</strong> The Bank selected by the end user has not processed the Transfer yet. This can happen with some Banks when delays occur during their processing hence why this state is optional.</td>
</tr>
<tr>
<td><code>REDIRECT TO BANK</code></td>
<td>The debtor's Bank has recorded a Transfer Request in relation to this Instant Bank Transfer Payment and the end user is redirected to his Bank environment in order to confirm it.</td>
</tr>
<tr>
<td><code>REDIRECTED TO INPAY</code></td>
<td>The debtor's Bank has redirected the end user back to the front end application.</td>
</tr>
<tr>
<td><code>BANK PROCESSING</code></td>
<td>The Transfer Request has not reached a final status yet at the debtor's Bank.</td>
</tr>
<tr>
<td><code>USER CANCELLED</code></td>
<td>The end user rejected or abandoned the Transfer Request at the debtor's Bank environment.</td>
</tr>
<tr>
<td><code>BANK AUTHORISED</code></td>
<td>The Transfer Request reaches a final status at the debtor's Bank without errors/failure. This status will make the related Order move to Authorised status.</td>
</tr>
<tr>
<td><code>BANK REJECTED</code></td>
<td>The Transfer Request reaches a final status at the debtor's Bank which is related to errors/failure.</td>
</tr>
<tr>
<td><code>COMPLETED</code></td>
<td>The funds have arrived to an Inpay account. This status will make the related Order move to Processing status.</td>
</tr>
</tbody>
</table>
