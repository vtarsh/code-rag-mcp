When programming the API integration, a fundamental part of it is the security model. In practice, it is a simple process to handle.

Effectively, you need to:

- equip messages with an `X-Request-ID` and look for it in the responses
- sign and encrypt requests
- decrypt and verify responses

Ensure that you have a mechanism for generating a unique `X-Request-ID` for each API request, suggestibly as a `UUID`, which ensures that it will indeed be unique.

The `X-Request-ID` will be present in the direct HTTP responses.

Webhook messages sent from Inpay has they own `X-Request-ID` that is consistent for the same state messaged – meaning that you can check if you already have processed that state for the request.

You need to be able to [sign and encrypt](/reference/getting-started#sign-and-encrypt) a request as well as [decrypt and verify the response](/reference/getting-started#decrypt-and-verify).

<img src="Encryption-and-signing-light.svg" alt="auth diagram"/>
