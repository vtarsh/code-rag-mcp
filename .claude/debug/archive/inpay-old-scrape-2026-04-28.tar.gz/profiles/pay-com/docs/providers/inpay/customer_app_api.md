# Customer APP API

**API version:** v1

> 🚫 **NOT A PUBLIC API.** The entire `/customer_app_api/*` namespace is **inaccessible via the public façade** (`https://{env}-api.inpay.com`). Probed 2026-04-25 against `test-api.inpay.com`: every path 302-redirects to docs. This is the **internal merchant panel** that powers the Inpay self-service web UI; it lives on a different ingress that needs a session cookie obtained via the panel login flow, not the merchant API bearer token. **Do not write integration code against these endpoints.** They are documented here only for completeness.
>
> Side-effect: `/payment_instruments` as a top-level resource only exists inside this namespace, so it is also not callable from public façade. If you need a similar concept for public payouts, look at the per-product schema flow under `pages/api__products.md` instead.

## Servers (internal merchant-panel back-end — not publicly resolvable)

- `https://backend-v2.internal/` — docker
- `http://localhost:3000` — Localhost
- `https://dev-backend-v2.inpay.com/` — DEV server
- `https://uat-backend-v2.inpay.com/` — UAT server
- `https://test-backend-v2.inpay.com/` — TEST server

## Security schemes

### `bearerAuth`

- type: `http`
- scheme: `bearer`
- bearerFormat: `JWT`

## Endpoints

## `POST /customer_app_api/authentication/impersonations/exchange`

**Summary:** Exchange

**Tags:** Customer / Impersonations

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `code`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- **impersonation_exchange_response** (ref)
  - `access_token` → **access_token** _(required)_
    - string [example: `Bearer eyJraWQiOiJodVNwUVhhd0VxeTg1eHBXZEpBWGVhYXNiNzJON0JHeEFmVTEwUzItQ1ZVIiwiYWxnIjoiUlMyNTYifQ.eyJleHAiOjE3NjQyNTA0ODMsImlzcyI6IklucGF5IiwiaWF0IjoxNzY0MjQ2ODg0LCJqdGkiOiI1NDRjYmE4My0xNDk5LTRjZjktYTkxZC1kYmJhYzA4NDgyZDAiLCJ1c2VyIjp7ImlkIjo0OTZ9LCJzY29wZXMiOiJkYXNoYm9hcmQiLCJpbXBlcnNvbmF0aW5nIjpmYWxzZX0.qtWlQX767YuuM8s2TxZBfmZN2R1Jgkdj4yyddo6lgu6Ums6psfs0F6tOOc9D5tyr6TAbcZz3-uA4z_r7Gm72dyMrJlZbs4yCRQ8nk0PAFlmHD0pC1U20NFsQefF9F3SvkRShqVRUyDY9pK2URCp7WnxV08jNR1xaE6zI4WaC4KGWuzyYjQmkSqLJDywOlcRVOjWhbpjeI6pkEtjNBOFeuJ15cixlqyAPDXtH-G9KpyS7w6Xs6cIMNen8FOMEN8p-vzZZlbKH-kvaZujhWTMtsMq2lxgM-MykgrvwGZRquRvPC4NKnPuXaMenAtvSg8aeBgm3HT__3eBM1Q0Q-Fx1bmrfZUd4pRPz_bpCQlNgo_bkW8jRjnl7ZtLdLWJnQfO7Ms08l2ZQKn7xXDxhh_uISuxn7mWmcqytUTLmT1NpDNGjqYFzc_oGOYBQ1TAdGKEbl3gvyZbcmOhgtWeDxCnu3Ox0gwBwijPlCUUYyF_bHToOvOuPg47W8Db-pZw7XiE62334kDulNl30wmz_IttV10TUMbWRKbbEM3tb6SczfzUNCHR6dQb_GO8QTTfCj4X7X_DwaNoB6tjbEaAD7OxZyPq7UEigWLc90oIi7W6Re_d3jt7lq12RUPWWm46ierO7tcSlLAjJsTjLGSXre1jlGX_0IqIqGSOStb6UIlPjudA`]

#### `422` Grant already used

**Content-Type:** `application/json`

- **impersonation_grant_error_response** (ref)
  - `error`: string _(required)_


---

## `POST /customer_app_api/authentication/mfa/request_sms`

**Summary:** Request SMS

**Tags:** MFA

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Responses

#### `200` SMS requested successfully

**Content-Type:** `application/json`

- `message`: string

#### `422` SMS request failed

**Content-Type:** `application/json`

- `error`: string


---

## `POST /customer_app_api/authentication/mfa/verify_sms`

**Summary:** Verify SMS

**Tags:** MFA

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Request body

**Content-Type:** `application/json`

- `auth_payload`: string _(required)_

### Responses

#### `200` SMS verified successfully

**Content-Type:** `application/json`

- `data`: object
  - `access_token`: string
  - `refresh_token`: string

#### `422` SMS verification failed

**Content-Type:** `application/json`

- `error`: string


---

## `GET /customer_app_api/authentication/mfa/request_totp_factor`

**Summary:** Request TOTP Factor

**Tags:** MFA

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Responses

#### `200` MFA registration successful

**Content-Type:** `application/json`

- `data`: string

#### `401` Should not be able to set mfa is configured and token is of level login

**Content-Type:** `application/json`

- `error`: string

#### `422` User already has verify setup

**Content-Type:** `application/json`

- `error`: string


---

## `POST /customer_app_api/authentication/mfa/validate_totp_factor`

**Summary:** Validate TOTP factor

**Tags:** MFA

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Request body

**Content-Type:** `application/json`

- `auth_payload`: string _(required)_

### Responses

#### `200` TOTP factor validated successfully

**Content-Type:** `application/json`

- `data`: object
  - `access_token`: string
  - `refresh_token`: string

#### `422` Twilio error

**Content-Type:** `application/json`

- `error`: string


---

## `POST /customer_app_api/authentication/mfa/verify_totp_factor`

**Summary:** Verify TOTP factor

**Tags:** MFA

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Request body

**Content-Type:** `application/json`

- `auth_payload`: string _(required)_

### Responses

#### `200` TOTP factor verified successfully

**Content-Type:** `application/json`

- `data`: object
  - `access_token`: string
  - `refresh_token`: string

#### `422` Verification failed

**Content-Type:** `application/json`

- `error`: string


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/funding_instructions`

**Summary:** Index funding instructions

**Tags:** Collection / Funding instructions

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful [v2 account fundings]

**Content-Type:** `application/json`

- `data` → **funding_configurations**
  - `virtual_account_number`: array of **funding_configuration**
    - **funding_configuration** (ref)
      - `changed`: boolean _(required)_ — states whether or not the instructions have been updated in admin
      - `uuid` → **uuid** _(required)_
      - `funding_reference`: string _(required)_ — Typically account number, but can be custom
      - `virtual_account_number` → **virtual_account_number** _(required)_
      - `currency_iso` → **currency_iso** _(required)_
      - `beneficiary` → **funding_configuration_beneficiary**


---

## `PUT /customer_app_api/collection/organisations/{organisation_id}/funding_instructions/{account_number}/accept_changes`

**Summary:** Accept funding updates

**Tags:** Collection / Funding instructions

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `account_number` | path | integer | yes | Account number of the funding instructions |

### Request body

_Required._

**Content-Type:** `application/json`

- `configuration_uuid`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **accepted_funding_configuration**
  - `banking_rail_id`: number
  - `currency_iso` → **currency_iso**
    - string [example: `EUR`] — Currency ISO code
  - `email`: string
  - `funding_reference`: string — account number or custom
  - `inpay_bank_account_id`: number
  - `organisation_id` → **organisation_id**
    - integer [example: `1`]
  - `owner_name`: string
  - `provider_inpay_bank_account_id`: number
  - `uuid` → **uuid**
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `virtual_account_number` → **virtual_account_number**
    - string [example: `29301655053`] — virtual account number

#### `422` Bad uuid

**Content-Type:** `application/json`

- `error` → **validation_error_invalid_uuid**
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `uuid`: array of string


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/orders/{uuid}`

**Summary:** Show Order

**Tags:** Collection / Orders

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Order UUID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **collection_order_find_one**
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `reference` → **reference** _(required)_
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `debtor` → **debtor** _(required)_
    - `email` → **email**
      - string [example: `johndoe@inpay.com`]
    - `full_name` → **full_name**
      - string [example: `John Doe`]
    - `date_of_birth`: string
    - `country_of_residence` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `status` → **status** _(required)_
    - string [example: `received`] — Status
  - `business_unit`: string _(required)_
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `payments`: array of **collection_order_payment_item** _(required)_
    - **collection_order_payment_item** (ref)
      - `uuid` → **uuid** _(required)_
      - `status` → **collection_payment_status** _(required)_
      - `type` → **collection_payment_type** _(required)_
      - `inpay_unique_reference` → **inpay_unique_reference** _(required)_
      - `created_at` → **created_at** _(required)_
  - `status_history`: array of **collection_status_history_item** _(required)_
    - **collection_status_history_item** (ref)
      - `status`: string _(required)_
      - `created_at`: string _(required)_
  - `refunds`: array of **collection_order_refund_item**
    - **collection_order_refund_item** (ref)
      - `amount`: string _(required)_
      - `category`: string _(required)_
      - `currency_iso`: string _(required)_
      - `status` → **collection_refund_status** _(required)_
      - `uuid`: number _(required)_
      - `organisation_id`: number _(required)_
      - `end_to_end_id`: string _(required)_
      - `full_refund`: boolean _(required)_
      - `created_at`: string _(required)_
  - `reason_codes`: array of **collection_order_reason_codes_item** _(required)_
    - **collection_order_reason_codes_item** (ref)
      - `kind`: string _(required)_ _enum: ['collection']_
      - `group`: string _(required)_ _enum: ['action_required_for_refund', 'action_required', 'refund_requested', 'order_cancelled']_
      - `reason`: string _(required)_
      - `external_message`: string _(required)_
      - `symbol`: string _(required)_


---

## `DELETE /customer_app_api/collection/organisations/{organisation_id}/orders/{uuid}`

**Summary:** Delete Order

**Tags:** Collection / Orders

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Uuid |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **cancel_order_return_type**
  - `status` → **ok_status** _(required)_
    - string [example: `ok`]

#### `422` Unprocessable Entity

**Content-Type:** `application/json`

- **error_response** (ref)
  - `error` → **validation_error_invalid_uuid** _(required)_
    - `code`: integer _(required)_ — error code from engine
    - `title`: string _(required)_
    - `details`: object _(required)_
      - `uuid`: array of string

#### `401` Unprocessable Entity

**Content-Type:** `application/json`

- **no_organisation_membership_error** (ref)
  - `errors`: array of **no_organisation_membership_errors_item** _(required)_
    - **no_organisation_membership_errors_item** (ref)
      - `title`: string _(required)_
      - `details`: array of string _(required)_


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/orders/find_by_uuid_or_inpay_external_reference`

**Summary:** Find Order By Uuid or Inpay External Reference

**Tags:** Collection / Orders

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `search_reference` | query | string | yes | Search reference / Order UUID |
| `start_date` | query | string | yes | Start Date |
| `end_date` | query | string | yes | End Date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **order**
  - `uuid` → **uuid**
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `reference`: string — A unique identifier in your system for this Order
  - `debtor` → **debtor**
    - `email` → **email**
      - string [example: `johndoe@inpay.com`]
    - `full_name` → **full_name**
      - string [example: `John Doe`]
    - `date_of_birth`: string
    - `country_of_residence` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `status`: string — Status of your order
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `amount_cents`: integer — Original amount in cents
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `virtual_account_number` → **debtor_account_number**
    - string [example: `29301655053`] — Debtor account number


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/orders`

**Summary:** Index Orders

**Tags:** Collection / Orders

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `created_after` | query | string | no | Filter by date |
| `created_before` | query | string | no | Filter by date |
| `status` | query | string | no | Find by status category |
| `virtual_account_number` | query | string | no | Find by virtual account number |
| `meta[cursor_after]` | query | string | no | Cursor after |
| `meta[cursor_before]` | query | string | no | Cursor before |
| `meta[sort]` | query | string | no | Sort param. Sort by -date is default |
| `meta[plain_cursor]` | query | string | no | Plain cursor |
| `meta[include_cursor]` | query | boolean | no | Include cursor |
| `meta[page_size]` | query | integer | no | Page size |
| `meta[page_size_default]` | query | integer | no | Default page size |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **order**
  - **order** (ref)
    - `uuid` → **uuid**
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `reference`: string — A unique identifier in your system for this Order
    - `debtor` → **debtor**
      - `email` → **email**
      - `full_name` → **full_name**
      - `date_of_birth`: string
      - `country_of_residence` → **country_iso**
      - `created_at` → **created_at**
    - `status`: string — Status of your order
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `amount_cents`: integer — Original amount in cents
    - `currency_code` → **currency_code**
      - string [example: `EUR`]
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `virtual_account_number` → **debtor_account_number**
      - string [example: `29301655053`] — Debtor account number
- `meta` → **orders_index_pagination**
  - `cursor_before`: string — Next page
  - `cursor_after`: string — Next page
  - `total`: integer — Total number of items
  - `has_orders`: boolean — Has orders


---

## `POST /customer_app_api/collection/organisations/{organisation_id}/orders/{uuid}/refund`

**Summary:** Create Order Refund

**Tags:** Collection / Orders

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Order UUID |

### Request body

_Required._

**Content-Type:** `application/json`

- `amount`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **success**
  - `success`: boolean — Successful operation response

#### `422` Configuration Error: Contracted Product

**Content-Type:** `application/json`

- `error` → **refund_not_configured_error**
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/payments/find_by_uuid_or_inpay_unique_reference`

**Summary:** Find Payment By Uuid or Inpay Unique Reference

**Tags:** Collection / Payments

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `search_reference` | query | string | yes | Search reference / Payment UUID |
| `start_date` | query | string | yes | Start Date |
| `end_date` | query | string | yes | End Date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **collection_payment_find_by_uuid_or_reference**
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `status` → **collection_payment_status** _(required)_
    - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
  - `type` → **collection_payment_type** _(required)_
    - string [enum: ['bank_transfer', 'instant_bank_transfer']]
  - `inpay_unique_reference` → **inpay_unique_reference** _(required)_
    - string [example: `d1a2b3c4d5`] — Our unique reference
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `order` → **collection_order_from_payment** _(required)_
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `reference`: string _(required)_ — A unique identifier in your system for this Order
    - `debtor` → **debtor** _(required)_
      - `email` → **email**
      - `full_name` → **full_name**
      - `date_of_birth`: string
      - `country_of_residence` → **country_iso**
      - `created_at` → **created_at**
    - `status`: string _(required)_ — Status of your order
    - `amount` → **amount** _(required)_
      - string [example: `100.0`] — amount
    - `amount_cents`: integer _(required)_ — Original amount in cents
    - `currency` → **currency_code** _(required)_
      - string [example: `EUR`]
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/payments/{uuid}`

**Summary:** Show Payment

**Tags:** Collection / Payments

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Payment UUID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **collection_payment_find_one**
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `status` → **collection_payment_status** _(required)_
    - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
  - `type` → **collection_payment_type** _(required)_
    - string [enum: ['bank_transfer', 'instant_bank_transfer']]
  - `inpay_unique_reference` → **inpay_unique_reference** _(required)_
    - string [example: `d1a2b3c4d5`] — Our unique reference
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `order` → **collection_order_from_payment** _(required)_
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `reference`: string _(required)_ — A unique identifier in your system for this Order
    - `debtor` → **debtor** _(required)_
      - `email` → **email**
      - `full_name` → **full_name**
      - `date_of_birth`: string
      - `country_of_residence` → **country_iso**
      - `created_at` → **created_at**
    - `status`: string _(required)_ — Status of your order
    - `amount` → **amount** _(required)_
      - string [example: `100.0`] — amount
    - `amount_cents`: integer _(required)_ — Original amount in cents
    - `currency` → **currency_code** _(required)_
      - string [example: `EUR`]
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `details` → **collection_payment_details**
    - `debtor_country`: string
    - `debtor_bank_name`: string
  - `status_history`: array of **collection_status_history_item**
    - **collection_status_history_item** (ref)
      - `status`: string _(required)_
      - `created_at`: string _(required)_


---

## `GET /customer_app_api/collection/organisations/{organisation_id}/stats/orders/status_counts_reports`

**Summary:** Get Status Counts Reports

**Tags:** Collection / Payments

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `created_after` | query | string | yes | Filter by date |
| `created_before` | query | string | no | Filter by date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **collection_count_status_reports_data_item**
  - **collection_count_status_reports_data_item** (ref)
    - `code`: string _(required)_
    - `name`: string _(required)_
    - `count`: integer _(required)_
    - `items`: array of **collection_count_status_reports_data_item_reason_code**
      - **collection_count_status_reports_data_item_reason_code** (ref)
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `id`: integer _(required)_
- `count`: integer


---

## `GET /customer_app_api/core/countries`

**Summary:** Index Countries

**Tags:** Core / Countries

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of object _(required)_
  - `id`: integer _(required)_
  - `iso`: string _(required)_
  - `name`: string _(required)_

#### `422` Unprocessable Entity

**Content-Type:** `application/json`

- `error`: object _(required)_
  - `code`: integer _(required)_
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/layer1/exchange_rates`

**Summary:** Get exchange rate quote

**Tags:** Crypto / Layer1

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `pair` | query | string | yes | Currency pair, e.g. USDC_EUR |
| `network` | query | string | yes | Network, e.g. ETHEREUM |
| `amount` | query | string | yes | Amount of crypto to exchange |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `quote_price`: string
- `vwap`: string
- `proceeds`: string
- `total_available_depth`: string
- `max_amount`: string
- `transaction_fee`: string
- `fetched_at`: integer
- `expiry_at`: integer
- `proceeds_after_fx_markup`: string
- `fx_markup`: string

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/bigedirect/token`

**Summary:** Get token by organisation with token

**Tags:** Crypto / BigeDirect

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `virtual_account_number` | query | string | yes | Virtual account number |

### Responses

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of any
  - `title`: string

#### `200` Successful

**Content-Type:** `application/json`

- `data`: string

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`: object
  - `code`: integer
  - `title`: string
  - `details`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/c2c/token`

**Summary:** Get token by organisation with token

**Tags:** Crypto / C2C

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `virtual_account_number` | query | string | yes | Virtual account number |

### Responses

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of any
  - `title`: string

#### `200` Successful

**Content-Type:** `application/json`

- `data`: string

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`: object
  - `code`: integer
  - `title`: string
  - `details`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/layer1/addresses`

**Summary:** Get Layer1 addresses

**Tags:** Crypto / Layer1

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `page_number` | query | integer | no | Page number for pagination |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `content`: array of object
  - `id`: string
  - `address`: string
  - `assetPoolId`: string
  - `network`: string
  - `keyPairId`: string
  - `reference`: string
  - `supportedAssets`: array of string
  - `customerId`: string
  - `master`: boolean
- `pageable`: object
  - `pageNumber`: integer
  - `pageSize`: integer
- `hasNext`: boolean

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/layer1/addresses/{address_id}`

**Summary:** Get Layer1 address

**Tags:** Crypto / Layer1

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `address_id` | path | string | yes | Address ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `id`: string
- `address`: string
- `assetPoolId`: string
- `network`: string
- `keyPairId`: string
- `reference`: string
- `supportedAssets`: array of string
- `balances`: array of object
  - `asset`: string
  - `available`: string
  - `reserved`: string
  - `blockchain`: string
- `customerId`: string
- `master`: boolean
- `createdAt`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/layer1/balances`

**Summary:** Get ledger balances per asset

**Tags:** Crypto / Layer1

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: object
  - `balances`: array of object
    - `asset`: string
    - `balance`: integer
    - `formatted_balance`: string
  - `balances_by_network`: array of object
    - `asset`: string
    - `network`: string
    - `balance`: integer
    - `formatted_balance`: string


---

## `GET /customer_app_api/crypto/organisations/{organisation_id}/layer1/deposits`

**Summary:** Get Layer1 deposit events grouped by transaction

**Tags:** Crypto / Layer1

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `cursor` | query | string | no | Pagination cursor returned from a previous request |
| `per_page` | query | integer | no | Number of results per page |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of object
  - `id`: integer
  - `layer1_deposit_id`: string
  - `data_digest`: string
  - `status`: string _(required)_
  - `asset`: string _(required)_
  - `amount`: integer _(required)_
  - `formatted_amount`: string
  - `network`: string _(required)_
  - `deposit_address`: string _(required)_
  - `from_address`: string _(required)_
  - `sources`: array of object
    - `address`: string
    - `amount`: string
  - `layer1_customer_id`: string
  - `organisation_id`: integer
  - `reference`: string
  - `tx_hash`: string _(required)_
  - `failure_reason`: string
  - `failure_message`: string
  - `layer1_created_at`: string _(required)_
  - `layer1_updated_at`: string
  - `received_webhook_id`: integer
  - `created_at`: string
  - `updated_at`: string
  - `status_history`: array of object
    - `status`: string
    - `timestamp`: string
- `meta`: object
  - `per_page`: integer
  - `total_pages`: integer
  - `next_cursor`: string

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`: object
  - `title`: string
  - `details`: string


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/address`

**Summary:** Customer Organisation Address

**Tags:** Customer / Address

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **address**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `line1`: string — Line 1 of the organisation address
  - `line2`: string — Line 2 of the organisation address
  - `city`: string — City
  - `state`: string — State
  - `postal_code`: string — Postal code
  - `country`: object
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `iso`: string — Country ISO code
    - `name`: string — Country name
  - `organisation_name`: string — Name of the organisation


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/business_units`

**Summary:** Index business units

**Tags:** Customer / Business units

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **business_unit**
  - **business_unit** (ref)
    - `id`: integer _(required)_
    - `name`: string _(required)_
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/configurations`

**Summary:** Index Configurations

**Tags:** Customer / Configurations

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **configuration**
  - `throttling`: string — Irrelevant
  - `batch_number_of_approvers`: string — Number
  - `manual_payout_number_of_approvers`: string — Number
  - `virtual_bank_bookkeeping`: string — v1 / v2 / dual
  - `withdrawals_enabled`: string — Either on/off
  - `fx_rate_end_point`: string — Irrelevant
  - `manual_payouts_enabled`: string — 1 if turned on
  - `batches_enabled`: string — Either on/off
  - `fx_widget_enabled`: string — Either on/off
  - `crypto_widget_variant`: string — c2c / bigedirect / layer 1
  - `customer_ab_testing`: string — Either on/off


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/contracted_products`

**Summary:** Get contracted products organisation

**Tags:** Customer / Products

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `meta`: object
  - `collection_products_count`: integer
  - `payout_products_count`: integer
- `data`: object
  - `payout_products`: array of **customer_app_contracted_products**
    - **customer_app_contracted_products** (ref)
      - `id`: integer — ID
      - `product_id`: integer — Product Id
      - `product_currency_iso`: string — Currency of the product
  - `collection_products`: array of **customer_app_contracted_products**
    - **customer_app_contracted_products** (ref)
      - `id`: integer — ID
      - `product_id`: integer — Product Id
      - `product_currency_iso`: string — Currency of the product


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/creditors/{id}`

**Summary:** Show Creditor

**Tags:** Customer / Creditors

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `id` | path | integer | yes | Creditor Id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **creditor_with_details**
  - `id`: integer _(required)_
  - `address_lines` → **creditor_address_lines**
    - string [example: `Toldbodgade 55`]
  - `birthdate` → **creditor_birthdate**
    - string (date) [example: `1990-01-01`]
  - `city` → **creditor_city**
    - string [example: `Roskilde`]
  - `country_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_birth_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_residence_code` → **creditor_country_code**
    - string [example: `DK`]
  - `created_by` → **creditor_created_by** _(required)_
    - string [example: `John Doe`]
  - `creditor_type` → **creditor_type**
    - string [enum: ['organization', 'private'], example: `private`] — Account holder type
  - `email` → **creditor_email**
    - string [example: `museum@kff.kk.dk`]
  - `full_name` → **creditor_full_name**
    - string [example: `John Doe`]
  - `id_expiry_date` → **id_expiry_date**
    - string [example: `2030-05-22`]
  - `id_issuing_country_code` → **id_issuing_country_code**
    - string [example: `DK`]
  - `id_issuing_date` → **id_issuing_date**
    - string [example: `2020-05-22`]
  - `id_number` → **id_number**
    - string [example: `1234567`]
  - `id_type` → **id_type**
    - string [example: `Passport`]
  - `mobile_number` → **creditor_mobile_number**
    - string [example: `+4533210772`]
  - `postcode` → **creditor_postcode**
    - string [example: `2200`]
  - `state` → **state**
    - string [example: `CA`]
  - `street_name` → **street_name**
    - string [example: `5181 MacGyver Thunder`]
  - `product_id` → **creditor_product_id**
    - integer [example: `397`]
  - `schema_id` → **creditor_schema_id**
    - integer [example: `107`]
  - `creditor_details`: array of **creditor_key_value_pair** _(required)_
    - **creditor_key_value_pair** (ref)
      - `key`: string _(required)_
      - `value`: string _(required)_


---

## `DELETE /customer_app_api/customer/organisations/{organisation_id}/creditors/{id}`

**Summary:** Delete Creditor

**Tags:** Customer / Creditors

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `id` | path | integer | yes | Creditor Id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **creditor_with_details**
  - `id`: integer _(required)_
  - `address_lines` → **creditor_address_lines**
    - string [example: `Toldbodgade 55`]
  - `birthdate` → **creditor_birthdate**
    - string (date) [example: `1990-01-01`]
  - `city` → **creditor_city**
    - string [example: `Roskilde`]
  - `country_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_birth_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_residence_code` → **creditor_country_code**
    - string [example: `DK`]
  - `created_by` → **creditor_created_by** _(required)_
    - string [example: `John Doe`]
  - `creditor_type` → **creditor_type**
    - string [enum: ['organization', 'private'], example: `private`] — Account holder type
  - `email` → **creditor_email**
    - string [example: `museum@kff.kk.dk`]
  - `full_name` → **creditor_full_name**
    - string [example: `John Doe`]
  - `id_expiry_date` → **id_expiry_date**
    - string [example: `2030-05-22`]
  - `id_issuing_country_code` → **id_issuing_country_code**
    - string [example: `DK`]
  - `id_issuing_date` → **id_issuing_date**
    - string [example: `2020-05-22`]
  - `id_number` → **id_number**
    - string [example: `1234567`]
  - `id_type` → **id_type**
    - string [example: `Passport`]
  - `mobile_number` → **creditor_mobile_number**
    - string [example: `+4533210772`]
  - `postcode` → **creditor_postcode**
    - string [example: `2200`]
  - `state` → **state**
    - string [example: `CA`]
  - `street_name` → **street_name**
    - string [example: `5181 MacGyver Thunder`]
  - `product_id` → **creditor_product_id**
    - integer [example: `397`]
  - `schema_id` → **creditor_schema_id**
    - integer [example: `107`]
  - `creditor_details`: array of **creditor_key_value_pair** _(required)_
    - **creditor_key_value_pair** (ref)
      - `key`: string _(required)_
      - `value`: string _(required)_


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/creditors`

**Summary:** Index Creditors

**Tags:** Customer / Creditors

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `product_id` | query | integer | no | Product ID |
| `schema_id` | query | integer | no | Schema ID |
| `cursor_next` | query | string | no | Cursor next |
| `cursor_prev` | query | string | no | Cursor prev |
| `sort` | query | string | no | Sort param. Sort by -date is default |
| `page_size` | query | string | no | Page size |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **creditor_with_details**
  - **creditor_with_details** (ref)
    - `id`: integer _(required)_
    - `address_lines` → **creditor_address_lines**
      - string [example: `Toldbodgade 55`]
    - `birthdate` → **creditor_birthdate**
      - string (date) [example: `1990-01-01`]
    - `city` → **creditor_city**
      - string [example: `Roskilde`]
    - `country_code` → **creditor_country_code**
      - string [example: `DK`]
    - `country_of_birth_code` → **creditor_country_code**
      - string [example: `DK`]
    - `country_of_residence_code` → **creditor_country_code**
      - string [example: `DK`]
    - `created_by` → **creditor_created_by** _(required)_
      - string [example: `John Doe`]
    - `creditor_type` → **creditor_type**
      - string [enum: ['organization', 'private'], example: `private`] — Account holder type
    - `email` → **creditor_email**
      - string [example: `museum@kff.kk.dk`]
    - `full_name` → **creditor_full_name**
      - string [example: `John Doe`]
    - `id_expiry_date` → **id_expiry_date**
      - string [example: `2030-05-22`]
    - `id_issuing_country_code` → **id_issuing_country_code**
      - string [example: `DK`]
    - `id_issuing_date` → **id_issuing_date**
      - string [example: `2020-05-22`]
    - `id_number` → **id_number**
      - string [example: `1234567`]
    - `id_type` → **id_type**
      - string [example: `Passport`]
    - `mobile_number` → **creditor_mobile_number**
      - string [example: `+4533210772`]
    - `postcode` → **creditor_postcode**
      - string [example: `2200`]
    - `state` → **state**
      - string [example: `CA`]
    - `street_name` → **street_name**
      - string [example: `5181 MacGyver Thunder`]
    - `product_id` → **creditor_product_id**
      - integer [example: `397`]
    - `schema_id` → **creditor_schema_id**
      - integer [example: `107`]
    - `creditor_details`: array of **creditor_key_value_pair** _(required)_
      - **creditor_key_value_pair** (ref)
        - `key`: string _(required)_
        - `value`: string _(required)_
- `meta` → **pagination**
  - `cursor_next`: integer — Next page
  - `cursor_prev`: integer — Previous page
  - `has_next_page`: boolean — Has next page
  - `has_prev_page`: boolean — Has prev page
  - `total`: integer — Total number of items


---

## `POST /customer_app_api/customer/organisations/{organisation_id}/creditors`

**Summary:** Create Creditor

**Tags:** Customer / Creditors

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `creditor`: object
  - `address_lines` → **creditor_address_lines**
    - string [example: `Toldbodgade 55`]
  - `birthdate` → **creditor_birthdate**
    - string (date) [example: `1990-01-01`]
  - `city` → **creditor_city**
    - string [example: `Roskilde`]
  - `country_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_birth_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_residence_code` → **creditor_country_code**
    - string [example: `DK`]
  - `creditor_type` → **creditor_type**
    - string [enum: ['organization', 'private'], example: `private`] — Account holder type
  - `email` → **creditor_email**
    - string [example: `museum@kff.kk.dk`]
  - `full_name` → **creditor_full_name**
    - string [example: `John Doe`]
  - `id_expiry_date` → **id_expiry_date**
    - string [example: `2030-05-22`]
  - `id_issuing_country_code` → **id_issuing_country_code**
    - string [example: `DK`]
  - `id_issuing_date` → **id_issuing_date**
    - string [example: `2020-05-22`]
  - `id_number` → **id_number**
    - string [example: `1234567`]
  - `id_type` → **id_type**
    - string [example: `Passport`]
  - `mobile_number` → **creditor_mobile_number**
    - string [example: `+4533210772`]
  - `postcode` → **creditor_postcode**
    - string [example: `2200`]
  - `state` → **state**
    - string [example: `CA`]
  - `street_name` → **street_name**
    - string [example: `5181 MacGyver Thunder`]
  - `product_id` → **creditor_product_id**
    - integer [example: `397`]
  - `schema_id` → **creditor_schema_id**
    - integer [example: `107`]
  - `creditor_details`: array of **creditor_key_value_pair**
    - **creditor_key_value_pair** (ref)
      - `key`: string _(required)_
      - `value`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **creditor_with_details**
  - `id`: integer _(required)_
  - `address_lines` → **creditor_address_lines**
    - string [example: `Toldbodgade 55`]
  - `birthdate` → **creditor_birthdate**
    - string (date) [example: `1990-01-01`]
  - `city` → **creditor_city**
    - string [example: `Roskilde`]
  - `country_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_birth_code` → **creditor_country_code**
    - string [example: `DK`]
  - `country_of_residence_code` → **creditor_country_code**
    - string [example: `DK`]
  - `created_by` → **creditor_created_by** _(required)_
    - string [example: `John Doe`]
  - `creditor_type` → **creditor_type**
    - string [enum: ['organization', 'private'], example: `private`] — Account holder type
  - `email` → **creditor_email**
    - string [example: `museum@kff.kk.dk`]
  - `full_name` → **creditor_full_name**
    - string [example: `John Doe`]
  - `id_expiry_date` → **id_expiry_date**
    - string [example: `2030-05-22`]
  - `id_issuing_country_code` → **id_issuing_country_code**
    - string [example: `DK`]
  - `id_issuing_date` → **id_issuing_date**
    - string [example: `2020-05-22`]
  - `id_number` → **id_number**
    - string [example: `1234567`]
  - `id_type` → **id_type**
    - string [example: `Passport`]
  - `mobile_number` → **creditor_mobile_number**
    - string [example: `+4533210772`]
  - `postcode` → **creditor_postcode**
    - string [example: `2200`]
  - `state` → **state**
    - string [example: `CA`]
  - `street_name` → **street_name**
    - string [example: `5181 MacGyver Thunder`]
  - `product_id` → **creditor_product_id**
    - integer [example: `397`]
  - `schema_id` → **creditor_schema_id**
    - integer [example: `107`]
  - `creditor_details`: array of **creditor_key_value_pair** _(required)_
    - **creditor_key_value_pair** (ref)
      - `key`: string _(required)_
      - `value`: string _(required)_


---

## `GET /customer_app_api/customer/organisations`

**Summary:** Index Organisations

**Tags:** Customer / Organisations

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `organisations`: array of **customer_user_organisation** _(required)_
  - **customer_user_organisation** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `name`: string _(required)_ — organisation name
    - `ordering_institution`: string _(required)_ — Public facing organisation name
    - `default`: boolean _(required)_ — true means automatically chosen as active when initially logging on
    - `role` → **role_name** _(required)_
      - string [example: `admin`] — admin, operations member or reviewer


---

## `POST /customer_app_api/customer/organisations/{id}/set_default`

**Summary:** Set Default Organisation

**Tags:** Customer / Set Default organisation

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `id` | path | integer | yes | Organisation ID |

### Responses

#### `200` No Content

#### `422` Unauthorized


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/roles`

**Summary:** Index roles

**Tags:** Customer / Roles

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **role**
  - **role** (ref)
    - `name` → **role_name** _(required)_
      - string [example: `admin`] — admin, operations member or reviewer
    - `description`: string — optional description


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/users`

**Summary:** Index users

**Tags:** Customer / Users

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **user_item**
  - **user_item** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `email`: string _(required)_
    - `first_name`: string _(required)_
    - `last_name`: string _(required)_
    - `active`: boolean _(required)_ — inactive means removed from organisation
    - `role` → **role_name** _(required)_
      - string [example: `admin`] — admin, operations member or reviewer
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `updated_at` → **updated_at** _(required)_
      - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of **users_not_authorized**
  - **users_not_authorized** (ref)
    - `title`: string _(required)_


---

## `POST /customer_app_api/customer/organisations/{organisation_id}/users`

**Summary:** Create user

**Tags:** Customer / Users

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `data`: object
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `email`: string _(required)_
  - `role`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **user**
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `email`: string _(required)_
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `role` → **role_name** _(required)_
    - string [example: `admin`] — admin, operations member or reviewer
  - `active`: boolean _(required)_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **updated_at** _(required)_
    - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

#### `422` Validation error

**Content-Type:** `application/json`

- `data` → **user_validation_error**
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details` → **user_validation_attributes** _(required)_
    - `first_name`: array of string _(required)_
    - `last_name`: array of string _(required)_
    - `email`: array of string _(required)_
    - `active`: array of string _(required)_
    - `role`: array of string _(required)_

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of **users_not_authorized**
  - **users_not_authorized** (ref)
    - `title`: string _(required)_


---

## `GET /customer_app_api/customer/organisations/{organisation_id}/users/{user_id}`

**Summary:** Get user

**Tags:** Customer / Users

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `user_id` | path | integer | yes | User Id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **user**
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `email`: string _(required)_
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `role` → **role_name** _(required)_
    - string [example: `admin`] — admin, operations member or reviewer
  - `active`: boolean _(required)_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **updated_at** _(required)_
    - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of **users_not_authorized**
  - **users_not_authorized** (ref)
    - `title`: string _(required)_


---

## `PUT /customer_app_api/customer/organisations/{organisation_id}/users/{user_id}`

**Summary:** Update user

**Tags:** Customer / Users

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `user_id` | path | integer | yes | User Id |

### Request body

_Required._

**Content-Type:** `application/json`

- `data`: object
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `email`: string _(required)_
  - `role`: string
  - `active`: boolean

### Responses

#### `200` Successful (admin updates another user: role & active updated)

**Content-Type:** `application/json`

- `data` → **user**
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `email`: string _(required)_
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `role` → **role_name** _(required)_
    - string [example: `admin`] — admin, operations member or reviewer
  - `active`: boolean _(required)_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **updated_at** _(required)_
    - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

#### `422` Validation error

**Content-Type:** `application/json`

- `errors` → **user_validation_error**
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details` → **user_validation_attributes** _(required)_
    - `first_name`: array of string _(required)_
    - `last_name`: array of string _(required)_
    - `email`: array of string _(required)_
    - `active`: array of string _(required)_
    - `role`: array of string _(required)_

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors` → **unauthorized_error**
  - array, items:
    - `title`: string _(required)_


---

## `GET /customer_app_api/customer/current_user`

**Summary:** Get current user

**Tags:** Customer / Users

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `user`: object
  - `id`: integer _(required)_
  - `email`: string _(required)_
  - `first_name`: string _(required)_
  - `last_name`: string _(required)_
  - `mfa_enabled`: boolean _(required)_
  - `mfa_configured`: boolean _(required)_
  - `skip_mfa`: boolean _(required)_
  - `has_verify_setup`: boolean _(required)_
  - `has_phone`: boolean _(required)_

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors`: array of object
  - `title`: string


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/capability_schemas/{schema_id}/csv_template`

**Summary:** Get CSV template

**Tags:** Disbursement / Capability Schemas

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `schema_id` | path | integer | yes | Capability schema id |
| `required_headers_only` | query | boolean | no | For required headers only |

### Responses

#### `200` Successful - required headers only

**Content-Type:** `text/csv`

- string [example: `template content`]

#### `422` Bad params

**Content-Type:** `text/csv`

- `error`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/external_codes`

**Summary:** Get external codes

**Tags:** Disbursement

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `name` | query | string | yes | External code set name |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **external_code** _(required)_
  - **external_code** (ref)
    - `id`: integer _(required)_
    - `value`: string _(required)_
    - `external_code_set_id`: integer _(required)_

#### `422` Codes not found

**Content-Type:** `application/json`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payment_instruments`

**Summary:** Get payment instruments

**Tags:** Disbursement

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |

### Responses

#### `200` No contracted products

**Content-Type:** `application/json`

- `data`: array of **payment_instruments** _(required)_
  - **payment_instruments** (ref)
    - `local_instrument_family`: string _(required)_
    - `products`: array of **product_items** _(required)_
      - **product_items** (ref)
        - `id`: integer _(required)_
        - `corridor`: string _(required)_
        - `v2_product_id`: integer


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{payout_batch_id}/attachments`

**Summary:** Index Batch Attachments

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_batch_id` | path | integer | yes | Batch id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **attachment** _(required)_
  - **attachment** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `file_name` → **file_name** _(required)_
      - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
    - `format`: string _(required)_
    - `owner_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
    - `creator_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `updated_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Uploading to non-owned resource


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{payout_batch_id}/attachments`

**Summary:** Create Batch Attachment

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_batch_id` | path | integer | yes | Batch id |

### Request body

Attachment file to upload

_Required._

**Content-Type:** `multipart/form-data`

- string (binary)

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Missing file

**Content-Type:** `application/json`

- `error` → **error_attributes** _(required)_
  - `attributes`: object _(required)_
    - `content`: string


---

## `DELETE /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{payout_batch_id}/attachments/{uuid}`

**Summary:** Delete Batch Attachment

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_batch_id` | path | integer | yes | Batch id |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Bad uuid

**Content-Type:** `application/json`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{payout_batch_id}/attachments/{uuid}/download`

**Summary:** Download Batch Attachment

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_batch_id` | path | integer | yes | Batch id |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `image/png`

- string (binary)

**Content-Type:** `application/pdf`

- string (binary)

#### `422` Uploading to non-owned resource

#### `404` Bad uuid

**Content-Type:** `image/png`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_

**Content-Type:** `application/pdf`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{batch_id}/payout_drafts`

**Summary:** Get Batch Drafts

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `batch_id` | path | integer | yes | Batch ID |
| `page[size]` | query | integer | no | Page size |
| `page[cursor_after]` | query | string | no | Cursor after |
| `page[cursor_before]` | query | string | no | Cursor before |
| `page[include_cursor]` | query | boolean | no | Include cursor |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `meta` → **preferred_pagination**
  - `cursor_next`: string _(required)_ — Next page
  - `cursor_prev`: string _(required)_ — Previous page
  - `has_next_page`: boolean _(required)_ — Has next page
  - `has_prev_page`: boolean _(required)_ — Has prev page
  - `total`: integer _(required)_ — Total number of items
- `data`: array of **batch_drafts_item**
  - **batch_drafts_item** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `amount`: number _(required)_ — amount
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `currency` → **currency_code** _(required)_
      - string [example: `EUR`]
    - `debtor_account`: string _(required)_
    - `attachments_count`: integer _(required)_
    - `state`: string _(required)_ — received, waiting_approval or rejected
    - `end_to_end_id`: string _(required)_ — end-to-end id


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{batch_id}/payout_drafts/{draft_id}`

**Summary:** Get Batch Draft

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `batch_id` | path | integer | yes | Batch ID |
| `draft_id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **batch_draft**
  - `amount`: string _(required)_
  - `currency_code`: string _(required)_
  - `local_instrument`: string _(required)_
  - `end_to_end_id`: string _(required)_ — end-to-end id
  - `state`: string _(required)_ — received, waiting_approval or rejected
  - `batch_id`: string _(required)_
  - `source`: string — manual, csv or api
  - `creditor` → **party_identification** _(required)_
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type
    - `birthdate`: string — Dob
  - `creditor_account` → **party_identification_account** _(required)_
    - `id`: string
    - `account_number`: string
    - `bank_bic`: string
    - `bank_branch_id`: integer
    - `bank_clearing_system_code`: integer
    - `country_code`: string
    - `iban`: string
    - `type`: string
  - `debtor` → **party_identification** _(required)_
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type
    - `birthdate`: string — Dob
  - `debtor_account` → **party_identification_account** _(required)_
    - `id`: string
    - `account_number`: string
    - `bank_bic`: string
    - `bank_branch_id`: integer
    - `bank_clearing_system_code`: integer
    - `country_code`: string
    - `iban`: string
    - `type`: string
  - `ultimate_debtor` → **party_identification** _(required)_
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type
    - `birthdate`: string — Dob


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches`

**Summary:** Index Payout Batches

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `filter[kind]` | query | string | no | Filter by kind |
| `filter[state]` | query | string | no | Filter by state |
| `page[cursor_after]` | query | string | no | Cursor after |
| `page[cursor_before]` | query | string | no | Cursor before |
| `page[include_cursor]` | query | boolean | no | Include cursor |
| `page[size]` | query | integer | no | Page size |
| `sort` | query | string | no | Sort by date |
| `created_after` | query | string | no | Filter created after date |
| `created_before` | query | string | no | Filter created before date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `meta` → **pagination**
  - `cursor_next`: integer — Next page
  - `cursor_prev`: integer — Previous page
  - `has_next_page`: boolean — Has next page
  - `has_prev_page`: boolean — Has prev page
  - `total`: integer — Total number of items
- `data`: array of **payout_batches**
  - **payout_batches** (ref)
    - `id`: integer _(required)_
    - `name`: string _(required)_
    - `kind`: string _(required)_ — batch kind (iso or csv)
    - `status`: string _(required)_ _enum: ['waiting_review', 'completed', 'rejected']_
    - `local_instrument`: string _(required)_
    - `total_payout_requests_count`: integer
    - `total_amount`: integer
    - `currency`: object _(required)_
      - `iso` → **currency_iso** _(required)_
      - `name` → **currency_name** _(required)_
    - `country`: object _(required)_
      - `iso` → **country_iso** _(required)_
      - `name` → **country_name** _(required)_
    - `approvers_count`: integer
    - `attachments_count`: integer _(required)_
    - `creator_id` → **creator_id**
      - integer [example: `5`] — User id
    - `creator_name` → **creator_name**
      - string [example: `Miss Money`]
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error` → **batch_bad_filter_error**
  - `code`: integer _(required)_
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `filter`: object _(required)_
      - `kind`: array of string _(required)_


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches`

**Summary:** Create Payout Batch

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `multipart/form-data`

- `file`: string (binary) _(required)_ — CSV file to upload
- `name`: string — Optional name for the batch

### Responses

#### `202` Successful

**Content-Type:** `application/json`

- `data`: object
  - `filename`: string _(required)_
  - `format`: string _(required)_
  - `batch_id`: integer _(required)_
- `meta` → **payout_batch_meta**
  - `local_instrument`: string _(required)_
  - `total_payout_requests`: integer _(required)_
  - `total_payout_requests_amount`: number _(required)_
  - `currency`: object _(required)_
    - `iso`: string _(required)_
    - `name`: string _(required)_
  - `country`: object _(required)_
    - `iso`: string _(required)_
    - `name`: string _(required)_
- `errors` → **payout_batch_errors**
  - array, items:
    - `title`: string _(required)_
    - `details`: array of string _(required)_
    - `source`: object _(required)_
      - `pointer`: string _(required)_

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `data` → **payout_batch_error_data**
  - `filename`: string _(required)_
  - `format`: string _(required)_
  - `content`: string _(required)_ — CSV file content with errors
- `meta` → **payout_batch_error_meta**
  - `country`: object _(required)_
    - `iso`: string
    - `name`: string
  - `currency`: object _(required)_
    - `iso`: string
    - `name`: string
  - `local_instrument`: string _(required)_
- `errors` → **payout_batch_errors**
  - array, items:
    - `title`: string _(required)_
    - `details`: array of string _(required)_
    - `source`: object _(required)_
      - `pointer`: string _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{batch_id}`

**Summary:** Show Payout Batch

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `batch_id` | path | integer | yes | Batch ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **payout_batch**
  - `id`: integer _(required)_
  - `name` → **file_name**
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `kind`: string — batch kind (iso or csv)
  - `status`: string _enum: ['waiting_review', 'completed', 'rejected']_
  - `local_instrument`: string
  - `total_payout_requests_count`: integer
  - `total_amount`: integer
  - `currency`: object
    - `iso` → **currency_iso** _(required)_
      - string [example: `EUR`] — Currency ISO code
    - `name` → **currency_name** _(required)_
      - string [example: `Euro`]
  - `country`: object
    - `iso` → **country_iso** _(required)_
      - string [example: `DK`] — Country ISO
    - `name` → **country_name** _(required)_
      - string [example: `Denmark`] — Country name
  - `approvers_count`: integer
  - `accepted_payout_requests_count`: integer
  - `creator_id` → **creator_id**
    - integer [example: `5`] — User id
  - `creator_name` → **creator_name**
    - string [example: `Miss Money`]
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `approvals`: array of **review**
    - **review** (ref)
      - `user_id` → **id** _(required)_
      - `created_at` → **created_at** _(required)_
      - `user_name` → **creator_name** _(required)_
      - `approved`: boolean _(required)_
  - `rejections`: array of **review**
    - **review** (ref)
      - `user_id` → **id** _(required)_
      - `created_at` → **created_at** _(required)_
      - `user_name` → **creator_name** _(required)_
      - `approved`: boolean _(required)_

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error` → **batch_not_found_error**
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{batch_id}/approve`

**Summary:** Approve Payout Batch

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `batch_id` | path | integer | yes | Batch ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **success**
  - `success`: boolean — Successful operation response

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors` → **unauthorized_error**
  - array, items:
    - `title`: string _(required)_


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_batches/{batch_id}/reject`

**Summary:** Reject Payout Batch

**Tags:** Disbursement / Payout Batches

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `batch_id` | path | integer | yes | Batch ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **success**
  - `success`: boolean — Successful operation response

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error` → **bad_batch_status_error**
  - `code`: integer _(required)_
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `batch_id`: array of string _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{payout_draft_id}/attachments`

**Summary:** Index Draft Attachments

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_draft_id` | path | integer | yes | `Draft` id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **attachment** _(required)_
  - **attachment** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `file_name` → **file_name** _(required)_
      - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
    - `format`: string _(required)_
    - `owner_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
    - `creator_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `updated_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Uploading to non-owned resource


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{payout_draft_id}/attachments`

**Summary:** Create Draft Attachment

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_draft_id` | path | integer | yes | Draft id |

### Request body

Attachment file to upload

_Required._

**Content-Type:** `multipart/form-data`

- string (binary)

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Missing file

**Content-Type:** `application/json`

- `error` → **error_attributes** _(required)_
  - `attributes`: object _(required)_
    - `content`: string


---

## `DELETE /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{payout_draft_id}/attachments/{uuid}`

**Summary:** Delete Draft Attachment

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_draft_id` | path | string | yes | Draft id |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Bad uuid

**Content-Type:** `application/json`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{payout_draft_id}/attachments/{uuid}/download`

**Summary:** Download Draft Attachment

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `payout_draft_id` | path | string | yes | Draft id |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `image/png`

- string (binary)

**Content-Type:** `application/pdf`

- string (binary)

#### `422` Uploading to non-owned resource

#### `404` Bad uuid

**Content-Type:** `image/png`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_

**Content-Type:** `application/pdf`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts`

**Summary:** Index Payout Drafts

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `filter[status]` | query | string | no | Filter by status |
| `created_after` | query | string | no | Created after |
| `created_before` | query | string | no | Created before |
| `page[cursor_after]` | query | string | no | Cursor after |
| `page[cursor_before]` | query | string | no | Cursor before |
| `page[include_cursor]` | query | boolean | no | Include cursor |
| `page[size]` | query | integer | no | Page size |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **payout_drafts_item** _(required)_
  - **payout_drafts_item** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `source`: string _(required)_ — manual or batch
    - `attachments_count`: integer _(required)_
    - `status`: string _(required)_ _enum: ['waiting_review', 'rejected']_ — waiting_approval or rejected
    - `creator_name`: string
    - `local_instrument`: string
    - `corridor`: string
    - `approvers_count`: integer — number of current approvals
    - `end_to_end_id`: string — end-to-end id
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `debtor_account` → **virtual_account_number**
      - string [example: `29301655053`] — virtual account number
    - `currency` → **currency_code**
      - string [example: `EUR`]
- `meta` → **preferred_pagination**
  - `cursor_next`: string _(required)_ — Next page
  - `cursor_prev`: string _(required)_ — Previous page
  - `has_next_page`: boolean _(required)_ — Has next page
  - `has_prev_page`: boolean _(required)_ — Has prev page
  - `total`: integer _(required)_ — Total number of items


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts`

**Summary:** Create Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `schema_id`: integer
- `product_id`: integer

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- **created_payout_draft** (ref)
  - `data`: object _(required)_
    - `draft_id`: integer _(required)_
    - `product`: object _(required)_
      - `local_instrument`: string _(required)_
      - `product_id`:  _(required)_
      - `schema_id`:  _(required)_
    - `payout_request`: object _(required)_
    - `ultimate_debtor`: object _(required)_
    - `creditor`: object _(required)_
    - `creditor_account`: object _(required)_
    - `debtor`: object _(required)_
    - `intermediary_agent`: object
    - `intermediary_agent_account`: object

#### `422` Unprocessable Entity

**Content-Type:** `application/json`

- **payout_draft_validation_error** (ref)
  - `error`: array of object _(required)_
    - `title`: string
    - `details`: array of string _(required)_
    - `source`: object
      - `pointer`: string


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{draft_id}`

**Summary:** Get Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `draft_id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **payout_draft** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `approvers_count`: integer _(required)_ — number of current approvals
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `debtor`: object
    - `name`: string
    - `website`: string
  - `ultimate_debtor` → **party_identification**
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type
    - `birthdate`: string — Dob
  - `creditor` → **party_identification**
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type
    - `birthdate`: string — Dob
  - `creditor_account` → **party_identification_account**
    - `id`: string
    - `account_number`: string
    - `bank_bic`: string
    - `bank_branch_id`: integer
    - `bank_clearing_system_code`: integer
    - `country_code`: string
    - `iban`: string
    - `type`: string
  - `intermediary_agent` → **intermediary_agent**
    - `bank_bic`: string _(required)_
    - `bank_name`: string _(required)_
  - `intermediary_agent_account` → **intermediary_agent_account**
    - `account_number`: string _(required)_
    - `iban`: string _(required)_
  - `debtor_account`: object
    - `id`: number
    - `scheme_name`: string
  - `creator_name`: string _(required)_ — user name
  - `source`: string _(required)_ — manual or batch
  - `user_id`: number — creator id
  - `status`: string _(required)_ _enum: ['waiting_review', 'rejected']_ — waiting_review or rejected
  - `end_to_end_id`: string — end-to-end id
  - `local_instrument`: string _(required)_
  - `corridor`: string _(required)_
  - `approvals`: array of **review**
    - **review** (ref)
      - `user_id` → **id** _(required)_
      - `created_at` → **created_at** _(required)_
      - `user_name` → **creator_name** _(required)_
      - `approved`: boolean _(required)_
  - `rejections`: array of **review**
    - **review** (ref)
      - `user_id` → **id** _(required)_
      - `created_at` → **created_at** _(required)_
      - `user_name` → **creator_name** _(required)_
      - `approved`: boolean _(required)_


---

## `PUT /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{draft_id}`

**Summary:** Updates a payout draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `draft_id` | path | integer | yes |  |

### Request body

**Content-Type:** `application/json`


### Responses

#### `200` payout draft updated

**Content-Type:** `application/json`

- `data`: boolean _(required)_ _enum: [True]_

#### `401` Unauthorized

**Content-Type:** `application/json`

- `errors` → **unauthorized_error** _(required)_
  - array, items:
    - `title`: string _(required)_

#### `422` Unprocessable Entity


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{draft_id}/approve`

**Summary:** Approve Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `draft_id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`:  _(required)_

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`:  _(required)_

#### `401` Unauthorised

**Content-Type:** `application/json`

- `errors` → **unauthorized_error** _(required)_
  - array, items:
    - `title`: string _(required)_


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{draft_id}/reject`

**Summary:** Reject Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `draft_id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`:  _(required)_

#### `422` Unprocessable entity

**Content-Type:** `application/json`

- `error`:  _(required)_

#### `401` Unauthorised

**Content-Type:** `application/json`

- `errors`:  _(required)_


---

## `DELETE /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{id}`

**Summary:** Destroy Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

#### `422` Unprocessable entity


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{id}/summary`

**Summary:** Payout Draft Summary

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `id` | path | integer | yes | Payout Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- **created_payout_draft** (ref)
  - `data`: object _(required)_
    - `draft_id`: integer _(required)_
    - `product`: object _(required)_
      - `local_instrument`: string _(required)_
      - `product_id`:  _(required)_
      - `schema_id`:  _(required)_
    - `payout_request`: object _(required)_
    - `ultimate_debtor`: object _(required)_
    - `creditor`: object _(required)_
    - `creditor_account`: object _(required)_
    - `debtor`: object _(required)_
    - `intermediary_agent`: object
    - `intermediary_agent_account`: object


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_drafts/{id}/publish`

**Summary:** Publish Payout Draft

**Tags:** Disbursement / Payout Drafts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `id` | path | integer | yes | Draft ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **published_payout_request**
  - `debtor_account` → **debtor_account**
    - `id`: string — The debtor account id
    - `scheme_name`: string — The scheme used for the payout request
  - `end_to_end_id`: string — Sequential end-to-end id
  - `inpay_unique_reference` → **inpay_unique_reference**
    - string [example: `d1a2b3c4d5`] — Our unique reference
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `currency`: string — Currency of the payout
  - `currency_code`: string — Currency of the draft
  - `timestamp`: string — Datetime
  - `state`: string — State of the payout request

#### `422` unprocessable entity

**Content-Type:** `application/json`

- **payout_draft_validation_error** (ref)
  - `error`: array of object _(required)_
    - `title`: string
    - `details`: array of string _(required)_
    - `source`: object
      - `pointer`: string


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_reports`

**Summary:** Index Payout Reports

**Tags:** Disbursement / Payout Reports

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **payout_reports**
  - **payout_reports** (ref)
    - `uuid` → **payout_report_name**
      - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `created_after`: string — created after filter
    - `created_before`: string — created before filter
    - `state_categories`: array of string
    - `amount_from`: string — amount from filter
    - `amount_to`: string — amount to filter
    - `reason_codes`: array of string
    - `business_unit_name`: string — business unit filter
    - `local_instrument`: string — local instrument filter
    - `currency_code` → **currency_code**
      - string [example: `EUR`]
    - `virtual_account_number` → **virtual_account_number**
      - string [example: `29301655053`] — virtual account number
    - `organisation_id` → **organisation_id**
      - integer [example: `1`]
    - `creator_id` → **creator_id**
      - integer [example: `5`] — User id
    - `creator_type` → **creator_type**
      - string [example: `Customer::User`]
    - `filename` → **payout_report_name**
      - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `updated_at` → **updated_at**
      - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated
- `meta` → **total_count_pagination**
  - `cursor_next`: integer — Next page
  - `cursor_prev`: integer — Previous page
  - `has_next_page`: boolean — Has next page
  - `has_prev_page`: boolean — Has prev page
  - `total_count`: integer — Total number of items


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_reports`

**Summary:** Create Payout Report

**Tags:** Disbursement / Payout Reports

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `virtual_account_number`: string _(required)_
- `created_after`: string _(required)_ — Date
- `created_before`: string _(required)_ — Date
- `state_categories`: array of string — Payment request state categories

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **payout_report_name**
  - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_reports/{uuid}`

**Summary:** Show Payout Report

**Tags:** Disbursement / Payout Reports

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Uuid of report |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **payout_report**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `processing_state`: string — available
  - `uuid` → **payout_report_name**
    - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `created_after`: string — created after filter
  - `created_before`: string — created before filter
  - `state_categories`: array of string
  - `amount_from`: string — amount from filter
  - `amount_to`: string — amount to filter
  - `reason_codes`: array of string
  - `business_unit_name`: string — business unit filter
  - `local_instrument`: string — local instrument filter
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `virtual_account_number` → **virtual_account_number**
    - string [example: `29301655053`] — virtual account number
  - `organisation_id` → **organisation_id**
    - integer [example: `1`]
  - `creator_id` → **creator_id**
    - integer [example: `5`] — User id
  - `creator_type` → **creator_type**
    - string [example: `Customer::User`]
  - `filename` → **payout_report_name**
    - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **updated_at**
    - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_reports/{uuid}/download`

**Summary:** Download Payout Report

**Tags:** Disbursement / Payout Reports

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `uuid` | path | string | yes | Uuid of report |

### Responses

#### `200` Successful

**Content-Type:** `text/csv`

- string [example: `csv content`]


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}/attachments`

**Summary:** Index Payout Request Attachments

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `inpay_unique_reference` | path | string | yes | Reference |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **attachment** _(required)_
  - **attachment** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `file_name` → **file_name** _(required)_
      - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
    - `format`: string _(required)_
    - `owner_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
    - `creator_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `updated_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Uploading to non-owned resource


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}/attachments`

**Summary:** Create Payout Request Attachment

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `inpay_unique_reference` | path | string | yes | Reference |

### Request body

Attachment file to upload

_Required._

**Content-Type:** `multipart/form-data`

- string (binary)

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Missing file

**Content-Type:** `application/json`

- `error` → **error_attributes** _(required)_
  - `attributes`: object _(required)_
    - `content`: string


---

## `DELETE /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}/attachments/{uuid}`

**Summary:** Delete Payout Request Attachment

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `inpay_unique_reference` | path | string | yes | Reference |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **attachment** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `file_name` → **file_name** _(required)_
    - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
  - `format`: string _(required)_
  - `owner_id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
  - `creator_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

#### `422` Bad uuid

**Content-Type:** `application/json`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}/attachments/{uuid}/download`

**Summary:** Download Payout Request Attachment

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `inpay_unique_reference` | path | string | yes | Reference |
| `uuid` | path | string | yes | Attachment uuid |

### Responses

#### `200` Successful

**Content-Type:** `image/png`

- string (binary)

**Content-Type:** `application/pdf`

- string (binary)

#### `422` Uploading to non-owned resource

#### `404` Bad uuid

**Content-Type:** `image/png`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_

**Content-Type:** `application/pdf`

- `error` → **error_generic_details_nil** _(required)_
  - `title`: string _(required)_
  - `details`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests`

**Summary:** Index Payout Requests

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `unique_identifier` | query | string | no | Unique identifier |
| `business_unit_id` | query | string | no |  |
| `reason_code_id` | query | string | no |  |
| `currency_code` | query | string | no |  |
| `source` | query | string | no |  |
| `state_category` | query | string | no |  |
| `local_instrument` | query | string | no |  |
| `batch_id` | query | string | no |  |
| `amount_from` | query | string | no |  |
| `amount_to` | query | string | no |  |
| `virtual_account_number` | query | string | no |  |
| `created_after` | query | string | no |  |
| `created_before` | query | string | no |  |
| `cursor_after` | query | string | no |  |
| `cursor_before` | query | string | no |  |
| `include_cursor` | query | string | no |  |
| `sort` | query | string | no |  |
| `page_size` | query | string | no |  |

### Responses

#### `200` Successful (filter by currency_code and source)

**Content-Type:** `application/json`

- `meta` → **preferred_pagination** _(required)_
  - `cursor_next`: string _(required)_ — Next page
  - `cursor_prev`: string _(required)_ — Previous page
  - `has_next_page`: boolean _(required)_ — Has next page
  - `has_prev_page`: boolean _(required)_ — Has prev page
  - `total`: integer _(required)_ — Total number of items
- `data`: array of **payout_request_item** _(required)_
  - **payout_request_item** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `business_unit_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `batch_id`: integer
    - `execution_date`: string _(required)_
    - `source`: string _enum: ['api', 'csv', 'manual', 'iso_20022']_
    - `state`: string _(required)_ _enum: ['received', 'pending', 'processing', 'completed', 'rejected', 'returned', 'action_required']_ — state category name
    - `local_instrument`: string _(required)_
    - `end_to_end_id`: string
    - `inpay_unique_reference` → **inpay_unique_reference**
      - string [example: `d1a2b3c4d5`] — Our unique reference
    - `amount` → **amount** _(required)_
      - string [example: `100.0`] — amount
    - `debtor_account` → **virtual_account_number** _(required)_
      - string [example: `29301655053`] — virtual account number
    - `currency` → **currency_code** _(required)_
      - string [example: `EUR`]
    - `attachments_count`: integer _(required)_

#### `422` Bad params

**Content-Type:** `application/json`

- `error` → **error_generic_detail_object** _(required)_
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `status`: string


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}`

**Summary:** Show Payout Request

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `inpay_unique_reference` | path | string | yes | Unique identifier |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **payout_request** _(required)_
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `inpay_unique_reference` → **inpay_unique_reference** _(required)_
    - string [example: `d1a2b3c4d5`] — Our unique reference
  - `end_to_end_id`: string _(required)_ — end-to-end id
  - `local_instrument`: string _(required)_
  - `business_unit`: string _(required)_
  - `amount` → **amount** _(required)_
    - string [example: `100.0`] — amount
  - `batch_id`: integer _(required)_
  - `source`: string _(required)_ — manual, csv or api
  - `currency` → **currency_code** _(required)_
    - string [example: `EUR`]
  - `status`: string _(required)_ _enum: ['received', 'rejected', 'returned', 'action_required', 'completed', 'pending', 'processing']_
  - `creator_id`: number _(required)_ — creator id
  - `creator_name`: string _(required)_
  - `current_state_name`: string _(required)_ _enum: ['created', 'capability_selected', 'validating_external', 'validated', 'unable_to_validate_external', 'waiting_future_execution', 'tstm_initiated', 'tstm_screened', 'ready_for_v1', 'scheduled_for_processing', 'converting_to_v1', 'conversion_to_v1_failed', 'converted_to_v1', 'ready_for_transaction_screening', 'transaction_screening_in_process', 'reviewing_transaction_screening', 'added_to_payout_planner', 'halted', 'rerouted_to_different_provider', 'accepted_by_processing_provider', 'reconciliation_completed', 'missing_capability', 'validation_schema_failed', 'external_validation_failed', 'payment_request_cancelled', 'payment_returned', 'awaiting_kyc_documents', 'awaiting_extended_kyc', 'insufficient_funds']_
  - `timestamp`: string _(required)_
  - `requested_execution_date` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `purpose_code`: string _(required)_
  - `debtor` → **payout_debtor** _(required)_
    - `full_name`: string _(required)_
    - `website`: string _(required)_
  - `ultimate_debtor` → **disbursement_party_identification** _(required)_
    - `full_name`: string _(required)_
    - `birthdate`: string _(required)_
    - `address`: string _(required)_
    - `city`: string _(required)_
    - `country_code` → **country_iso** _(required)_
      - string [example: `DK`] — Country ISO
    - `postal_code`: string
    - `email`: string _(required)_
    - `mobile_number`: string _(required)_
    - `vop_result`: string
    - `vop_matched_name`: string
  - `creditor` → **disbursement_party_identification** _(required)_
    - `full_name`: string _(required)_
    - `birthdate`: string _(required)_
    - `address`: string _(required)_
    - `city`: string _(required)_
    - `country_code` → **country_iso** _(required)_
      - string [example: `DK`] — Country ISO
    - `postal_code`: string
    - `email`: string _(required)_
    - `mobile_number`: string _(required)_
    - `vop_result`: string
    - `vop_matched_name`: string
  - `creditor_account` → **creditor_account** _(required)_
    - `iban`: string _(required)_
    - `account_number`: string _(required)_
    - `account_number_type`: string _(required)_
    - `bank_bic`: string _(required)_
    - `bank_name`: string _(required)_
    - `bank_clearing_system_id`: string _(required)_
    - `bank_clearing_system_code`: string _(required)_
    - `bank_branch_id`: integer _(required)_
    - `bank_branch_name`: integer _(required)_
    - `country_code`: string _(required)_
  - `intermediary_agent` → **intermediary_agent** _(required)_
    - `bank_bic`: string _(required)_
    - `bank_name`: string _(required)_
  - `intermediary_agent_account` → **intermediary_agent_account** _(required)_
    - `account_number`: string _(required)_
    - `iban`: string _(required)_
  - `debtor_account` → **reconciliation_virtual_account** _(required)_
    - `number`: string
    - `currency`: string
  - `reason_codes`: array of **reason_code_object** _(required)_
    - **reason_code_object** (ref)
      - `id` → **id** _(required)_
      - `reason_code_id` → **id** _(required)_
      - `kind`: string _(required)_
      - `group`: string _(required)_
      - `symbol`: string _(required)_
      - `external_message`: string _(required)_
      - `reason`: string _(required)_
  - `payment_request_state_reason_codes`: array of object _(required)_
    - `reason_code_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `meta`: object
  - `status_transitions`: array of object _(required)_
    - `name`: string _(required)_
    - `timestamp`: string _(required)_
  - `cancellations`: array of **cancellations** _(required)_
    - **cancellations** (ref)
      - `id` → **id**
      - `initiator_id` → **id**
      - `initiator_name` → **creator_name**
      - `initiator_type`: string _enum: ['Customer::User', 'Admin::User', 'Customer::Organisation']_
      - `created_at`: string
      - `status`: string
  - `reviews`: array of **payout_review** _(required)_
    - **payout_review** (ref)
      - `reviewer_id` → **id**
      - `created_at`: string
      - `reviewer_name` → **creator_name**
      - `approved`: boolean
  - `errors`: object _(required)_

#### `422` Not found

**Content-Type:** `application/json`

- `error` → **error_generic_detail_string** _(required)_
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `DELETE /customer_app_api/disbursement/organisations/{organisation_id}/payout_requests/{inpay_unique_reference}`

**Summary:** Cancel Payout Requests

**Tags:** Disbursement / Payout Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `inpay_unique_reference` | path | string | yes | Unique identifier |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: object _(required)_
  - `status`: string _(required)_ _enum: ['pending']_

#### `422` Unprocessable

**Content-Type:** `application/json`

- `error` → **error_generic_detail_object** _(required)_
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `status`: string


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/product_schemas`

**Summary:** Get product schemas

**Tags:** Disbursement

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `product_id` | query | integer | yes | Product id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **product_schemas** _(required)_
  - **product_schemas** (ref)
    - `id`: integer _(required)_
    - `label`: string _(required)_

#### `422` Product not found

**Content-Type:** `application/json`

- `error` → **error_generic_with_code_detail_object** _(required)_
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/schema_fields_definition/{schema_id}`

**Summary:** Get Schema Fields Definition

**Tags:** Disbursement / Schemas Fields Definition

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `schema_id` | path | integer | yes | schema id |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- **schema_fields_definition** (ref)
  - `data`: object _(required)_
    - `creditor`: object _(required)_
    - `creditor_account`: object _(required)_
    - `intermediary_agent`: object
    - `intermediary_agent_account`: object

#### `422` Bad params

**Content-Type:** `application/json`

- `error`:  _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/stats/payout_requests/reason_codes`

**Summary:** Get payout reason code stats

**Tags:** Disbursement/Stats

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `created_after` | query | string | no | Date filter |
| `created_before` | query | string | no | Date filter |
| `categories[]` | query | array | no |  |

### Responses

#### `200` With category filter

**Content-Type:** `application/json`

- `data` → **payout_reason_code_stats** _(required)_
  - `action_required` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `completed` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `pending` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `processing` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `received` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `rejected` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `returned` → **payout_reason_code_stat_item** _(required)_
    - `items`: array of **payout_reason_code_item** _(required)_
      - **payout_reason_code_item** (ref)
        - `id`: integer _(required)_
        - `code`: string _(required)_
        - `name`: string _(required)_
        - `count`: integer _(required)_
        - `percentage`: number (float) _(required)_
    - `meta` → **payout_reason_code_stat_meta** _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_

#### `422` Invalid query params

**Content-Type:** `application/json`

- `error`: array of **payout_error** _(required)_
  - **payout_error** (ref)
    - `details`: array of string _(required)_
    - `pointer`: string _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/stats/payout_requests/state_categories`

**Summary:** Get payout state category stats

**Tags:** Disbursement/Stats

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation id |
| `created_after` | query | string | no | Date filter |
| `created_before` | query | string | no | Date filter |
| `categories[]` | query | array | no |  |

### Responses

#### `200` With category filter

**Content-Type:** `application/json`

- `data`: array of **payout_state_category_stat_item** _(required)_
  - **payout_state_category_stat_item** (ref)
    - `code`: string _(required)_ _enum: ['received', 'pending', 'action_required', 'processing', 'rejected', 'completed', 'returned']_
    - `name`: string _(required)_ _enum: ['Received', 'Pending', 'Action required', 'Processing', 'Rejected', 'Completed', 'Returned']_
    - `count`: integer _(required)_
- `meta` → **payout_state_category_stat_meta** _(required)_
  - `count`: integer _(required)_

#### `422` Invalid query params

**Content-Type:** `application/json`

- `error`: array of **payout_error** _(required)_
  - **payout_error** (ref)
    - `details`: array of string _(required)_
    - `pointer`: string _(required)_


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/withdrawal_account_authorizations`

**Summary:** Get withdrawal account authorizations

**Tags:** Disbursement / Withdrawal Account Authorizations

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `withdrawal_account_status` | query | string (enum: ['created', 'pending_approval', 'active', 'inactive', 'rejected']) | no | Withdrawal account status |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **withdrawal_account_authorization**
  - **withdrawal_account_authorization** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `withdrawal_account_uuid` → **uuid**
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `virtual_bank_account_number` → **virtual_account_number**
      - string [example: `29301655053`] — virtual account number


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/withdrawal_accounts`

**Summary:** Get Organisations Withdrawal Accounts

**Tags:** Disbursement / Withdrawal Accounts

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful with crypto account

**Content-Type:** `application/json`

- `data`: array of **withdrawal_account**
  - **withdrawal_account** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `label`: string — Label
    - `organisation_id`: number _(required)_ — Organisation id
    - `account_number`: string — Account number
    - `type`: string — Type
    - `bank_bic`: string — Bank bic
    - `bank_branch_name`: string — Bank branch name
    - `bank_clearing_system_code`: string — Bank clearing system code
    - `bank_name`: string — Bank name
    - `country_code` → **country_iso** _(required)_
      - string [example: `DK`] — Country ISO
    - `currency`: string _(required)_ — Currency
    - `iban`: string — Iban
    - `local_instrument`: string — Local instrument
    - `bank_branch_id`: string — Bank branch id
    - `bank_clearing_system_id`: string — Bank clearing system id
    - `status`: string _(required)_ _enum: ['created', 'pending_approval', 'active', 'inactive', 'rejected']_ — Status
    - `party_identification`: object
      - `address_lines`: string — Creditor address
      - `city`: string — Creditor city
      - `country_code` → **country_iso**
      - `name`: string — Creditor name
      - `postcode`: string — Creditor postcode
      - `type`: string — Account holder type


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/withdrawal_requests`

**Summary:** Index Withdrawal Requests

**Tags:** Disbursement / Withdrawal Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `page` | query | object | no | Pagination parameters |
| `filter` | query | object | no | Filtering options |
| `sort` | query | string (enum: ['amount', '-amount', 'id', '-id', 'created_at', '-created_at', 'updated_at', '-updated_at']) | no | Sort param. Sort by id is default |
| `created_after` | query | string | no | Filter by date |
| `created_before` | query | string | no | Filter by date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **withdrawal_requests** _(required)_
  - **withdrawal_requests** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `creditor_account_uuid` → **creditor_account_uuid**
      - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
    - `currency_code` → **currency_code**
      - string [example: `EUR`]
    - `debtor_account_number` → **debtor_account_number**
      - string [example: `29301655053`] — Debtor account number
    - `external_reference` → **external_reference**
      - string [example: `chosen_id`] — Unique reference end to end id
    - `reference` → **reference**
      - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
    - `status` → **withdrawal_status**
      - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `meta` → **preferred_pagination** _(required)_
  - `cursor_next`: string _(required)_ — Next page
  - `cursor_prev`: string _(required)_ — Previous page
  - `has_next_page`: boolean _(required)_ — Has next page
  - `has_prev_page`: boolean _(required)_ — Has prev page
  - `total`: integer _(required)_ — Total number of items


---

## `POST /customer_app_api/disbursement/organisations/{organisation_id}/withdrawal_requests`

**Summary:** Create Withdrawal Request

**Tags:** Disbursement / Withdrawal Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `end_to_end_id`: string _(required)_ — End to end id
- `amount`: number _(required)_ — Withdrawal request amount
- `currency_code`: string _(required)_ — Country code
- `creditor_account`: object _(required)_
  - `id`: string _(required)_ — Creditor account UUID
- `debtor_account`: object _(required)_
  - `scheme_name`: string _(required)_ — Schema type
  - `id`: string _(required)_ — Debitor account id

### Responses

#### `201` Successful

**Content-Type:** `application/json`

- `data` → **withdrawal_request**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `creditor_account_uuid` → **creditor_account_uuid**
    - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `external_reference` → **external_reference**
    - string [example: `chosen_id`] — Unique reference end to end id
  - `reference` → **reference**
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `debtor_account_number` → **debtor_account_number**
    - string [example: `29301655053`] — Debtor account number
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created


---

## `GET /customer_app_api/disbursement/organisations/{organisation_id}/withdrawal_requests/{withdrawal_request_id}`

**Summary:** Show Withdrawal Request

**Tags:** Disbursement / Withdrawal Requests

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `withdrawal_request_id` | path | integer | yes | The ID of the withdrawal request |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **withdrawal_request_with_account**
  - `id` → **id** _(required)_
    - integer [example: `1`] — Unique Identifier
  - `amount` → **amount** _(required)_
    - string [example: `100.0`] — amount
  - `creditor_account_uuid` → **creditor_account_uuid** _(required)_
    - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
  - `currency_code` → **currency_code** _(required)_
    - string [example: `EUR`]
  - `external_reference` → **external_reference**
    - string [example: `chosen_id`] — Unique reference end to end id
  - `reference` → **reference** _(required)_
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `status` → **withdrawal_status** _(required)_
    - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
  - `transfer_amount` → **transfer_amount**
    - integer [example: `10.0`] — Transfer amount
  - `transfer_currency_code` → **transfer_currency_code**
    - string [example: `EUR`] — Transfer currency code
  - `provider_capability_id` → **provider_capability_id**
    - string [example: ``] — Provider capability id
  - `debtor_account_number` → **debtor_account_number** _(required)_
    - string [example: `29301655053`] — Debtor account number
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `status_transitions` → **status_transitions_with_reason_code** _(required)_
    - array, items:
      - **status_transition_with_reason_code** (ref)
        - `id` → **id**
        - `created_at` → **created_at** _(required)_
        - `status` → **withdrawal_status** _(required)_
        - `reason_code` → **withdrawal_reason_code** _(required)_
  - `creditor_account` → **withdrawal_account**
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `label`: string — Label
    - `organisation_id`: number _(required)_ — Organisation id
    - `account_number`: string — Account number
    - `type`: string — Type
    - `bank_bic`: string — Bank bic
    - `bank_branch_name`: string — Bank branch name
    - `bank_clearing_system_code`: string — Bank clearing system code
    - `bank_name`: string — Bank name
    - `country_code` → **country_iso** _(required)_
      - string [example: `DK`] — Country ISO
    - `currency`: string _(required)_ — Currency
    - `iban`: string — Iban
    - `local_instrument`: string — Local instrument
    - `bank_branch_id`: string — Bank branch id
    - `bank_clearing_system_id`: string — Bank clearing system id
    - `status`: string _(required)_ _enum: ['created', 'pending_approval', 'active', 'inactive', 'rejected']_ — Status
    - `party_identification`: object
      - `address_lines`: string — Creditor address
      - `city`: string — Creditor city
      - `country_code` → **country_iso**
      - `name`: string — Creditor name
      - `postcode`: string — Creditor postcode
      - `type`: string — Account holder type


---

## `GET /customer_app_api/documentation/organisations`

**Summary:** Get Organisations with authenticated user

**Tags:** Documentation / Products

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `token` | query | string | no | magic token |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **organisations**
  - **organisations** (ref)
    - `id`: integer — Organisation id
    - `name`: string — Organisation name
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO

#### `401` Invalid scope

**Content-Type:** `application/json`



---

## `GET /customer_app_api/documentation/organisations/{organisation_id}`

**Summary:** Get Organisation by ID with standard auth

**Tags:** Documentation / Products

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `token` | query | string | no | magic token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **organisations**
  - `id`: integer — Organisation id
  - `name`: string — Organisation name
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO

#### `422` Resource not found

**Content-Type:** `application/json`


#### `401` Resource not found

**Content-Type:** `application/json`



---

## `GET /customer_app_api/documentation/organisations/{organisation_id}/products`

**Summary:** Get products by organisation with token

**Tags:** Documentation / Products

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `token` | query | string | no | Magic token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `origin` | query | string | yes | Type of product |

### Responses

#### `422` Invalid origin

**Content-Type:** `application/json`


#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **contracted_products**
  - **contracted_products** (ref)
    - `id`: integer — Product id
    - `currency_iso` → **currency_iso**
      - string [example: `EUR`] — Currency ISO code
    - `country_iso` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `label`: string — label
    - `instrument`: string — label

#### `401` Invalid scope

**Content-Type:** `application/json`



---

## `GET /customer_app_api/documentation/organisations/{organisation_id}/products/{product_id}`

**Summary:** Get single product with token

**Tags:** Documentation / Products

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `token` | query | string | yes | Magic token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `product_id` | path | integer | yes | Product ID |
| `v2_product_id` | query | integer | no | V2 Product ID |

### Responses

#### `422` Product not found

**Content-Type:** `application/json`


#### `200` Successful

**Content-Type:** `application/json`

- `data` → **schema_example_product**
  - `example`: string — The example string
  - `schema`: object — The schema of the example
    - `schema_fields`: array of **schema_field** — The schema fields
      - **schema_field** (ref)
        - `field`: string — The name of the field
        - `description`: string — A brief description of the field
        - `type`: string — The data type of the field
        - `rules`: array of object
          - `description`: string — A brief description of the rule
          - `hint`: string — A hint for the rule
    - `organisation`: object — The organisation
      - `id`: integer — The organisation id
      - `name`: string — The organisation name
      - `country_code`: string
    - `payout_product`: object — The payout product
      - `id`: integer — The product id
      - `currency`: string
      - `country`: string
    - `current_schema`: object — The current schema
      - `id`: integer — The schema id
      - `name`: string — The schema name
      - `description`: string — The schema description
      - `updated_at`: string
      - `label`: string
    - `available_schemas`: array of object — The available schemas
      - `id`: integer — The schema id
      - `name`: string — The schema name
      - `description`: string — The schema description
      - `updated_at`: string
      - `label`: string

#### `401` Invalid scope

**Content-Type:** `application/json`



---

## `GET /customer_app_api/feature_flags`

**Summary:** Get flipper features

**Tags:** System

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | no | Authentication token |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **feature_flag** _(required)_
  - `customer-app-canary-ui`: boolean
  - `CBP-1761-customer-app-batches`: boolean
  - `CBP-2001-approval-workflow-manual-payouts`: boolean
  - `CBP-2870-withdrawal-accounts-enabled`: boolean
  - `CBP-8000-receiver-management`: boolean
  - `CBP-10746-e2e-test-cases-field-enabled`: boolean
  - `PEGO-12125-insight-section-customer-app`: boolean
  - `PEGO-12738-sandbox-customer-app-api-docs`: boolean
  - `PEGO-12664-create-receiver`: boolean


---

## `GET /customer_app_api/fx/organisations/{organisation_id}/currencies`

**Summary:** Fetch currencies

**Tags:** FX

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of object
  - `iso_code`: string — three-letter ISO (4217) code for currency in question
  - `id`: number — Id of the currency
  - `name`: string — Name of the currency


---

## `GET /customer_app_api/fx/organisations/{organisation_id}/exchange_rate`

**Summary:** Retrieve Exchange Rate

**Tags:** FX

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |
| `buy_currency` | query | string | yes | buy currency. Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies. |
| `pay_currency` | query | string | yes | pay currency. Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies. |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: object
  - `buy_currency`: string — Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies.
  - `pay_currency`: string — Format does not fully conform to ISO standard 4217 - can potentially also return crypto currencies.
  - `exchange_rate`: string — the exchange rate value
  - `reciprocal_exchange_rate`: string — the reciprocal exchange rate value, is the same as (1/exchange_rate)
  - `utc_time`: string — time when the request was processed in UTC time zone.

#### `422` Bad Request - Invalid Parameters

**Content-Type:** `application/json`

- `errors`: array of object
  - `details`: object
  - `title`: string

#### `404` Not Found - Exchange Rate not found

**Content-Type:** `application/json`

- `errors`: array of object
  - `details`: string
  - `title`: string


---

## `GET /customer_app_api/fx/organisations/{organisation_id}/markups`

**Summary:** Fetch markups

**Tags:** FX

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of object
  - `id`: integer — Id
  - `buy_currency_iso`: string — three-letter ISO (4217) code for currency in question
  - `pay_currency_iso`: string — three-letter ISO (4217) code for currency in question


---

## `GET /customer_app_api/notifications/organisations/{organisation_id}/alerts`

**Summary:** Retrieve In-App Alerts

**Tags:** Customer / Notifications

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `app_type` | query | string | no | Filter alerts by app type |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **in_app_alert**
  - **in_app_alert** (ref)
    - `id`: integer _(required)_ — The unique identifier of the alert
    - `app_type`: string _(required)_ — The type of app the alert is for (e.g., 'customer_app', 'docs')
    - `alert_type`: string _(required)_ — The type of alert (e.g., 'info', 'warning', 'error')
    - `alert_message`: string _(required)_ — The message content of the alert
    - `enabled`: boolean _(required)_ — Whether the alert is currently enabled or not

#### `401` Unauthorized


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/accounts`

**Summary:** Index Accounts Request

**Tags:** Virtual Bank / Account

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **account**
  - **account** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `account_number`: string — Account number
    - `name`: string — Account Name (default is '<currency> account')
    - `balance`: string — latest balance on account
    - `currency_code` → **currency_code**
      - string [example: `EUR`]
    - `currency_name` → **currency_name**
      - string [example: `Euro`]
    - `has_transactions`: boolean — Boolean telling if the account has any transactions
    - `owner`: boolean — Boolean telling if the account is owned by the requesting organisation
    - `status`: string _enum: ['active', 'suspended', 'terminated']_ — account can be active, suspended or terminated


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/accounts/{account_number}/summary`

**Summary:** Account summary Request

**Tags:** Virtual Bank / Account

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `account_number` | path | integer | yes | Account number |
| `created_after` | query | string | yes | summary from date |
| `created_before` | query | string | yes | summary to date |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **account_summary** _(required)_
  - `currency_code` → **currency_code**
    - string [example: `EUR`]
  - `current_balance`: string
  - `opening_balance`: string
  - `closing_balance`: string

#### `422` No owned accounts found


---

## `POST /customer_app_api/virtual_bank/organisations/{organisation_id}/inter_account_movements`

**Summary:** Create inter account movement

**Tags:** Virtual Bank / Inter account movements

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `amount`: string _(required)_
- `from_account_number`: string _(required)_
- `to_account_number`: string _(required)_
- `end_to_end_id`: string _(required)_

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **internal_account_movement**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `amount` → **amount**
    - string [example: `100.0`] — amount
  - `date` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `reason`: string — Type
  - `reference` → **reference**
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `movable_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `movable_type`: string — Type of movement
  - `account_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `movable` → **movable**
    - `user_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `internal_remarks`: string — Additional info

#### `422` Bad accounts

**Content-Type:** `application/json`

- `error` → **internal_account_movement_errors**
  - `code`: integer — error code from engine
  - `title`: string
  - `details`: 


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/accounts/{account_number}/movements`

**Summary:** Index Account Movements Request

**Tags:** Virtual Bank / Account

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `account_number` | path | integer | yes | Account number |
| `created_after` | query | string | no | created after |
| `created_before` | query | string | no | Created before |
| `cursor_after` | query | string | no | Cursor after |
| `cursor_before` | query | string | no | Cursor before |
| `filter[entry_type]` | query | string (enum: ['collection', 'collection_refund', 'collection_fee', 'collection_refund_fee', 'refund_canceled', 'refund_returned', 'payout', 'payout_fee', 'payout_returned', 'payout_cancelled', 'incident_charges_fee', 'monthly_fee', 'minimum_processing_fee', 'inter_account_transfer', 'correction', 'contract_trx_fee_adjustment', 'funding']) | no | Entry type |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **movement**
  - **movement** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `order_id`: string — Order id
    - `reference` → **reference**
      - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `payout_currency` → **currency_code**
      - string [example: `EUR`]
    - `amount_payout_currency`: string — Amount
    - `entry_type`: string — Type of movement
    - `date` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `value_date` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `currency` → **currency_code**
      - string [example: `EUR`]
    - `running_balance` → **amount**
      - string [example: `100.0`] — amount
- `meta` → **pagination**
  - `cursor_next`: integer — Next page
  - `cursor_prev`: integer — Previous page
  - `has_next_page`: boolean — Has next page
  - `has_prev_page`: boolean — Has prev page
  - `total`: integer — Total number of items


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/movements/search`

**Summary:** Search Account Movements

**Tags:** Virtual Bank / Account

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `unique_identifier` | query | string | yes | Unique identifier of movement |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **movement**
  - **movement** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `order_id`: string — Order id
    - `reference` → **reference**
      - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
    - `amount` → **amount**
      - string [example: `100.0`] — amount
    - `payout_currency` → **currency_code**
      - string [example: `EUR`]
    - `amount_payout_currency`: string — Amount
    - `entry_type`: string — Type of movement
    - `date` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `value_date` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `currency` → **currency_code**
      - string [example: `EUR`]
    - `running_balance` → **amount**
      - string [example: `100.0`] — amount
- `meta` → **account_meta**
  - `count`: integer — Count of movements (typical one request and one fee)


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/statements`

**Summary:** Index statements

**Tags:** Virtual Bank / Statements

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data`: array of **statement_item**
  - **statement_item** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `kind`: string _enum: ['transactions', 'charges']_ — Status
    - `file_name` → **reference**
      - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
    - `from`: string — created after filter
    - `to`: string — created before filter
    - `virtual_account_number` → **virtual_account_number**
      - string [example: `29301655053`] — virtual account number
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `csv_file_id`: integer — id of the csv file
- `meta` → **total_count_pagination**
  - `cursor_next`: integer — Next page
  - `cursor_prev`: integer — Previous page
  - `has_next_page`: boolean — Has next page
  - `has_prev_page`: boolean — Has prev page
  - `total_count`: integer — Total number of items


---

## `POST /customer_app_api/virtual_bank/organisations/{organisation_id}/statements`

**Summary:** Create statement

**Tags:** Virtual Bank / Statements

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |

### Request body

_Required._

**Content-Type:** `application/json`

- `virtual_account_number`: string
- `created_after`: string _(required)_ — Date
- `created_before`: string _(required)_ — Date
- `kind`: string — transactions or charges

### Responses

#### `200` Successful

**Content-Type:** `application/json`

- `data` → **new_statement**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `from`: string — created after filter
  - `to`: string — created before filter
  - `account_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `reference` → **reference**
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `period`: string
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `updated_at` → **updated_at**
    - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated
  - `version`: integer
  - `kind`: string — transactions or charges
  - `status`: string — created, scheduled, in_progress, failed or completed

#### `422` Unprocessable Entity


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/statements/{statement_id}`

**Summary:** Show statement

**Tags:** Virtual Bank / Statements

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `statement_id` | path | integer | yes | statement id |

### Responses

#### `200` Gets the statement

**Content-Type:** `application/json`

- `data` → **statement_item**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `kind`: string _enum: ['transactions', 'charges']_ — Status
  - `file_name` → **reference**
    - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
  - `from`: string — created after filter
  - `to`: string — created before filter
  - `virtual_account_number` → **virtual_account_number**
    - string [example: `29301655053`] — virtual account number
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `csv_file_id`: integer — id of the csv file

#### `422` Bad id

**Content-Type:** `application/json`

- `error` → **error_generic_with_code_detail_object**
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: string _(required)_


---

## `GET /customer_app_api/virtual_bank/organisations/{organisation_id}/statements/{file_id}/download`

**Summary:** Download statement file

**Tags:** Virtual Bank / Statements

### Parameters

| Name | In | Type | Required | Description |
|------|-----|------|----------|-------------|
| `Authorization` | header | string | yes | Authentication token |
| `organisation_id` | path | integer | yes | Organisation ID |
| `file_id` | path | integer | yes | statement file (csv only) id |

### Responses

#### `200` Successful

**Content-Type:** `text/csv`

- string [example: `csv content`]


---

# Schemas / Definitions

## `id`

Unique Identifier

- integer [example: `1`] — Unique Identifier

---

## `organisation_id`

- integer [example: `1`]

---

## `access_token`

- string [example: `Bearer eyJraWQiOiJodVNwUVhhd0VxeTg1eHBXZEpBWGVhYXNiNzJON0JHeEFmVTEwUzItQ1ZVIiwiYWxnIjoiUlMyNTYifQ.eyJleHAiOjE3NjQyNTA0ODMsImlzcyI6IklucGF5IiwiaWF0IjoxNzY0MjQ2ODg0LCJqdGkiOiI1NDRjYmE4My0xNDk5LTRjZjktYTkxZC1kYmJhYzA4NDgyZDAiLCJ1c2VyIjp7ImlkIjo0OTZ9LCJzY29wZXMiOiJkYXNoYm9hcmQiLCJpbXBlcnNvbmF0aW5nIjpmYWxzZX0.qtWlQX767YuuM8s2TxZBfmZN2R1Jgkdj4yyddo6lgu6Ums6psfs0F6tOOc9D5tyr6TAbcZz3-uA4z_r7Gm72dyMrJlZbs4yCRQ8nk0PAFlmHD0pC1U20NFsQefF9F3SvkRShqVRUyDY9pK2URCp7WnxV08jNR1xaE6zI4WaC4KGWuzyYjQmkSqLJDywOlcRVOjWhbpjeI6pkEtjNBOFeuJ15cixlqyAPDXtH-G9KpyS7w6Xs6cIMNen8FOMEN8p-vzZZlbKH-kvaZujhWTMtsMq2lxgM-MykgrvwGZRquRvPC4NKnPuXaMenAtvSg8aeBgm3HT__3eBM1Q0Q-Fx1bmrfZUd4pRPz_bpCQlNgo_bkW8jRjnl7ZtLdLWJnQfO7Ms08l2ZQKn7xXDxhh_uISuxn7mWmcqytUTLmT1NpDNGjqYFzc_oGOYBQ1TAdGKEbl3gvyZbcmOhgtWeDxCnu3Ox0gwBwijPlCUUYyF_bHToOvOuPg47W8Db-pZw7XiE62334kDulNl30wmz_IttV10TUMbWRKbbEM3tb6SczfzUNCHR6dQb_GO8QTTfCj4X7X_DwaNoB6tjbEaAD7OxZyPq7UEigWLc90oIi7W6Re_d3jt7lq12RUPWWm46ierO7tcSlLAjJsTjLGSXre1jlGX_0IqIqGSOStb6UIlPjudA`]

---

## `code`

- string [example: `19MLNzmAhMHyzzByby3XsWvqzZDN7_WgjCJKUpi5gsI`]

---

## `creator_id`

User id

- integer [example: `5`] — User id

---

## `creator_type`

- string [example: `Customer::User`]

---

## `amount`

amount

- string [example: `100.0`] — amount

---

## `creditor_account_uuid`

Creditor account uuid

- string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid

---

## `creator_name`

- string [example: `Miss Money`]

---

## `country_name`

Country name

- string [example: `Denmark`] — Country name

---

## `currency_code`

- string [example: `EUR`]

---

## `currency_iso`

Currency ISO code

- string [example: `EUR`] — Currency ISO code

---

## `currency_name`

- string [example: `Euro`]

---

## `country_iso`

Country ISO

- string [example: `DK`] — Country ISO

---

## `external_reference`

Unique reference end to end id

- string [example: `chosen_id`] — Unique reference end to end id

---

## `email`

- string [example: `johndoe@inpay.com`]

---

## `full_name`

- string [example: `John Doe`]

---

## `id_expiry_date`

- string [example: `2030-05-22`]

---

## `id_issuing_country_code`

- string [example: `DK`]

---

## `id_issuing_date`

- string [example: `2020-05-22`]

---

## `id_number`

- string [example: `1234567`]

---

## `id_type`

- string [example: `Passport`]

---

## `inpay_unique_reference`

Our unique reference

- string [example: `d1a2b3c4d5`] — Our unique reference

---

## `reference`

Reference

- string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference

---

## `status`

Status

- string [example: `received`] — Status

---

## `ok_status`

- string [example: `ok`]

---

## `creditor_type`

Account holder type

- string [enum: ['organization', 'private'], example: `private`] — Account holder type

---

## `transfer_amount`

Transfer amount

- integer [example: `10.0`] — Transfer amount

---

## `transfer_currency_code`

Transfer currency code

- string [example: `EUR`] — Transfer currency code

---

## `provider_capability_id`

Provider capability id

- string [example: ``] — Provider capability id

---

## `debtor_account_number`

Debtor account number

- string [example: `29301655053`] — Debtor account number

---

## `virtual_account_number`

virtual account number

- string [example: `29301655053`] — virtual account number

---

## `created_at`

Datetime when the record was created

- string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `updated_at`

Datetime when the record was last updated

- string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

---

## `withdrawal_status`

<all> is only for frontend use

- string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use

---

## `state`

- string [example: `CA`]

---

## `street_name`

- string [example: `5181 MacGyver Thunder`]

---

## `status_transitions`

- array, items:
  - **status_transition** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `status_category` → **withdrawal_status**
      - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use

---

## `status_transition`

For Details > History section

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status_category` → **withdrawal_status**
  - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use

---

## `status_transitions_with_reason_code`

- array, items:
  - **status_transition_with_reason_code** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `status` → **withdrawal_status** _(required)_
      - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
    - `reason_code` → **withdrawal_reason_code** _(required)_
      - `reason`: string _(required)_
      - `external_message`: string _(required)_

---

## `status_transition_with_reason_code`

For Details > History section

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status` → **withdrawal_status** _(required)_
  - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
- `reason_code` → **withdrawal_reason_code** _(required)_
  - `reason`: string _(required)_
  - `external_message`: string _(required)_

---

## `role_name`

admin, operations member or reviewer

- string [example: `admin`] — admin, operations member or reviewer

---

## `reason_code_object`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `reason_code_id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `kind`: string _(required)_
- `group`: string _(required)_
- `symbol`: string _(required)_
- `external_message`: string _(required)_
- `reason`: string _(required)_

---

## `withdrawal_reason_code`

- `reason`: string _(required)_
- `external_message`: string _(required)_

---

## `disbursement_party_identification`

- `full_name`: string _(required)_
- `birthdate`: string _(required)_
- `address`: string _(required)_
- `city`: string _(required)_
- `country_code` → **country_iso** _(required)_
  - string [example: `DK`] — Country ISO
- `postal_code`: string
- `email`: string _(required)_
- `mobile_number`: string _(required)_
- `vop_result`: string
- `vop_matched_name`: string

---

## `party_identification`

- `address_lines`: string — Creditor address
- `city`: string — Creditor city
- `country_code` → **country_iso**
  - string [example: `DK`] — Country ISO
- `name`: string — Creditor name
- `postcode`: string — Creditor postcode
- `type`: string — Account holder type
- `birthdate`: string — Dob

---

## `creditor_account`

- `iban`: string _(required)_
- `account_number`: string _(required)_
- `account_number_type`: string _(required)_
- `bank_bic`: string _(required)_
- `bank_name`: string _(required)_
- `bank_clearing_system_id`: string _(required)_
- `bank_clearing_system_code`: string _(required)_
- `bank_branch_id`: integer _(required)_
- `bank_branch_name`: integer _(required)_
- `country_code`: string _(required)_

---

## `party_identification_account`

- `id`: string
- `account_number`: string
- `bank_bic`: string
- `bank_branch_id`: integer
- `bank_clearing_system_code`: integer
- `country_code`: string
- `iban`: string
- `type`: string

---

## `intermediary_agent`

- `bank_bic`: string _(required)_
- `bank_name`: string _(required)_

---

## `intermediary_agent_account`

- `account_number`: string _(required)_
- `iban`: string _(required)_

---

## `success`

- `success`: boolean — Successful operation response

---

## `attachment`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `file_name` → **file_name** _(required)_
  - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
- `format`: string _(required)_
- `owner_id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `owner_type`: string _(required)_ _enum: ['Disbursement::PaymentRequest', 'Disbursement::PaymentRequestDraft', 'Disbursement::PaymentRequestBatch']_
- `creator_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `creator_type`: string _enum: ['Customer::User', 'Admin::User']_
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `cancellations`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `initiator_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `initiator_name` → **creator_name**
  - string [example: `Miss Money`]
- `initiator_type`: string _enum: ['Customer::User', 'Admin::User', 'Customer::Organisation']_
- `created_at`: string
- `status`: string

---

## `feature_flag`

- `customer-app-canary-ui`: boolean
- `CBP-1761-customer-app-batches`: boolean
- `CBP-2001-approval-workflow-manual-payouts`: boolean
- `CBP-2870-withdrawal-accounts-enabled`: boolean
- `CBP-8000-receiver-management`: boolean
- `CBP-10746-e2e-test-cases-field-enabled`: boolean
- `PEGO-12125-insight-section-customer-app`: boolean
- `PEGO-12738-sandbox-customer-app-api-docs`: boolean
- `PEGO-12664-create-receiver`: boolean

---

## `review`

Approval or rejection

- `user_id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `user_name` → **creator_name** _(required)_
  - string [example: `Miss Money`]
- `approved`: boolean _(required)_

---

## `payout_review`

- `reviewer_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `created_at`: string
- `reviewer_name` → **creator_name**
  - string [example: `Miss Money`]
- `approved`: boolean

---

## `uuid`

uuidV4

- string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4

---

## `file_name`

contains file type

- string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type

---

## `payout_report_name`

report_uuid

- string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid

---

## `payout_report_data`

csv content

- string [example: `Account,Created At,Inpay Reference,End-to-End ID,Status,Reason Codes,Amount,Currency
`] — csv content

---

## `payout_report`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `processing_state`: string — available
- `uuid` → **payout_report_name**
  - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `created_after`: string — created after filter
- `created_before`: string — created before filter
- `state_categories`: array of string
- `amount_from`: string — amount from filter
- `amount_to`: string — amount to filter
- `reason_codes`: array of string
- `business_unit_name`: string — business unit filter
- `local_instrument`: string — local instrument filter
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `virtual_account_number` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number
- `organisation_id` → **organisation_id**
  - integer [example: `1`]
- `creator_id` → **creator_id**
  - integer [example: `5`] — User id
- `creator_type` → **creator_type**
  - string [example: `Customer::User`]
- `filename` → **payout_report_name**
  - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **updated_at**
  - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

---

## `payout_reports`

- `uuid` → **payout_report_name**
  - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `created_after`: string — created after filter
- `created_before`: string — created before filter
- `state_categories`: array of string
- `amount_from`: string — amount from filter
- `amount_to`: string — amount to filter
- `reason_codes`: array of string
- `business_unit_name`: string — business unit filter
- `local_instrument`: string — local instrument filter
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `virtual_account_number` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number
- `organisation_id` → **organisation_id**
  - integer [example: `1`]
- `creator_id` → **creator_id**
  - integer [example: `5`] — User id
- `creator_type` → **creator_type**
  - string [example: `Customer::User`]
- `filename` → **payout_report_name**
  - string [example: `n0yUx0oGs81NAta8IYywIHhI00Dd0GmY33Y`] — report_uuid
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **updated_at**
  - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

---

## `payout_request`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `inpay_unique_reference` → **inpay_unique_reference** _(required)_
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `end_to_end_id`: string _(required)_ — end-to-end id
- `local_instrument`: string _(required)_
- `business_unit`: string _(required)_
- `amount` → **amount** _(required)_
  - string [example: `100.0`] — amount
- `batch_id`: integer _(required)_
- `source`: string _(required)_ — manual, csv or api
- `currency` → **currency_code** _(required)_
  - string [example: `EUR`]
- `status`: string _(required)_ _enum: ['received', 'rejected', 'returned', 'action_required', 'completed', 'pending', 'processing']_
- `creator_id`: number _(required)_ — creator id
- `creator_name`: string _(required)_
- `current_state_name`: string _(required)_ _enum: ['created', 'capability_selected', 'validating_external', 'validated', 'unable_to_validate_external', 'waiting_future_execution', 'tstm_initiated', 'tstm_screened', 'ready_for_v1', 'scheduled_for_processing', 'converting_to_v1', 'conversion_to_v1_failed', 'converted_to_v1', 'ready_for_transaction_screening', 'transaction_screening_in_process', 'reviewing_transaction_screening', 'added_to_payout_planner', 'halted', 'rerouted_to_different_provider', 'accepted_by_processing_provider', 'reconciliation_completed', 'missing_capability', 'validation_schema_failed', 'external_validation_failed', 'payment_request_cancelled', 'payment_returned', 'awaiting_kyc_documents', 'awaiting_extended_kyc', 'insufficient_funds']_
- `timestamp`: string _(required)_
- `requested_execution_date` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `purpose_code`: string _(required)_
- `debtor` → **payout_debtor** _(required)_
  - `full_name`: string _(required)_
  - `website`: string _(required)_
- `ultimate_debtor` → **disbursement_party_identification** _(required)_
  - `full_name`: string _(required)_
  - `birthdate`: string _(required)_
  - `address`: string _(required)_
  - `city`: string _(required)_
  - `country_code` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `postal_code`: string
  - `email`: string _(required)_
  - `mobile_number`: string _(required)_
  - `vop_result`: string
  - `vop_matched_name`: string
- `creditor` → **disbursement_party_identification** _(required)_
  - `full_name`: string _(required)_
  - `birthdate`: string _(required)_
  - `address`: string _(required)_
  - `city`: string _(required)_
  - `country_code` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `postal_code`: string
  - `email`: string _(required)_
  - `mobile_number`: string _(required)_
  - `vop_result`: string
  - `vop_matched_name`: string
- `creditor_account` → **creditor_account** _(required)_
  - `iban`: string _(required)_
  - `account_number`: string _(required)_
  - `account_number_type`: string _(required)_
  - `bank_bic`: string _(required)_
  - `bank_name`: string _(required)_
  - `bank_clearing_system_id`: string _(required)_
  - `bank_clearing_system_code`: string _(required)_
  - `bank_branch_id`: integer _(required)_
  - `bank_branch_name`: integer _(required)_
  - `country_code`: string _(required)_
- `intermediary_agent` → **intermediary_agent** _(required)_
  - `bank_bic`: string _(required)_
  - `bank_name`: string _(required)_
- `intermediary_agent_account` → **intermediary_agent_account** _(required)_
  - `account_number`: string _(required)_
  - `iban`: string _(required)_
- `debtor_account` → **reconciliation_virtual_account** _(required)_
  - `number`: string
  - `currency`: string
- `reason_codes`: array of **reason_code_object** _(required)_
  - **reason_code_object** (ref)
    - `id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `reason_code_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `kind`: string _(required)_
    - `group`: string _(required)_
    - `symbol`: string _(required)_
    - `external_message`: string _(required)_
    - `reason`: string _(required)_
- `payment_request_state_reason_codes`: array of object _(required)_
  - `reason_code_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `meta`: object
- `status_transitions`: array of object _(required)_
  - `name`: string _(required)_
  - `timestamp`: string _(required)_
- `cancellations`: array of **cancellations** _(required)_
  - **cancellations** (ref)
    - `id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `initiator_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `initiator_name` → **creator_name**
      - string [example: `Miss Money`]
    - `initiator_type`: string _enum: ['Customer::User', 'Admin::User', 'Customer::Organisation']_
    - `created_at`: string
    - `status`: string
- `reviews`: array of **payout_review** _(required)_
  - **payout_review** (ref)
    - `reviewer_id` → **id**
      - integer [example: `1`] — Unique Identifier
    - `created_at`: string
    - `reviewer_name` → **creator_name**
      - string [example: `Miss Money`]
    - `approved`: boolean
- `errors`: object _(required)_

---

## `payout_request_item`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `business_unit_id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `batch_id`: integer
- `execution_date`: string _(required)_
- `source`: string _enum: ['api', 'csv', 'manual', 'iso_20022']_
- `state`: string _(required)_ _enum: ['received', 'pending', 'processing', 'completed', 'rejected', 'returned', 'action_required']_ — state category name
- `local_instrument`: string _(required)_
- `end_to_end_id`: string
- `inpay_unique_reference` → **inpay_unique_reference**
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `amount` → **amount** _(required)_
  - string [example: `100.0`] — amount
- `debtor_account` → **virtual_account_number** _(required)_
  - string [example: `29301655053`] — virtual account number
- `currency` → **currency_code** _(required)_
  - string [example: `EUR`]
- `attachments_count`: integer _(required)_

---

## `payout_drafts_item`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `source`: string _(required)_ — manual or batch
- `attachments_count`: integer _(required)_
- `status`: string _(required)_ _enum: ['waiting_review', 'rejected']_ — waiting_approval or rejected
- `creator_name`: string
- `local_instrument`: string
- `corridor`: string
- `approvers_count`: integer — number of current approvals
- `end_to_end_id`: string — end-to-end id
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `debtor_account` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number
- `currency` → **currency_code**
  - string [example: `EUR`]

---

## `payout_draft`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `approvers_count`: integer _(required)_ — number of current approvals
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `debtor`: object
  - `name`: string
  - `website`: string
- `ultimate_debtor` → **party_identification**
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type
  - `birthdate`: string — Dob
- `creditor` → **party_identification**
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type
  - `birthdate`: string — Dob
- `creditor_account` → **party_identification_account**
  - `id`: string
  - `account_number`: string
  - `bank_bic`: string
  - `bank_branch_id`: integer
  - `bank_clearing_system_code`: integer
  - `country_code`: string
  - `iban`: string
  - `type`: string
- `intermediary_agent` → **intermediary_agent**
  - `bank_bic`: string _(required)_
  - `bank_name`: string _(required)_
- `intermediary_agent_account` → **intermediary_agent_account**
  - `account_number`: string _(required)_
  - `iban`: string _(required)_
- `debtor_account`: object
  - `id`: number
  - `scheme_name`: string
- `creator_name`: string _(required)_ — user name
- `source`: string _(required)_ — manual or batch
- `user_id`: number — creator id
- `status`: string _(required)_ _enum: ['waiting_review', 'rejected']_ — waiting_review or rejected
- `end_to_end_id`: string — end-to-end id
- `local_instrument`: string _(required)_
- `corridor`: string _(required)_
- `approvals`: array of **review**
  - **review** (ref)
    - `user_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `user_name` → **creator_name** _(required)_
      - string [example: `Miss Money`]
    - `approved`: boolean _(required)_
- `rejections`: array of **review**
  - **review** (ref)
    - `user_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `user_name` → **creator_name** _(required)_
      - string [example: `Miss Money`]
    - `approved`: boolean _(required)_

---

## `schema_fields_definition`

- `data`: object _(required)_
  - `creditor`: object _(required)_
  - `creditor_account`: object _(required)_
  - `intermediary_agent`: object
  - `intermediary_agent_account`: object

---

## `created_payout_draft`

- `data`: object _(required)_
  - `draft_id`: integer _(required)_
  - `product`: object _(required)_
    - `local_instrument`: string _(required)_
    - `product_id`:  _(required)_
    - `schema_id`:  _(required)_
  - `payout_request`: object _(required)_
  - `ultimate_debtor`: object _(required)_
  - `creditor`: object _(required)_
  - `creditor_account`: object _(required)_
  - `debtor`: object _(required)_
  - `intermediary_agent`: object
  - `intermediary_agent_account`: object

---

## `FieldObject`

- `ui_field`: string _(required)_ _enum: ['text', 'datepicker']_
- `rules`: object
- `value`:  _(required)_
- `errors`: array of string _(required)_

---

## `payout_batch`

- `id`: integer _(required)_
- `name` → **file_name**
  - string [example: `2nCvGRvlUDvBevQ1WfeZfJHu9hq1QZFxCOy.csv`] — contains file type
- `kind`: string — batch kind (iso or csv)
- `status`: string _enum: ['waiting_review', 'completed', 'rejected']_
- `local_instrument`: string
- `total_payout_requests_count`: integer
- `total_amount`: integer
- `currency`: object
  - `iso` → **currency_iso** _(required)_
    - string [example: `EUR`] — Currency ISO code
  - `name` → **currency_name** _(required)_
    - string [example: `Euro`]
- `country`: object
  - `iso` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `name` → **country_name** _(required)_
    - string [example: `Denmark`] — Country name
- `approvers_count`: integer
- `accepted_payout_requests_count`: integer
- `creator_id` → **creator_id**
  - integer [example: `5`] — User id
- `creator_name` → **creator_name**
  - string [example: `Miss Money`]
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `approvals`: array of **review**
  - **review** (ref)
    - `user_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `user_name` → **creator_name** _(required)_
      - string [example: `Miss Money`]
    - `approved`: boolean _(required)_
- `rejections`: array of **review**
  - **review** (ref)
    - `user_id` → **id** _(required)_
      - integer [example: `1`] — Unique Identifier
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
    - `user_name` → **creator_name** _(required)_
      - string [example: `Miss Money`]
    - `approved`: boolean _(required)_

---

## `created_batch_meta`

- `local_instrument`: string _(required)_
- `total_payout_requests`: integer _(required)_
- `total_payout_requests_amount`: integer _(required)_
- `currency`: object _(required)_
  - `iso` → **currency_iso** _(required)_
    - string [example: `EUR`] — Currency ISO code
  - `name` → **currency_name** _(required)_
    - string [example: `Euro`]
- `country`: object _(required)_
  - `iso` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `name` → **country_name** _(required)_
    - string [example: `Denmark`] — Country name

---

## `created_batch_data`

- `filename`: string _(required)_
- `format`: string _(required)_ — file format
- `batch_id`: integer _(required)_

---

## `payout_batches`

- `id`: integer _(required)_
- `name`: string _(required)_
- `kind`: string _(required)_ — batch kind (iso or csv)
- `status`: string _(required)_ _enum: ['waiting_review', 'completed', 'rejected']_
- `local_instrument`: string _(required)_
- `total_payout_requests_count`: integer
- `total_amount`: integer
- `currency`: object _(required)_
  - `iso` → **currency_iso** _(required)_
    - string [example: `EUR`] — Currency ISO code
  - `name` → **currency_name** _(required)_
    - string [example: `Euro`]
- `country`: object _(required)_
  - `iso` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `name` → **country_name** _(required)_
    - string [example: `Denmark`] — Country name
- `approvers_count`: integer
- `attachments_count`: integer _(required)_
- `creator_id` → **creator_id**
  - integer [example: `5`] — User id
- `creator_name` → **creator_name**
  - string [example: `Miss Money`]
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `batch_draft`

- `amount`: string _(required)_
- `currency_code`: string _(required)_
- `local_instrument`: string _(required)_
- `end_to_end_id`: string _(required)_ — end-to-end id
- `state`: string _(required)_ — received, waiting_approval or rejected
- `batch_id`: string _(required)_
- `source`: string — manual, csv or api
- `creditor` → **party_identification** _(required)_
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type
  - `birthdate`: string — Dob
- `creditor_account` → **party_identification_account** _(required)_
  - `id`: string
  - `account_number`: string
  - `bank_bic`: string
  - `bank_branch_id`: integer
  - `bank_clearing_system_code`: integer
  - `country_code`: string
  - `iban`: string
  - `type`: string
- `debtor` → **party_identification** _(required)_
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type
  - `birthdate`: string — Dob
- `debtor_account` → **party_identification_account** _(required)_
  - `id`: string
  - `account_number`: string
  - `bank_bic`: string
  - `bank_branch_id`: integer
  - `bank_clearing_system_code`: integer
  - `country_code`: string
  - `iban`: string
  - `type`: string
- `ultimate_debtor` → **party_identification** _(required)_
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type
  - `birthdate`: string — Dob

---

## `batch_drafts_item`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `amount`: number _(required)_ — amount
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `currency` → **currency_code** _(required)_
  - string [example: `EUR`]
- `debtor_account`: string _(required)_
- `attachments_count`: integer _(required)_
- `state`: string _(required)_ — received, waiting_approval or rejected
- `end_to_end_id`: string _(required)_ — end-to-end id

---

## `preferred_pagination`

- `cursor_next`: string _(required)_ — Next page
- `cursor_prev`: string _(required)_ — Previous page
- `has_next_page`: boolean _(required)_ — Has next page
- `has_prev_page`: boolean _(required)_ — Has prev page
- `total`: integer _(required)_ — Total number of items

---

## `pagination`

- `cursor_next`: integer — Next page
- `cursor_prev`: integer — Previous page
- `has_next_page`: boolean — Has next page
- `has_prev_page`: boolean — Has prev page
- `total`: integer — Total number of items

---

## `orders_index_pagination`

- `cursor_before`: string — Next page
- `cursor_after`: string — Next page
- `total`: integer — Total number of items
- `has_orders`: boolean — Has orders

---

## `total_count_pagination`

- `cursor_next`: integer — Next page
- `cursor_prev`: integer — Previous page
- `has_next_page`: boolean — Has next page
- `has_prev_page`: boolean — Has prev page
- `total_count`: integer — Total number of items

---

## `statement_item`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `kind`: string _enum: ['transactions', 'charges']_ — Status
- `file_name` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `from`: string — created after filter
- `to`: string — created before filter
- `virtual_account_number` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `csv_file_id`: integer — id of the csv file

---

## `new_statement`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `from`: string — created after filter
- `to`: string — created before filter
- `account_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `reference` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `period`: string
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **updated_at**
  - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated
- `version`: integer
- `kind`: string — transactions or charges
- `status`: string — created, scheduled, in_progress, failed or completed

---

## `payout_debtor`

- `full_name`: string _(required)_
- `website`: string _(required)_

---

## `debtor`

- `email` → **email**
  - string [example: `johndoe@inpay.com`]
- `full_name` → **full_name**
  - string [example: `John Doe`]
- `date_of_birth`: string
- `country_of_residence` → **country_iso**
  - string [example: `DK`] — Country ISO
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `configuration`

- `throttling`: string — Irrelevant
- `batch_number_of_approvers`: string — Number
- `manual_payout_number_of_approvers`: string — Number
- `virtual_bank_bookkeeping`: string — v1 / v2 / dual
- `withdrawals_enabled`: string — Either on/off
- `fx_rate_end_point`: string — Irrelevant
- `manual_payouts_enabled`: string — 1 if turned on
- `batches_enabled`: string — Either on/off
- `fx_widget_enabled`: string — Either on/off
- `crypto_widget_variant`: string — c2c / bigedirect / layer 1
- `customer_ab_testing`: string — Either on/off

---

## `account`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `account_number`: string — Account number
- `name`: string — Account Name (default is '<currency> account')
- `balance`: string — latest balance on account
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `currency_name` → **currency_name**
  - string [example: `Euro`]
- `has_transactions`: boolean — Boolean telling if the account has any transactions
- `owner`: boolean — Boolean telling if the account is owned by the requesting organisation
- `status`: string _enum: ['active', 'suspended', 'terminated']_ — account can be active, suspended or terminated

---

## `account_meta`

- `count`: integer — Count of movements (typical one request and one fee)

---

## `account_summary`

- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `current_balance`: string
- `opening_balance`: string
- `closing_balance`: string

---

## `address`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `line1`: string — Line 1 of the organisation address
- `line2`: string — Line 2 of the organisation address
- `city`: string — City
- `state`: string — State
- `postal_code`: string — Postal code
- `country`: object
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `iso`: string — Country ISO code
  - `name`: string — Country name
- `organisation_name`: string — Name of the organisation

---

## `movement`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `order_id`: string — Order id
- `reference` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `payout_currency` → **currency_code**
  - string [example: `EUR`]
- `amount_payout_currency`: string — Amount
- `entry_type`: string — Type of movement
- `date` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `value_date` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `currency` → **currency_code**
  - string [example: `EUR`]
- `running_balance` → **amount**
  - string [example: `100.0`] — amount

---

## `movable`

- `user_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `internal_remarks`: string — Additional info

---

## `accepted_funding_configuration`

- `banking_rail_id`: number
- `currency_iso` → **currency_iso**
  - string [example: `EUR`] — Currency ISO code
- `email`: string
- `funding_reference`: string — account number or custom
- `inpay_bank_account_id`: number
- `organisation_id` → **organisation_id**
  - integer [example: `1`]
- `owner_name`: string
- `provider_inpay_bank_account_id`: number
- `uuid` → **uuid**
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `virtual_account_number` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number

---

## `funding_configuration`

- `changed`: boolean _(required)_ — states whether or not the instructions have been updated in admin
- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `funding_reference`: string _(required)_ — Typically account number, but can be custom
- `virtual_account_number` → **virtual_account_number** _(required)_
  - string [example: `29301655053`] — virtual account number
- `currency_iso` → **currency_iso** _(required)_
  - string [example: `EUR`] — Currency ISO code
- `beneficiary` → **funding_configuration_beneficiary**
  - `full_name`: string
  - `bank_name`: string
  - `bank_address`: string
  - `iban`: string
  - `account_number`: string
  - `sort_code`: string
  - `swift_code`: string
  - `wallet_address`: string
  - `crypto_network`: string

---

## `funding_configuration_beneficiary`

- `full_name`: string
- `bank_name`: string
- `bank_address`: string
- `iban`: string
- `account_number`: string
- `sort_code`: string
- `swift_code`: string
- `wallet_address`: string
- `crypto_network`: string

---

## `funding_configurations`

- `virtual_account_number`: array of **funding_configuration**
  - **funding_configuration** (ref)
    - `changed`: boolean _(required)_ — states whether or not the instructions have been updated in admin
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `funding_reference`: string _(required)_ — Typically account number, but can be custom
    - `virtual_account_number` → **virtual_account_number** _(required)_
      - string [example: `29301655053`] — virtual account number
    - `currency_iso` → **currency_iso** _(required)_
      - string [example: `EUR`] — Currency ISO code
    - `beneficiary` → **funding_configuration_beneficiary**
      - `full_name`: string
      - `bank_name`: string
      - `bank_address`: string
      - `iban`: string
      - `account_number`: string
      - `sort_code`: string
      - `swift_code`: string
      - `wallet_address`: string
      - `crypto_network`: string

---

## `internal_account_movement`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `date` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `reason`: string — Type
- `reference` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `movable_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `movable_type`: string — Type of movement
- `account_id` → **id**
  - integer [example: `1`] — Unique Identifier
- `movable` → **movable**
  - `user_id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `internal_remarks`: string — Additional info

---

## `virtual_bank_account`

- `id`: integer — Unique identifier for the account
- `account_number`: string — The account number
- `balance`: string (decimal) — The current balance of the account
- `currency_code`: string — The three-letter ISO code for the account's currency
- `currency_name`: string — The name of the account's currency
- `has_transactions`: boolean — Whether the account has any transactions
- `name`: string — The name of the account
- `owner`: boolean — Whether the account is owned by the current user

---

## `schema_example_product`

- `example`: string — The example string
- `schema`: object — The schema of the example
  - `schema_fields`: array of **schema_field** — The schema fields
    - **schema_field** (ref)
      - `field`: string — The name of the field
      - `description`: string — A brief description of the field
      - `type`: string — The data type of the field
      - `rules`: array of object
        - `description`: string — A brief description of the rule
        - `hint`: string — A hint for the rule
  - `organisation`: object — The organisation
    - `id`: integer — The organisation id
    - `name`: string — The organisation name
    - `country_code`: string
  - `payout_product`: object — The payout product
    - `id`: integer — The product id
    - `currency`: string
    - `country`: string
  - `current_schema`: object — The current schema
    - `id`: integer — The schema id
    - `name`: string — The schema name
    - `description`: string — The schema description
    - `updated_at`: string
    - `label`: string
  - `available_schemas`: array of object — The available schemas
    - `id`: integer — The schema id
    - `name`: string — The schema name
    - `description`: string — The schema description
    - `updated_at`: string
    - `label`: string

---

## `schema_field`

- `field`: string — The name of the field
- `description`: string — A brief description of the field
- `type`: string — The data type of the field
- `rules`: array of object
  - `description`: string — A brief description of the rule
  - `hint`: string — A hint for the rule

---

## `v2_schema_example_product`

- `example`: string — The example string
- `schema`: object — The schema of the example
  - `product_fields`: array of **v2_schema_field** — The schema fields
    - **v2_schema_field** (ref)
      - `field`: string — The name of the field
      - `description`: string — A brief description of the field
      - `type`: string — The data type of the field
      - `rules`: array of object
        - `description`: string — A brief description of the rule
        - `hint`: string — A hint for the rule
  - `organisation`: object — The organisation
    - `id`: integer — The organisation id
    - `name`: string — The organisation name
  - `payout_v2_product`: object — The payout product
    - `id`: integer — The product id
    - `currency`: string
    - `country`: string

---

## `v2_schema_field`

- `field`: string — The name of the field
- `description`: string — A brief description of the field
- `type`: string — The data type of the field
- `rules`: array of object
  - `description`: string — A brief description of the rule
  - `hint`: string — A hint for the rule

---

## `impersonation_exchange_response`

- `access_token` → **access_token** _(required)_
  - string [example: `Bearer eyJraWQiOiJodVNwUVhhd0VxeTg1eHBXZEpBWGVhYXNiNzJON0JHeEFmVTEwUzItQ1ZVIiwiYWxnIjoiUlMyNTYifQ.eyJleHAiOjE3NjQyNTA0ODMsImlzcyI6IklucGF5IiwiaWF0IjoxNzY0MjQ2ODg0LCJqdGkiOiI1NDRjYmE4My0xNDk5LTRjZjktYTkxZC1kYmJhYzA4NDgyZDAiLCJ1c2VyIjp7ImlkIjo0OTZ9LCJzY29wZXMiOiJkYXNoYm9hcmQiLCJpbXBlcnNvbmF0aW5nIjpmYWxzZX0.qtWlQX767YuuM8s2TxZBfmZN2R1Jgkdj4yyddo6lgu6Ums6psfs0F6tOOc9D5tyr6TAbcZz3-uA4z_r7Gm72dyMrJlZbs4yCRQ8nk0PAFlmHD0pC1U20NFsQefF9F3SvkRShqVRUyDY9pK2URCp7WnxV08jNR1xaE6zI4WaC4KGWuzyYjQmkSqLJDywOlcRVOjWhbpjeI6pkEtjNBOFeuJ15cixlqyAPDXtH-G9KpyS7w6Xs6cIMNen8FOMEN8p-vzZZlbKH-kvaZujhWTMtsMq2lxgM-MykgrvwGZRquRvPC4NKnPuXaMenAtvSg8aeBgm3HT__3eBM1Q0Q-Fx1bmrfZUd4pRPz_bpCQlNgo_bkW8jRjnl7ZtLdLWJnQfO7Ms08l2ZQKn7xXDxhh_uISuxn7mWmcqytUTLmT1NpDNGjqYFzc_oGOYBQ1TAdGKEbl3gvyZbcmOhgtWeDxCnu3Ox0gwBwijPlCUUYyF_bHToOvOuPg47W8Db-pZw7XiE62334kDulNl30wmz_IttV10TUMbWRKbbEM3tb6SczfzUNCHR6dQb_GO8QTTfCj4X7X_DwaNoB6tjbEaAD7OxZyPq7UEigWLc90oIi7W6Re_d3jt7lq12RUPWWm46ierO7tcSlLAjJsTjLGSXre1jlGX_0IqIqGSOStb6UIlPjudA`]

---

## `in_app_alert`

- `id`: integer _(required)_ — The unique identifier of the alert
- `app_type`: string _(required)_ — The type of app the alert is for (e.g., 'customer_app', 'docs')
- `alert_type`: string _(required)_ — The type of alert (e.g., 'info', 'warning', 'error')
- `alert_message`: string _(required)_ — The message content of the alert
- `enabled`: boolean _(required)_ — Whether the alert is currently enabled or not

---

## `withdrawal_account`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `label`: string — Label
- `organisation_id`: number _(required)_ — Organisation id
- `account_number`: string — Account number
- `type`: string — Type
- `bank_bic`: string — Bank bic
- `bank_branch_name`: string — Bank branch name
- `bank_clearing_system_code`: string — Bank clearing system code
- `bank_name`: string — Bank name
- `country_code` → **country_iso** _(required)_
  - string [example: `DK`] — Country ISO
- `currency`: string _(required)_ — Currency
- `iban`: string — Iban
- `local_instrument`: string — Local instrument
- `bank_branch_id`: string — Bank branch id
- `bank_clearing_system_id`: string — Bank clearing system id
- `status`: string _(required)_ _enum: ['created', 'pending_approval', 'active', 'inactive', 'rejected']_ — Status
- `party_identification`: object
  - `address_lines`: string — Creditor address
  - `city`: string — Creditor city
  - `country_code` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `name`: string — Creditor name
  - `postcode`: string — Creditor postcode
  - `type`: string — Account holder type

---

## `withdrawal_account_authorization`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `withdrawal_account_uuid` → **uuid**
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `virtual_bank_account_number` → **virtual_account_number**
  - string [example: `29301655053`] — virtual account number

---

## `withdrawal_request`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `creditor_account_uuid` → **creditor_account_uuid**
  - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `external_reference` → **external_reference**
  - string [example: `chosen_id`] — Unique reference end to end id
- `reference` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `debtor_account_number` → **debtor_account_number**
  - string [example: `29301655053`] — Debtor account number
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `withdrawal_requests`

- `id` → **id**
  - integer [example: `1`] — Unique Identifier
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `creditor_account_uuid` → **creditor_account_uuid**
  - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `debtor_account_number` → **debtor_account_number**
  - string [example: `29301655053`] — Debtor account number
- `external_reference` → **external_reference**
  - string [example: `chosen_id`] — Unique reference end to end id
- `reference` → **reference**
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `status` → **withdrawal_status**
  - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `withdrawal_request_with_account`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `amount` → **amount** _(required)_
  - string [example: `100.0`] — amount
- `creditor_account_uuid` → **creditor_account_uuid** _(required)_
  - string [example: `D5eS7rU9PgOQxsn8VwFBBNod3071U0Ev4a1`] — Creditor account uuid
- `currency_code` → **currency_code** _(required)_
  - string [example: `EUR`]
- `external_reference` → **external_reference**
  - string [example: `chosen_id`] — Unique reference end to end id
- `reference` → **reference** _(required)_
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `status` → **withdrawal_status** _(required)_
  - string [enum: ['received', 'processing', 'completed', 'rejected', 'returned'], example: `received`] — <all> is only for frontend use
- `transfer_amount` → **transfer_amount**
  - integer [example: `10.0`] — Transfer amount
- `transfer_currency_code` → **transfer_currency_code**
  - string [example: `EUR`] — Transfer currency code
- `provider_capability_id` → **provider_capability_id**
  - string [example: ``] — Provider capability id
- `debtor_account_number` → **debtor_account_number** _(required)_
  - string [example: `29301655053`] — Debtor account number
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status_transitions` → **status_transitions_with_reason_code** _(required)_
  - array, items:
    - **status_transition_with_reason_code** (ref)
      - `id` → **id**
      - `created_at` → **created_at** _(required)_
      - `status` → **withdrawal_status** _(required)_
      - `reason_code` → **withdrawal_reason_code** _(required)_
- `creditor_account` → **withdrawal_account**
  - `id` → **id**
    - integer [example: `1`] — Unique Identifier
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `label`: string — Label
  - `organisation_id`: number _(required)_ — Organisation id
  - `account_number`: string — Account number
  - `type`: string — Type
  - `bank_bic`: string — Bank bic
  - `bank_branch_name`: string — Bank branch name
  - `bank_clearing_system_code`: string — Bank clearing system code
  - `bank_name`: string — Bank name
  - `country_code` → **country_iso** _(required)_
    - string [example: `DK`] — Country ISO
  - `currency`: string _(required)_ — Currency
  - `iban`: string — Iban
  - `local_instrument`: string — Local instrument
  - `bank_branch_id`: string — Bank branch id
  - `bank_clearing_system_id`: string — Bank clearing system id
  - `status`: string _(required)_ _enum: ['created', 'pending_approval', 'active', 'inactive', 'rejected']_ — Status
  - `party_identification`: object
    - `address_lines`: string — Creditor address
    - `city`: string — Creditor city
    - `country_code` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `name`: string — Creditor name
    - `postcode`: string — Creditor postcode
    - `type`: string — Account holder type

---

## `organisations`

- `id`: integer — Organisation id
- `name`: string — Organisation name
- `country_code` → **country_iso**
  - string [example: `DK`] — Country ISO

---

## `customer_user_organisation`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `name`: string _(required)_ — organisation name
- `ordering_institution`: string _(required)_ — Public facing organisation name
- `default`: boolean _(required)_ — true means automatically chosen as active when initially logging on
- `role` → **role_name** _(required)_
  - string [example: `admin`] — admin, operations member or reviewer

---

## `business_unit`

- `id`: integer _(required)_
- `name`: string _(required)_
- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4

---

## `role`

- `name` → **role_name** _(required)_
  - string [example: `admin`] — admin, operations member or reviewer
- `description`: string — optional description

---

## `user`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `email`: string _(required)_
- `first_name`: string _(required)_
- `last_name`: string _(required)_
- `role` → **role_name** _(required)_
  - string [example: `admin`] — admin, operations member or reviewer
- `active`: boolean _(required)_
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **updated_at** _(required)_
  - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

---

## `user_item`

- `id` → **id** _(required)_
  - integer [example: `1`] — Unique Identifier
- `email`: string _(required)_
- `first_name`: string _(required)_
- `last_name`: string _(required)_
- `active`: boolean _(required)_ — inactive means removed from organisation
- `role` → **role_name** _(required)_
  - string [example: `admin`] — admin, operations member or reviewer
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `updated_at` → **updated_at** _(required)_
  - string (date-time) [example: `2020-01-02T00:00:00Z`] — Datetime when the record was last updated

---

## `customer_app_contracted_products`

- `id`: integer — ID
- `product_id`: integer — Product Id
- `product_currency_iso`: string — Currency of the product

---

## `contracted_products`

- `id`: integer — Product id
- `currency_iso` → **currency_iso**
  - string [example: `EUR`] — Currency ISO code
- `country_iso` → **country_iso**
  - string [example: `DK`] — Country ISO
- `label`: string — label
- `instrument`: string — label

---

## `reconciliation_virtual_account`

- `number`: string
- `currency`: string

---

## `debtor_account`

- `id`: string — The debtor account id
- `scheme_name`: string — The scheme used for the payout request

---

## `published_payout_request`

- `debtor_account` → **debtor_account**
  - `id`: string — The debtor account id
  - `scheme_name`: string — The scheme used for the payout request
- `end_to_end_id`: string — Sequential end-to-end id
- `inpay_unique_reference` → **inpay_unique_reference**
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `currency`: string — Currency of the payout
- `currency_code`: string — Currency of the draft
- `timestamp`: string — Datetime
- `state`: string — State of the payout request

---

## `order`

- `uuid` → **uuid**
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `reference`: string — A unique identifier in your system for this Order
- `debtor` → **debtor**
  - `email` → **email**
    - string [example: `johndoe@inpay.com`]
  - `full_name` → **full_name**
    - string [example: `John Doe`]
  - `date_of_birth`: string
  - `country_of_residence` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status`: string — Status of your order
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `amount_cents`: integer — Original amount in cents
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `created_at` → **created_at**
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `virtual_account_number` → **debtor_account_number**
  - string [example: `29301655053`] — Debtor account number

---

## `collection_order_find_one`

- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `reference` → **reference** _(required)_
  - string [example: `MxTTi9v4bNYBmORRzslm7f2QsxzkdhrKKeL`] — Reference
- `debtor` → **debtor** _(required)_
  - `email` → **email**
    - string [example: `johndoe@inpay.com`]
  - `full_name` → **full_name**
    - string [example: `John Doe`]
  - `date_of_birth`: string
  - `country_of_residence` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status` → **status** _(required)_
  - string [example: `received`] — Status
- `business_unit`: string _(required)_
- `currency_code` → **currency_code**
  - string [example: `EUR`]
- `amount` → **amount**
  - string [example: `100.0`] — amount
- `payments`: array of **collection_order_payment_item** _(required)_
  - **collection_order_payment_item** (ref)
    - `uuid` → **uuid** _(required)_
      - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
    - `status` → **collection_payment_status** _(required)_
      - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
    - `type` → **collection_payment_type** _(required)_
      - string [enum: ['bank_transfer', 'instant_bank_transfer']]
    - `inpay_unique_reference` → **inpay_unique_reference** _(required)_
      - string [example: `d1a2b3c4d5`] — Our unique reference
    - `created_at` → **created_at** _(required)_
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status_history`: array of **collection_status_history_item** _(required)_
  - **collection_status_history_item** (ref)
    - `status`: string _(required)_
    - `created_at`: string _(required)_
- `refunds`: array of **collection_order_refund_item**
  - **collection_order_refund_item** (ref)
    - `amount`: string _(required)_
    - `category`: string _(required)_
    - `currency_iso`: string _(required)_
    - `status` → **collection_refund_status** _(required)_
      - string [enum: ['created', 'processing', 'initiated', 'halted', 'returned', 'rejected', 'completed', 'cancelled', 'scheduled_for_retry', 'insufficient_funds']]
    - `uuid`: number _(required)_
    - `organisation_id`: number _(required)_
    - `end_to_end_id`: string _(required)_
    - `full_refund`: boolean _(required)_
    - `created_at`: string _(required)_
- `reason_codes`: array of **collection_order_reason_codes_item** _(required)_
  - **collection_order_reason_codes_item** (ref)
    - `kind`: string _(required)_ _enum: ['collection']_
    - `group`: string _(required)_ _enum: ['action_required_for_refund', 'action_required', 'refund_requested', 'order_cancelled']_
    - `reason`: string _(required)_
    - `external_message`: string _(required)_
    - `symbol`: string _(required)_

---

## `collection_order_refund_item`

- `amount`: string _(required)_
- `category`: string _(required)_
- `currency_iso`: string _(required)_
- `status` → **collection_refund_status** _(required)_
  - string [enum: ['created', 'processing', 'initiated', 'halted', 'returned', 'rejected', 'completed', 'cancelled', 'scheduled_for_retry', 'insufficient_funds']]
- `uuid`: number _(required)_
- `organisation_id`: number _(required)_
- `end_to_end_id`: string _(required)_
- `full_refund`: boolean _(required)_
- `created_at`: string _(required)_

---

## `collection_status_history_item`

- `status`: string _(required)_
- `created_at`: string _(required)_

---

## `collection_order_payment_item`

- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `status` → **collection_payment_status** _(required)_
  - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
- `type` → **collection_payment_type** _(required)_
  - string [enum: ['bank_transfer', 'instant_bank_transfer']]
- `inpay_unique_reference` → **inpay_unique_reference** _(required)_
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `collection_refund_status`

- string [enum: ['created', 'processing', 'initiated', 'halted', 'returned', 'rejected', 'completed', 'cancelled', 'scheduled_for_retry', 'insufficient_funds']]

---

## `collection_payment_type`

- string [enum: ['bank_transfer', 'instant_bank_transfer']]

---

## `collection_order_reason_codes_item`

- `kind`: string _(required)_ _enum: ['collection']_
- `group`: string _(required)_ _enum: ['action_required_for_refund', 'action_required', 'refund_requested', 'order_cancelled']_
- `reason`: string _(required)_
- `external_message`: string _(required)_
- `symbol`: string _(required)_

---

## `cancel_order_return_type`

- `status` → **ok_status** _(required)_
  - string [example: `ok`]

---

## `collection_payment_status`

- string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]

---

## `collection_payment_details`

- `debtor_country`: string
- `debtor_bank_name`: string

---

## `collection_payment_find_one`

- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `status` → **collection_payment_status** _(required)_
  - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
- `type` → **collection_payment_type** _(required)_
  - string [enum: ['bank_transfer', 'instant_bank_transfer']]
- `inpay_unique_reference` → **inpay_unique_reference** _(required)_
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `order` → **collection_order_from_payment** _(required)_
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `reference`: string _(required)_ — A unique identifier in your system for this Order
  - `debtor` → **debtor** _(required)_
    - `email` → **email**
      - string [example: `johndoe@inpay.com`]
    - `full_name` → **full_name**
      - string [example: `John Doe`]
    - `date_of_birth`: string
    - `country_of_residence` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `status`: string _(required)_ — Status of your order
  - `amount` → **amount** _(required)_
    - string [example: `100.0`] — amount
  - `amount_cents`: integer _(required)_ — Original amount in cents
  - `currency` → **currency_code** _(required)_
    - string [example: `EUR`]
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `details` → **collection_payment_details**
  - `debtor_country`: string
  - `debtor_bank_name`: string
- `status_history`: array of **collection_status_history_item**
  - **collection_status_history_item** (ref)
    - `status`: string _(required)_
    - `created_at`: string _(required)_

---

## `collection_payment_find_by_uuid_or_reference`

- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `status` → **collection_payment_status** _(required)_
  - string [enum: ['created', 'consent_required', 'kyc_required', 'processing', 'user_authorised', 'extra_info_required', 'bank_info_collected', 'consent_given', 'external_request_created', 'redirect_to_bank', 'redirect_to_inpay', 'external_transfer_required', 'bank_processing', 'user_cancelled', 'bank_rejected', 'bank_authorised', 'completed', 'instructions_provided', 'sum_too_low', 'sum_too_high', 'refunded', 'extra_bank_info_required', 'redirected_to_inpay']]
- `type` → **collection_payment_type** _(required)_
  - string [enum: ['bank_transfer', 'instant_bank_transfer']]
- `inpay_unique_reference` → **inpay_unique_reference** _(required)_
  - string [example: `d1a2b3c4d5`] — Our unique reference
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `order` → **collection_order_from_payment** _(required)_
  - `uuid` → **uuid** _(required)_
    - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
  - `reference`: string _(required)_ — A unique identifier in your system for this Order
  - `debtor` → **debtor** _(required)_
    - `email` → **email**
      - string [example: `johndoe@inpay.com`]
    - `full_name` → **full_name**
      - string [example: `John Doe`]
    - `date_of_birth`: string
    - `country_of_residence` → **country_iso**
      - string [example: `DK`] — Country ISO
    - `created_at` → **created_at**
      - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
  - `status`: string _(required)_ — Status of your order
  - `amount` → **amount** _(required)_
    - string [example: `100.0`] — amount
  - `amount_cents`: integer _(required)_ — Original amount in cents
  - `currency` → **currency_code** _(required)_
    - string [example: `EUR`]
  - `created_at` → **created_at** _(required)_
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `collection_order_from_payment`

- `uuid` → **uuid** _(required)_
  - string [example: `4852ef22-2a0c-4df4-ba45-4b3b67483c1b`] — uuidV4
- `reference`: string _(required)_ — A unique identifier in your system for this Order
- `debtor` → **debtor** _(required)_
  - `email` → **email**
    - string [example: `johndoe@inpay.com`]
  - `full_name` → **full_name**
    - string [example: `John Doe`]
  - `date_of_birth`: string
  - `country_of_residence` → **country_iso**
    - string [example: `DK`] — Country ISO
  - `created_at` → **created_at**
    - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created
- `status`: string _(required)_ — Status of your order
- `amount` → **amount** _(required)_
  - string [example: `100.0`] — amount
- `amount_cents`: integer _(required)_ — Original amount in cents
- `currency` → **currency_code** _(required)_
  - string [example: `EUR`]
- `created_at` → **created_at** _(required)_
  - string (date-time) [example: `2020-01-01T00:00:00Z`] — Datetime when the record was created

---

## `collection_count_status_reports_data_item`

- `code`: string _(required)_
- `name`: string _(required)_
- `count`: integer _(required)_
- `items`: array of **collection_count_status_reports_data_item_reason_code**
  - **collection_count_status_reports_data_item_reason_code** (ref)
    - `code`: string _(required)_
    - `name`: string _(required)_
    - `id`: integer _(required)_

---

## `collection_count_status_reports_data_item_reason_code`

- `code`: string _(required)_
- `name`: string _(required)_
- `id`: integer _(required)_

---

## `external_code`

- `id`: integer _(required)_
- `value`: string _(required)_
- `external_code_set_id`: integer _(required)_

---

## `product_schemas`

- `id`: integer _(required)_
- `label`: string _(required)_

---

## `payment_instruments`

- `local_instrument_family`: string _(required)_
- `products`: array of **product_items** _(required)_
  - **product_items** (ref)
    - `id`: integer _(required)_
    - `corridor`: string _(required)_
    - `v2_product_id`: integer

---

## `product_items`

- `id`: integer _(required)_
- `corridor`: string _(required)_
- `v2_product_id`: integer

---

## `payout_state_category_stat_item`

- `code`: string _(required)_ _enum: ['received', 'pending', 'action_required', 'processing', 'rejected', 'completed', 'returned']_
- `name`: string _(required)_ _enum: ['Received', 'Pending', 'Action required', 'Processing', 'Rejected', 'Completed', 'Returned']_
- `count`: integer _(required)_

---

## `payout_state_category_stat_meta`

- `count`: integer _(required)_

---

## `payout_reason_code_stats`

- `action_required` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `completed` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `pending` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `processing` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `received` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `rejected` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `returned` → **payout_reason_code_stat_item** _(required)_
  - `items`: array of **payout_reason_code_item** _(required)_
    - **payout_reason_code_item** (ref)
      - `id`: integer _(required)_
      - `code`: string _(required)_
      - `name`: string _(required)_
      - `count`: integer _(required)_
      - `percentage`: number (float) _(required)_
  - `meta` → **payout_reason_code_stat_meta** _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_

---

## `payout_reason_code_stat_item`

- `items`: array of **payout_reason_code_item** _(required)_
  - **payout_reason_code_item** (ref)
    - `id`: integer _(required)_
    - `code`: string _(required)_
    - `name`: string _(required)_
    - `count`: integer _(required)_
    - `percentage`: number (float) _(required)_
- `meta` → **payout_reason_code_stat_meta** _(required)_
  - `count`: integer _(required)_
  - `percentage`: number (float) _(required)_

---

## `payout_reason_code_stat_meta`

- `count`: integer _(required)_
- `percentage`: number (float) _(required)_

---

## `payout_reason_code_item`

- `id`: integer _(required)_
- `code`: string _(required)_
- `name`: string _(required)_
- `count`: integer _(required)_
- `percentage`: number (float) _(required)_

---

## `creditor_address_lines`

- string [example: `Toldbodgade 55`]

---

## `creditor_birthdate`

- string (date) [example: `1990-01-01`]

---

## `creditor_city`

- string [example: `Roskilde`]

---

## `creditor_country_code`

- string [example: `DK`]

---

## `creditor_created_by`

- string [example: `John Doe`]

---

## `creditor_email`

- string [example: `museum@kff.kk.dk`]

---

## `creditor_full_name`

- string [example: `John Doe`]

---

## `creditor_mobile_number`

- string [example: `+4533210772`]

---

## `creditor_postcode`

- string [example: `2200`]

---

## `creditor_product_id`

- integer [example: `397`]

---

## `creditor_schema_id`

- integer [example: `107`]

---

## `creditor_key_value_pair`

- `key`: string _(required)_
- `value`: string _(required)_

---

## `creditor_with_details`

- `id`: integer _(required)_
- `address_lines` → **creditor_address_lines**
  - string [example: `Toldbodgade 55`]
- `birthdate` → **creditor_birthdate**
  - string (date) [example: `1990-01-01`]
- `city` → **creditor_city**
  - string [example: `Roskilde`]
- `country_code` → **creditor_country_code**
  - string [example: `DK`]
- `country_of_birth_code` → **creditor_country_code**
  - string [example: `DK`]
- `country_of_residence_code` → **creditor_country_code**
  - string [example: `DK`]
- `created_by` → **creditor_created_by** _(required)_
  - string [example: `John Doe`]
- `creditor_type` → **creditor_type**
  - string [enum: ['organization', 'private'], example: `private`] — Account holder type
- `email` → **creditor_email**
  - string [example: `museum@kff.kk.dk`]
- `full_name` → **creditor_full_name**
  - string [example: `John Doe`]
- `id_expiry_date` → **id_expiry_date**
  - string [example: `2030-05-22`]
- `id_issuing_country_code` → **id_issuing_country_code**
  - string [example: `DK`]
- `id_issuing_date` → **id_issuing_date**
  - string [example: `2020-05-22`]
- `id_number` → **id_number**
  - string [example: `1234567`]
- `id_type` → **id_type**
  - string [example: `Passport`]
- `mobile_number` → **creditor_mobile_number**
  - string [example: `+4533210772`]
- `postcode` → **creditor_postcode**
  - string [example: `2200`]
- `state` → **state**
  - string [example: `CA`]
- `street_name` → **street_name**
  - string [example: `5181 MacGyver Thunder`]
- `product_id` → **creditor_product_id**
  - integer [example: `397`]
- `schema_id` → **creditor_schema_id**
  - integer [example: `107`]
- `creditor_details`: array of **creditor_key_value_pair** _(required)_
  - **creditor_key_value_pair** (ref)
    - `key`: string _(required)_
    - `value`: string _(required)_

---

## `error_response`

- `error` → **validation_error_invalid_uuid** _(required)_
  - `code`: integer _(required)_ — error code from engine
  - `title`: string _(required)_
  - `details`: object _(required)_
    - `uuid`: array of string

---

## `error_generic_details_nil`

- `title`: string _(required)_
- `details`:  _(required)_

---

## `error_generic_detail_string`

- `title`: string _(required)_
- `details`: string _(required)_

---

## `error_generic_detail_object`

- `code`: integer _(required)_ — error code from engine
- `title`: string _(required)_
- `details`: object _(required)_
  - `status`: string

---

## `impersonation_grant_error_response`

- `error`: string _(required)_

---

## `error_attributes`

- `attributes`: object _(required)_
  - `content`: string

---

## `no_organisation_membership_error`

- `errors`: array of **no_organisation_membership_errors_item** _(required)_
  - **no_organisation_membership_errors_item** (ref)
    - `title`: string _(required)_
    - `details`: array of string _(required)_

---

## `no_organisation_membership_errors_item`

- `title`: string _(required)_
- `details`: array of string _(required)_

---

## `refund_no_amount_error`

- `title`: string _(required)_
- `details`: string _(required)_

---

## `refund_bad_amount_error`

- `title`: string _(required)_
- `details`: string _(required)_

---

## `refund_not_configured_error`

- `title`: string _(required)_
- `details`: string _(required)_

---

## `error_generic_with_code_detail_object`

- `code`: integer _(required)_ — error code from engine
- `title`: string _(required)_
- `details`: string _(required)_

---

## `validation_error_invalid_uuid`

- `code`: integer _(required)_ — error code from engine
- `title`: string _(required)_
- `details`: object _(required)_
  - `uuid`: array of string

---

## `unauthorized_error`

- array, items:
  - `title`: string _(required)_

---

## `bad_batch_status_error`

- `code`: integer _(required)_
- `title`: string _(required)_
- `details`: object _(required)_
  - `batch_id`: array of string _(required)_

---

## `batch_bad_filter_error`

- `code`: integer _(required)_
- `title`: string _(required)_
- `details`: object _(required)_
  - `filter`: object _(required)_
    - `kind`: array of string _(required)_

---

## `batch_not_found_error`

- `title`: string _(required)_
- `details`: string _(required)_

---

## `users_not_authorized`

- `title`: string _(required)_

---

## `user_validation_error`

- `code`: integer _(required)_ — error code from engine
- `title`: string _(required)_
- `details` → **user_validation_attributes** _(required)_
  - `first_name`: array of string _(required)_
  - `last_name`: array of string _(required)_
  - `email`: array of string _(required)_
  - `active`: array of string _(required)_
  - `role`: array of string _(required)_

---

## `user_validation_attributes`

- `first_name`: array of string _(required)_
- `last_name`: array of string _(required)_
- `email`: array of string _(required)_
- `active`: array of string _(required)_
- `role`: array of string _(required)_

---

## `payout_draft_validation_error`

- `error`: array of object _(required)_
  - `title`: string
  - `details`: array of string _(required)_
  - `source`: object
    - `pointer`: string

---

## `internal_account_movement_errors`

- `code`: integer — error code from engine
- `title`: string
- `details`: 

---

## `payout_batch_data`

- `filename`: string _(required)_
- `format`: string _(required)_
- `batch_id`: integer _(required)_
- `content`: string _(required)_

---

## `payout_batch_meta`

- `local_instrument`: string _(required)_
- `total_payout_requests`: integer _(required)_
- `total_payout_requests_amount`: number _(required)_
- `currency`: object _(required)_
  - `iso`: string _(required)_
  - `name`: string _(required)_
- `country`: object _(required)_
  - `iso`: string _(required)_
  - `name`: string _(required)_

---

## `payout_batch_errors`

- array, items:
  - `title`: string _(required)_
  - `details`: array of string _(required)_
  - `source`: object _(required)_
    - `pointer`: string _(required)_

---

## `payout_error`

- `details`: array of string _(required)_
- `pointer`: string _(required)_

---

## `payout_batch_error_data`

- `filename`: string _(required)_
- `format`: string _(required)_
- `content`: string _(required)_ — CSV file content with errors

---

## `payout_batch_error_meta`

- `country`: object _(required)_
  - `iso`: string
  - `name`: string
- `currency`: object _(required)_
  - `iso`: string
  - `name`: string
- `local_instrument`: string _(required)_

---
