## Security

Should you at any time wish to update your certificates or token, for either the development/test environment or the production environment, it is necessary to contact Onboarding & Support at [support@inpay.com](mailto:support@inpay.com) to coordinate this, as they need to be updated also in your Inpay account.

We advise you to contact Technical Support before actually changing anything through [support@inpay.com](mailto:support@inpay.com), so that the downtime around changing the certificate can be limited and planned.

## Changing or expanding the functionality

The world is ever evolving, and so are most businesses, probably also yours. If this leads to changed needs, you can always reach out to Onboarding & Support at [support@inpay.com](mailto:support@inpay.com) for at talk about what can be done.

If you change the webhook, please contact Onboarding & Support ahead of time to have your account adjusted to use the new webhook.

## [Purchase](https://www.inpay.com/contact-us/)

Any additional product or feature purchases can be arranged through your Inpay sales contact or Onboarding & Support.

When you update your integration solution, you should go through a project similar to when you first developed the solution, with the exception that you can keep the same certificates and token.

Before going live with the changed solution, you are advised to contact Inpay’s Technical Support for a joint evaluation of the functionality before going live.

Even though you can, technically speaking, omit that renewed test together with Inpay, we advise you to prioritise it – as it might uncover something that could potentially lead to downtime or other problems for your system when entering production.
