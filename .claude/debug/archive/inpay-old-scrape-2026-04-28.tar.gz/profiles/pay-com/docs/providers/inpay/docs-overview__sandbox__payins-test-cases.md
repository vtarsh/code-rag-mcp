Payin test cases can be executed from <a id="customer-app-link">Customer App</a> -> Pay-ins Orders page, Sandbox section of order details.

<table class="table mt-3">
  <thead>
    <tr>
      <th>Test case</th>
      <th>Steps</th>
      <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <code>Complete payment</code>
      </td>
      <td>
        <ol style="list-style-type: decimal; padding-left: 1rem;">
          <li>Create an order through the standard <a href="/reference/collections#collections-order-create">payins API</a></li>
          <li>Go through the standard payment flow</li>
          <li>Navigate to the <a id="customer-app-link">Customer App</a> -> Pay-ins Orders page</li>
          <li>
            Execute <b>Complete payment</b> test case from the Sandbox section of order details
          </li>
        </ol>
      </td>
      <td>
        This test case becomes available when a payment reaches a certain status, based on the payment type. Here's the supported list:
        <ul style="list-style-type: disc; padding-left: 1rem;">
          <li>
            Instant bank transfer: <code>REDIRECT TO BANK</code>, <code>REDIRECTED TO INPAY</code>, <code>BANK PROCESSING</code>, <code>BANK AUTHORISED</code>
          </li>
          <li>
            Bank transfer: <code>INSTRUCTIONS PROVIDED</code>
          </li>
          <li>
            Wallet transfer: <code>PROCESSING</code>, <code>USER_AUTHORISED</code>
          </li>
        </ul>
      </td>
    </tr>
  </tbody>
</table>
