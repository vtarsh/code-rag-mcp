Our Virtual Bank Accounts are the virtual balances that we hold for customers.

This is where we register all customer transactions as debit and credit movements. When sending payout requests, you must tell us which virtual account to debit in order to process your payments. We also apply the transaction charges to the virtual account based on your organisation’s configuration.
