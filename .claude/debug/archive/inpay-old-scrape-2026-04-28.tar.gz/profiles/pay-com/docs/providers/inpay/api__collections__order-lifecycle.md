Inpay uses a simplified set of statuses to help you. Regardless of the Payment (and its related Payment Method) used to provide the funds, each order goes through the same basic sequence and acts as the single source of truth that tracks the end to end collection service lifecycle. The available order statuses in the Collection API are shown below, following the legend:

<img src="payins-order-status-light.png" alt="payouts-diagram"/>

- The Order happy path is illustrated using green color.
- The Order states that require an action from you are illustrated in yellow color.
- Order states that cannot be recovered are illustrated in red color.

<table class="table mt-3">
<thead>
<tr>
<th>
Status
</th>
<th>
Description
</th>
</tr>
</thead>
<tbody>

<tr>
<td>
<code>RECEIVED</code>
</td>
<td>
The Order has been successfully recorded in our system after having passed all validations.
</td>
</tr>

<tr>
<td>
<code>PENDING</code>
</td>
<td>
At least one Payment has been initiated for the Order.
</td>
</tr>

<tr>
<td>
<code>CANCELLED</code>
</td>
<td>
The Order has been cancelled before reaching the PROCESSING status.
</td>
</tr>

<tr>
<td>
<code>AUTHORISED</code>
</td>
<td>
<strong>OPTIONAL:</strong> Payments executed through certain Payment Methods (including Instant Bank Transfer) may set this status in the Order when the Payment has been successfully submitted to the payment instrument. At this stage, Inpay is waiting to receive the funds.
</td>
</tr>

<tr>
<td>
<code>PROCESSING</code>
</td>
<td>
The funds have been successfully received, and Inpay is performing transaction monitoring/screening.
</td>
</tr>

<tr>
<td>
<code>ACTION REQUIRED</code>
</td>
<td>
The Order requires manual action to progress further. This may be due to Inpay internal policies. The reason will be explained in the status_reasons field.
</td>
</tr>

<tr>
<td>
<code>COMPLETED</code>
</td>
<td>
Transaction monitoring/screening has completed successfully and the funds are put at the Merchant's disposal.
</td>
</tr>

<tr>
<td>
<code>PROCESSING REFUND</code>
</td>
<td>
Inpay is performing the pertinent checks prior to executing a refund. This may be due to order was rejected by transaction screening. If so the reason will be set as: 'Rejected by Inpay due to compliance'
</td>
</tr>

<tr>
<td>
<code>ACTION REQUIRED FOR REFUND</code>
</td>
<td>
The Refund requires manual action to progress further. This may be due to missing customer information or Inpay internal policies. The reason will be explained in the status_reasons field.
</td>
</tr>

<tr>
<td>
<code>REFUNDED</code>
</td>
<td>
The funds collected for the Order have been returned to the end-user. This may be due to order was rejected by transaction screening. If so the reason will be set as: 'Rejected by Inpay due to compliance'
</td>
</tr>

<tr>
<td>
<code>PARTIALLY REFUNDED</code>
</td>
<td>
Portion of the funds collected for the Order have been returned to the end-user.
</td>
</tr>

<tr>
<td>
<code>RETURNED</code>
</td>
<td>
If a refund is returned to Inpay after it has been processed, the state will be set to returned and a webhook notification will be sent to you informing you of this status change.
</td>
</tr>

</tbody>
</table>

A webhook notification is sent to you via HTTPs every time an Order transitions from one status to another, Please refer to the webhook notification section for further details.

<div class="warning">
  <li>
An Order is only accepted by Inpay and consequently recorded if all the validations of the <a href="/reference/collections#collections-order-create"/>CreateOrder</a> endpoint are passed by the request.
  </li>
  <li>
An Order may be cancelled by the End-User during the checkout flow or manually by an Inpay Operator at Inpay's BackOffice.
  </li>
</div>

<br />
<div class="hint">
  <p>
    <b>Hint</b>: You can use <a href="/guide/sandbox#sandbox-payins-test-cases">Sandbox test cases</a> to facilitate the order going through various statuses.
  </p>
</div>
