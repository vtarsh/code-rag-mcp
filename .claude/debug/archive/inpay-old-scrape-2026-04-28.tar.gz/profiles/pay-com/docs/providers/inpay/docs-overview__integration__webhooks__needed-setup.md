Even though it might be possible to set up certain integrations without webhooks, we advise against such a solution as it will limit the value you get from the API.

If you have only one webhook URL, all status messages will be sent to that one, but if you have two or more [business units](/guide/docs-integration#integration-definitions-business-units), you can choose to have a separate webhook URL for each of the [business units](/guide/docs-integration#integration-definitions-business-units). This may be practical for your internal processing of the status requests, allowing for easy distribution to the relevant internal process.

The webserver must be using `TLS 1.2` or later and be equipped with a valid SSL certificate by a trusted CA (Certificate Authority).

<div class="warning">
The webhooks need to be set up in our system, so we kindly ask you to send the URL for each webhook address and information on which business unit it belongs to, to our onboarding team when they ask for it.
</div>

[Read more about Business Units](/guide/docs-integration#integration-definitions-business-units)
