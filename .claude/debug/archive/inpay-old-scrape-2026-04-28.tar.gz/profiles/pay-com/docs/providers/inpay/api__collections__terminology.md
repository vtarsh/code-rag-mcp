<table class="table mt-3">
<thead>
<tr>
<th>
Term
</th>
<th>
Description
</th>
</tr>
</thead>
<tbody>
<tr>
<td>
Collection
</td>
<td>
Inpay service that enables you to collect funds from your customers.
</td>
</tr>

<tr>
<td>
Order
</td>
<td>
An Order represents your intention to collect a particular amount from a given customer. It is the main relationship between Inpay's collection service and your system. An order may/may not have multiple payment attempts associated with it. For instance, if the first payment attempt fails and your customer retries a new payment attempt, then the same order will be associated with these two payment attempts.
</td>
</tr>

<tr>
<td>
Payment
</td>
<td>
A Payment represents your customer’s payment attempt to provide the funds for a particular Order via a specific Payment Method.
</td>
</tr>

<tr>
<td>
Payment Method
</td>
<td>
The payment instrument or a way that Inpay makes available to your customers to pay for an order. For example, Instant Bank Transfer.
</td>
</tr>

<tr>
<td>
Instant Bank Transfer
</td>
<td>
A Payment Method where an Online Banking Transfer is initiated via an Open Banking Payment Initiation Service (PIS) directly from your customer’s bank account.
</td>
</tr>

<tr>
<td>
Bank Transfer
</td>
<td>
A Payment Method where a Bank Transfer is initiated by the end user by following a provided set of instructions.
</td>
</tr>

<tr>
<td>
Wallet transfer
</td>
<td>
A payment method where the end-user consents to create a wallet account and selects an available payment instrument to pay with. (<a href="https://entirepay.com/">EntirePay</a> trading name)
</td>
</tr>

<tr>
<td>
Merchant
</td>
<td>
This is you (Inpay customer), the entity with whom Inpay has entered into a contract with.
</td>
</tr>

<tr>
<td>
Debtor
</td>
<td>
Your customer who provides the funds for an order.
</td>
</tr>

<tr>
<td>
Debtor Account
</td>
<td>
In the context of an Instant Bank Transfer Payment, it is the bank account of your customer, where the funds are sourced from.
</td>
</tr>

</tbody>
</table>
