A request identification is needed to ensure the correct match between requests and replies – and to prevent accidentally processing the same request twice.

<b>You must generate the identification for each request</b>, and it can be any unique code or number. We recommend you use [UUID](https://en.wikipedia.org/wiki/Universally_unique_identifier).

The identification is sent back with the reply to and statuses on that specific request.

The HTTP header to use for this: `X-Request-ID: [X-Request-ID]`

`X-Request-ID` will persist in the response so the client could identify the response in case of multiple asynchronous calls.

<div class="warning">
    <li>
      <b>Important</b>: Requests with duplicate <code>X-Request-ID</code> will not be processed. The HTTP return code will be 412 Precondition Failed
    </li>
    <li>
      It is not needed for GET requests
    </li>
</div>
