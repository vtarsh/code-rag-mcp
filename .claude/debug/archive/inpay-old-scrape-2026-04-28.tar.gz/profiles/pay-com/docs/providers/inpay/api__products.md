A product is a concept denoted by a combination of a currency, a country and a local instrument, e.g., international CAD to Canada. A product thus can be compared to access, meaning available products simply shows you which payout services are available for your Inpay account.

The information requirements per product could change. On <a href="/reference/payouts#payouts-create">Create payment request endpoint page</a>, you can verify the required information to be able to create a payment request using a specific product.

<div class="hint">
Hint: If you observe an inconsistency between available corridors and what you/your organisation has purchased, please do reach out to <a href="mailto:support@inpay.com">support@inpay.com</a>
</div>

You currently have access to the following disbursement products. If you want to offer more to your customers and expand your corridor range, your dedicated Account Manager or Customer Success Manager will be able to tell you more about our wide range of payout destinations and currencies. For all other inquiries contact us at support@inpay.com and we'll answer as soon as possible.
