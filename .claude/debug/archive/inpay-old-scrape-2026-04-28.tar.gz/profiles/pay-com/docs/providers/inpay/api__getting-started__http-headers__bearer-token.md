The Bearer Authentication consists of a code or a number that Inpay gives you for the solution and you then include in all communication, together with the `X-Auth-Uuid`, showing that the communication came from you.

The HTTP header to use for this:

`Authorization: Bearer [Authorization Bearer Token]`

<div class="warning">
  <p><b>Important:</b> Remember to keep your Authorization Bearer token & private key secret secure - if you suspect these might has been compromised, contact support@inpay.com to revoke the <code>X-Auth-Uuid</code> and generate a new one for you.</p>
</div>
