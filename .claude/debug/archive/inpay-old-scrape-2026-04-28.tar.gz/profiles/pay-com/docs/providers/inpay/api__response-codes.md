<table>
  <thead>
    <tr>
      <th>Code</th>
      <th>Meaning</th>
      <th>Used When</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>401</td>
      <td>Unauthorised</td>
      <td>The credentials are not accepted</td>
    </tr>
    <tr>
      <td>400</td>
      <td>Bad Request</td>
      <td>The client sent invalid parameters</td>
    </tr>
    <tr>
      <td>422</td>
      <td>Un-processable Entity</td>
      <td>Business logic errors in the API backend</td>
    </tr>
    <tr>
      <td>500</td>
      <td>Internal Server Error</td>
      <td>The program execution stopped unexpectedly</td>
    </tr>
    <tr>
      <td>503</td>
      <td>Service Unavailable</td>
      <td>The infrastructure is not available</td>
    </tr>
  </tbody>
</table>

- **Controlled errors**: will also include a JSON body following the structure depicted in the examples at the right-hand side. The response body will contain an Array of error objects under the errors key. Each error object will include two keys:

- **Title**: a short, human-readable summary of the problem.

- **Detail**: a human-readable explanation specific to this occurrence of the problem. It may be just a sentence, or, in the case of validation errors, it may contain an object pointing at the parameters that went wrong with a list of problems found in each of those parameters.
