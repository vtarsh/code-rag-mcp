- [Payouts](/reference/payouts#payouts-concepts): Functionality to let you make payouts in a simple and effective way.

- [Payins](/reference/collections#payins-concepts): A set of API endpoints and user interface elements that will allow you to handle the pay-in/collection flow with the needed end-user interaction integrated.

- [Reconciliation](/reference/reconciliation#reconciliation-endpoints): What you need to manage and monitor your account with Inpay funding and statements.

Integration help. For ensuring a functioning communication, we offer a set of endpoints that will help you test the authorization and encryption through correct use of certificates.

Comments, suggestions, and corrections may be directed to Onboarding & Support at [support@inpay.com](mailto:support@inpay.com) – and we will be happy to hear from you!
