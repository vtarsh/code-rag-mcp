<table class="table mt-3">
  <thead>
    <tr>
      <th>Term</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Disbursement</td>
      <td>
        Transferring of funds from your account with Inpay to another bank
        account. In common terms, a disbursement is understood as a payout or
        classic bank transfer.
      </td>
    </tr>
    <tr>
      <td>Local Instrument</td>
      <td>
        Specifies the service level to be used for sending the funds. For
        example, instruction to use LOCAL, SEPA, INSTANT SEPA or INTERNATIONAL
        instrument.
      </td>
    </tr>
    <tr>
      <td>Ultimate Debtor</td>
      <td>
        The individual or organisation that ultimately owns the funds being
        transferred and thus is the ordering party/sender of the funds.
      </td>
    </tr>
    <tr>
      <td>Debtor</td>
      <td>
        Your organisation/company has the role of a debtor. This means that
        debtor.name field, for example, must always be populated with the legal
        name of your legal entity/company name.
      </td>
    </tr>
    <tr>
      <td>Debtor account</td>
      <td>
        This is your virtual account with Inpay. This is the account from which
        funds used for payout requests are debited from. Debtor_account.id field
        must therefore contain the relevant ID of your virtual account (11 digit
        number).
      </td>
    </tr>
    <tr>
      <td>Creditor</td>
      <td>
        The individual or organisation to whom the funds are being transferred
        to. In other words, creditor is the beneficiary/receiver of the funds.
      </td>
    </tr>
    <tr>
      <td>Creditor account</td>
      <td>
        The bank account owned by the creditor. This is the bank account to
        which the funds are being sent/transferred to.
      </td>
    </tr>
    <tr>
      <td>Business Unit</td>
      <td>
        A business unit allows you to segmentate your payouts and collections
        based on your internal needs. An organisation by design will always have
        a default business unit created for it.
      </td>
    </tr>
    <tr>
      <td>Product</td>
      <td>
        A product is defined by a combination of currency, country and local
        instrument, e.g. EUR-DE-SEPA or CAD-CA-Local.
      </td>
    </tr>
  </tbody>
</table>
