### Maintaining both test and prod environments

For the further development and the ability to test potential problems and their solutions in a safe environment, it is recommended to maintain the test environment, also after going live.
Each environment will have their own endpoint addresses, and they will each have their own set of certificates. Additionally, there is a separate customer portal access for the test and the production environments.

<div class="warning">
Please pay attention to these details when moving code, testing new developments, or checking the results of API requests.
</div>

### Contacts with Inpay

Your initial contact will be with our sales department, and you can always reach out to your Inpay sales contact if you need to adjust your set of functionality or products.
If you have agreed on a hyper care period after going live with the integration, this will be arranged together with your Inpay sales contact.

_During an integration project, there are a few needed touchpoints with the Inpay Onboarding & Support department, as described in the onboarding process section, and when you are live with the integration, you can always reach out to them through the support portal for any technical questions._
