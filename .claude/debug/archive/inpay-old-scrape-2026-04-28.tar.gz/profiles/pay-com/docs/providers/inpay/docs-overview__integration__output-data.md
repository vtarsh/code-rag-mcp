Similar considerations as for the input data counts for the output data. They will need to be fed into your other systems either

- directly as part of an event-based flow, following the individual request you sent off and its response
- or they may be collected and fed into your other systems batch-wise.

<div class="warning">
It is important to keep in mind that the response to a request may appear asynchronously through the webhook, meaning that you in your program design potentially could have several parallel requests going on, and the responses might then need to be paired with the correct request to produce a full set of result data for the further processing in your solution.
</div>
