As soon as you have made an agreement with Inpay, your contact will get in touch with our onboarding team with information on how to proceed and with access to the customer portal and your customised documentation – with all the features and information that you need for your business and for your integration project.

In the prepare step, you should:

- Get access to the API information
- Understand the problem
- Design a project that solves the problem, using the API
- Access custom documentation

The first thing to do is ensuring that you have an internal setup and structure that will bring such information and communication into the hands of those who need it.

If you are planning a project, getting early access to the documentation is important, as some of your decisions for the project planning and integration design and functionality might be affected by the details in how the API works.

## Establish development environment

It is possible that you already have an environment for your software development, and that you want to implement the integration with the Inpay API using that same environment.

If you, on the other hand, need to set up a new environment, you will have all the usual considerations on which programming language to choose, for instance, and how the interfaces to your other systems, to which the Inpay API should be integrated, can best be accessed.
